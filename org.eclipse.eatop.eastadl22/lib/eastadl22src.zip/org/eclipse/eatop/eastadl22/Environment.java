/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Environment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The collection of the environment functional descriptions. This collection can be done across the EAST-ADL abstraction levels.
 * 
 * An environment model can contain functionPrototypes given by either AnalysisFunction or DesignFunction. The environment model does not have abstraction levels as in the system model (e.g., analysisLevel, designLevel).
 * 
 * A functionPrototype of the environment model can have interactions with FAA FunctionalDevice and an FDA HardwareFunction through the ClampConnector.
 * 
 * Semantics:
 * Environment is a container element for the entities surrounding the EE architecture and their connections to the EE architecture. The function hierarchy of the Environment interacts with the EE System through Clamp Connectors connected to the SystemModel's functions.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Environment.Environment</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Environment#getClampConnector <em>Clamp Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Environment#getEnvironmentModel <em>Environment Model</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEnvironment()
 * @model annotation="MetaData guid='{F55D2C97-57ED-4a0c-B07E-C860AB5B4BB3}' id='82' EA\040name='Environment'"
 *        extendedMetaData="name='ENVIRONMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ENVIRONMENTS'"
 * @generated
 */
public interface Environment extends Context {
	/**
	 * Returns the value of the '<em><b>Clamp Connector</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ClampConnector}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Clamp Connector</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Clamp Connector</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEnvironment_ClampConnector()
	 * @model containment="true"
	 *        annotation="MetaData guid='{C7CC367F-36C2-4866-B289-17C771368AB2}' id='538' EA\040name=''"
	 *        extendedMetaData="name='CLAMP-CONNECTOR' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CLAMP-CONNECTORS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ClampConnector> getClampConnector();

	/**
	 * Returns the value of the '<em><b>Environment Model</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Environment Model</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Environment Model</em>' containment reference.
	 * @see #setEnvironmentModel(FunctionPrototype)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEnvironment_EnvironmentModel()
	 * @model containment="true"
	 *        annotation="MetaData guid='{4A836273-1F54-47f8-BBD8-70A1D967E760}' id='629' EA\040name=''"
	 *        extendedMetaData="name='ENVIRONMENT-MODEL' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ENVIRONMENT-MODELS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	FunctionPrototype getEnvironmentModel();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Environment#getEnvironmentModel <em>Environment Model</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Environment Model</em>' containment reference.
	 * @see #getEnvironmentModel()
	 * @generated
	 */
	void setEnvironmentModel(FunctionPrototype value);

} // Environment
