/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Age Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An AgeConstraint defines how long before each response a corresponding stimulus must have occurred.
 * 
 * This constraint provides an alternative to the ordinary DelayConstraint for situations where the causal relation between event occurrences must be taken into account. It differs from the DelayConstraint in that it applies to an event chain, and only looks at the stimulus occurrences that have the same color as each particular response occurrence. It is the latest of these stimulus occurrences that is required to lie within the prescribed time bounds. If the roles of stimulus and response are swapped, and the time bounds negated, a ReactionConstraint is obtained.
 * 
 * Semantics:
 * A system behavior satisfies an AgeConstraint c if and only if
 * for each occurrence y in c.scope.response,
 * 		there is an occurrence x in c.scope.stimulus such that
 * 			x.color = y.color
 * 		and
 * 			x is maximal in c.scope.stimulus with that color
 * 		and
 * 			c.minimum &lt;= y - x &lt;= c.maximum
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.AgeConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.AgeConstraint#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.AgeConstraint#getMaximum <em>Maximum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.AgeConstraint#getScope <em>Scope</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAgeConstraint()
 * @model annotation="MetaData guid='{975F31C2-9874-4c9b-A3B4-42A12451BFA8}' id='172' EA\040name='AgeConstraint'"
 *        extendedMetaData="name='AGE-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='AGE-CONSTRAINTS'"
 * @generated
 */
public interface AgeConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Minimum</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Minimum</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Minimum</em>' containment reference.
	 * @see #setMinimum(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAgeConstraint_Minimum()
	 * @model containment="true"
	 *        annotation="MetaData guid='{6EF8D9D2-7822-4107-9637-2E3B1E040588}' id='315' EA\040name=''"
	 *        extendedMetaData="name='MINIMUM' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MINIMUMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getMinimum();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.AgeConstraint#getMinimum <em>Minimum</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Minimum</em>' containment reference.
	 * @see #getMinimum()
	 * @generated
	 */
	void setMinimum(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Maximum</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Maximum</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Maximum</em>' containment reference.
	 * @see #setMaximum(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAgeConstraint_Maximum()
	 * @model containment="true"
	 *        annotation="MetaData guid='{0862DCF8-9346-459d-B2E9-EED8B68FB867}' id='324' EA\040name=''"
	 *        extendedMetaData="name='MAXIMUM' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MAXIMUMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getMaximum();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.AgeConstraint#getMaximum <em>Maximum</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Maximum</em>' containment reference.
	 * @see #getMaximum()
	 * @generated
	 */
	void setMaximum(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Scope</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scope</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scope</em>' reference.
	 * @see #setScope(EventChain)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAgeConstraint_Scope()
	 * @model required="true"
	 *        annotation="MetaData guid='{7499871B-D7DE-4b99-9E6F-5549D4EBF078}' id='352' EA\040name=''"
	 *        extendedMetaData="name='SCOPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SCOPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EventChain getScope();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.AgeConstraint#getScope <em>Scope</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Scope</em>' reference.
	 * @see #getScope()
	 * @generated
	 */
	void setScope(EventChain value);

} // AgeConstraint
