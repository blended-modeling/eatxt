/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Attribute Binding</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.AttributeQuantificationConstraint.BehaviorAttributeBinding</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorAttributeBinding#getAttribute <em>Attribute</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorAttributeBinding#getVisibleThroughAnomaly <em>Visible Through Anomaly</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorAttributeBinding#getVisibleThroughHardwarePort <em>Visible Through Hardware Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorAttributeBinding#getVisibleThroughHardwarePin <em>Visible Through Hardware Pin</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorAttributeBinding#getVisibleThroughFunctionPort <em>Visible Through Function Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorAttributeBinding()
 * @model annotation="MetaData guid='{899954A2-ACA9-483d-80D8-9C51A2F662C9}' id='308' EA\040name='BehaviorAttributeBinding'"
 *        extendedMetaData="name='BEHAVIOR-ATTRIBUTE-BINDING' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-ATTRIBUTE-BINDINGS'"
 * @generated
 */
public interface BehaviorAttributeBinding extends Relationship {
	/**
	 * Returns the value of the '<em><b>Attribute</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Attribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attribute</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attribute</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorAttributeBinding_Attribute()
	 * @model required="true"
	 *        annotation="MetaData guid='{03AA9C83-57A1-4f0e-B284-8043AFDCF9C8}' id='59' EA\040name=''"
	 *        extendedMetaData="name='ATTRIBUTE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ATTRIBUTE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Attribute> getAttribute();

	/**
	 * Returns the value of the '<em><b>Visible Through Anomaly</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Anomaly}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Visible Through Anomaly</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Visible Through Anomaly</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorAttributeBinding_VisibleThroughAnomaly()
	 * @model annotation="MetaData guid='{3CEC67CC-A015-4c2f-BA50-E705C9C38809}' id='212' EA\040name=''"
	 *        extendedMetaData="name='VISIBLE-THROUGH-ANOMALY-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VISIBLE-THROUGH-ANOMALY-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Anomaly> getVisibleThroughAnomaly();

	/**
	 * Returns the value of the '<em><b>Visible Through Hardware Port</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.HardwarePort}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Visible Through Hardware Port</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Visible Through Hardware Port</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorAttributeBinding_VisibleThroughHardwarePort()
	 * @model annotation="MetaData guid='{27E17DA0-CD5E-428a-A4E5-142EF65D9B8C}' id='548' EA\040name=''"
	 *        extendedMetaData="name='VISIBLE-THROUGH-HARDWARE-PORT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VISIBLE-THROUGH-HARDWARE-PORT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<HardwarePort> getVisibleThroughHardwarePort();

	/**
	 * Returns the value of the '<em><b>Visible Through Hardware Pin</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.HardwarePin}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Visible Through Hardware Pin</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Visible Through Hardware Pin</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorAttributeBinding_VisibleThroughHardwarePin()
	 * @model annotation="MetaData guid='{A5CCC124-2E7C-47d7-A435-2EC54183189E}' id='551' EA\040name=''"
	 *        extendedMetaData="name='VISIBLE-THROUGH-HARDWARE-PIN-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VISIBLE-THROUGH-HARDWARE-PIN-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<HardwarePin> getVisibleThroughHardwarePin();

	/**
	 * Returns the value of the '<em><b>Visible Through Function Port</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionPort}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Visible Through Function Port</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Visible Through Function Port</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorAttributeBinding_VisibleThroughFunctionPort()
	 * @model annotation="MetaData guid='{86A0E440-B241-4438-8112-64A4D832DEBF}' id='674' EA\040name=''"
	 *        extendedMetaData="name='VISIBLE-THROUGH-FUNCTION-PORT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VISIBLE-THROUGH-FUNCTION-PORT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FunctionPort> getVisibleThroughFunctionPort();

} // BehaviorAttributeBinding
