/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Generic Constraint Kind</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * Enumeration for different type of constraints.
 * 
 * Semantics:
 * The semantics is defined on each literal.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.GenericConstraints.GenericConstraintKind</b></em> 
 * <!-- end-model-doc -->
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getGenericConstraintKind()
 * @model annotation="MetaData guid='{B212672E-7EFA-4750-9F39-1B5899E7C8F1}' id='232' EA\040name='GenericConstraintKind'"
 *        annotation="Stereotype Stereotype='enumeration'"
 *        extendedMetaData="name='GENERIC-CONSTRAINT-KIND'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='GENERIC-CONSTRAINT-KINDS'"
 * @generated
 */
public enum GenericConstraintKind implements Enumerator {
	/**
	 * The '<em><b>Cable Length</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CABLE_LENGTH_VALUE
	 * @generated
	 * @ordered
	 */
	CABLE_LENGTH(0, "cableLength", "CABLELENGTH"),

	/**
	 * The '<em><b>Computational Element Kind</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #COMPUTATIONAL_ELEMENT_KIND_VALUE
	 * @generated
	 * @ordered
	 */
	COMPUTATIONAL_ELEMENT_KIND(1, "computationalElementKind", "COMPUTATIONALELEMENTKIND"),

	/**
	 * The '<em><b>Current</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CURRENT_VALUE
	 * @generated
	 * @ordered
	 */
	CURRENT(2, "current", "CURRENT"),

	/**
	 * The '<em><b>Development Cost</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DEVELOPMENT_COST_VALUE
	 * @generated
	 * @ordered
	 */
	DEVELOPMENT_COST(3, "developmentCost", "DEVELOPMENTCOST"),

	/**
	 * The '<em><b>Function Allocation Different HW</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FUNCTION_ALLOCATION_DIFFERENT_HW_VALUE
	 * @generated
	 * @ordered
	 */
	FUNCTION_ALLOCATION_DIFFERENT_HW(4, "functionAllocationDifferentHW", "FUNCTIONALLOCATIONDIFFERENTHW"),

	/**
	 * The '<em><b>Function Allocation Same HW</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FUNCTION_ALLOCATION_SAME_HW_VALUE
	 * @generated
	 * @ordered
	 */
	FUNCTION_ALLOCATION_SAME_HW(5, "functionAllocationSameHW", "FUNCTIONALLOCATIONSAMEHW"),

	/**
	 * The '<em><b>Impedance</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #IMPEDANCE_VALUE
	 * @generated
	 * @ordered
	 */
	IMPEDANCE(6, "impedance", "IMPEDANCE"),

	/**
	 * The '<em><b>Insulation</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #INSULATION_VALUE
	 * @generated
	 * @ordered
	 */
	INSULATION(7, "insulation", "INSULATION"),

	/**
	 * The '<em><b>Memory</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MEMORY_VALUE
	 * @generated
	 * @ordered
	 */
	MEMORY(8, "memory", "MEMORY"),

	/**
	 * The '<em><b>Non Volatile Memory</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NON_VOLATILE_MEMORY_VALUE
	 * @generated
	 * @ordered
	 */
	NON_VOLATILE_MEMORY(9, "nonVolatileMemory", "NONVOLATILEMEMORY"),

	/**
	 * The '<em><b>Other</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #OTHER_VALUE
	 * @generated
	 * @ordered
	 */
	OTHER(10, "other", "OTHER"),

	/**
	 * The '<em><b>Piece Cost</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PIECE_COST_VALUE
	 * @generated
	 * @ordered
	 */
	PIECE_COST(11, "pieceCost", "PIECECOST"),

	/**
	 * The '<em><b>Power Consumption</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #POWER_CONSUMPTION_VALUE
	 * @generated
	 * @ordered
	 */
	POWER_CONSUMPTION(12, "powerConsumption", "POWERCONSUMPTION"),

	/**
	 * The '<em><b>Power Supply Independent</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #POWER_SUPPLY_INDEPENDENT_VALUE
	 * @generated
	 * @ordered
	 */
	POWER_SUPPLY_INDEPENDENT(13, "powerSupplyIndependent", "POWERSUPPLYINDEPENDENT"),

	/**
	 * The '<em><b>Realization Different</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REALIZATION_DIFFERENT_VALUE
	 * @generated
	 * @ordered
	 */
	REALIZATION_DIFFERENT(14, "realizationDifferent", "REALIZATIONDIFFERENT"),

	/**
	 * The '<em><b>Realization Same</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REALIZATION_SAME_VALUE
	 * @generated
	 * @ordered
	 */
	REALIZATION_SAME(15, "realizationSame", "REALIZATIONSAME"),

	/**
	 * The '<em><b>Space Redundancy</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SPACE_REDUNDANCY_VALUE
	 * @generated
	 * @ordered
	 */
	SPACE_REDUNDANCY(16, "spaceRedundancy", "SPACEREDUNDANCY"),

	/**
	 * The '<em><b>Standard</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #STANDARD_VALUE
	 * @generated
	 * @ordered
	 */
	STANDARD(17, "standard", "STANDARD"),

	/**
	 * The '<em><b>Time Redundancy</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TIME_REDUNDANCY_VALUE
	 * @generated
	 * @ordered
	 */
	TIME_REDUNDANCY(18, "timeRedundancy", "TIMEREDUNDANCY"),

	/**
	 * The '<em><b>Utilization</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UTILIZATION_VALUE
	 * @generated
	 * @ordered
	 */
	UTILIZATION(19, "utilization", "UTILIZATION"),

	/**
	 * The '<em><b>Volatile Memory</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #VOLATILE_MEMORY_VALUE
	 * @generated
	 * @ordered
	 */
	VOLATILE_MEMORY(20, "volatileMemory", "VOLATILEMEMORY"),

	/**
	 * The '<em><b>Voltage</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #VOLTAGE_VALUE
	 * @generated
	 * @ordered
	 */
	VOLTAGE(21, "voltage", "VOLTAGE"),

	/**
	 * The '<em><b>Weight</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WEIGHT_VALUE
	 * @generated
	 * @ordered
	 */
	WEIGHT(22, "weight", "WEIGHT");

	/**
	 * The '<em><b>Cable Length</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Cable Length</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CABLE_LENGTH
	 * @model name="cableLength" literal="CABLELENGTH"
	 * @generated
	 * @ordered
	 */
	public static final int CABLE_LENGTH_VALUE = 0;

	/**
	 * The '<em><b>Computational Element Kind</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Computational Element Kind</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #COMPUTATIONAL_ELEMENT_KIND
	 * @model name="computationalElementKind" literal="COMPUTATIONALELEMENTKIND"
	 * @generated
	 * @ordered
	 */
	public static final int COMPUTATIONAL_ELEMENT_KIND_VALUE = 1;

	/**
	 * The '<em><b>Current</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Current</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CURRENT
	 * @model name="current" literal="CURRENT"
	 * @generated
	 * @ordered
	 */
	public static final int CURRENT_VALUE = 2;

	/**
	 * The '<em><b>Development Cost</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Development Cost</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DEVELOPMENT_COST
	 * @model name="developmentCost" literal="DEVELOPMENTCOST"
	 * @generated
	 * @ordered
	 */
	public static final int DEVELOPMENT_COST_VALUE = 3;

	/**
	 * The '<em><b>Function Allocation Different HW</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Function Allocation Different HW</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #FUNCTION_ALLOCATION_DIFFERENT_HW
	 * @model name="functionAllocationDifferentHW" literal="FUNCTIONALLOCATIONDIFFERENTHW"
	 * @generated
	 * @ordered
	 */
	public static final int FUNCTION_ALLOCATION_DIFFERENT_HW_VALUE = 4;

	/**
	 * The '<em><b>Function Allocation Same HW</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Function Allocation Same HW</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #FUNCTION_ALLOCATION_SAME_HW
	 * @model name="functionAllocationSameHW" literal="FUNCTIONALLOCATIONSAMEHW"
	 * @generated
	 * @ordered
	 */
	public static final int FUNCTION_ALLOCATION_SAME_HW_VALUE = 5;

	/**
	 * The '<em><b>Impedance</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Impedance</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #IMPEDANCE
	 * @model name="impedance" literal="IMPEDANCE"
	 * @generated
	 * @ordered
	 */
	public static final int IMPEDANCE_VALUE = 6;

	/**
	 * The '<em><b>Insulation</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Insulation</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #INSULATION
	 * @model name="insulation" literal="INSULATION"
	 * @generated
	 * @ordered
	 */
	public static final int INSULATION_VALUE = 7;

	/**
	 * The '<em><b>Memory</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Memory</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MEMORY
	 * @model name="memory" literal="MEMORY"
	 * @generated
	 * @ordered
	 */
	public static final int MEMORY_VALUE = 8;

	/**
	 * The '<em><b>Non Volatile Memory</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Non Volatile Memory</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NON_VOLATILE_MEMORY
	 * @model name="nonVolatileMemory" literal="NONVOLATILEMEMORY"
	 * @generated
	 * @ordered
	 */
	public static final int NON_VOLATILE_MEMORY_VALUE = 9;

	/**
	 * The '<em><b>Other</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Other</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #OTHER
	 * @model name="other" literal="OTHER"
	 * @generated
	 * @ordered
	 */
	public static final int OTHER_VALUE = 10;

	/**
	 * The '<em><b>Piece Cost</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Piece Cost</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PIECE_COST
	 * @model name="pieceCost" literal="PIECECOST"
	 * @generated
	 * @ordered
	 */
	public static final int PIECE_COST_VALUE = 11;

	/**
	 * The '<em><b>Power Consumption</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Power Consumption</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #POWER_CONSUMPTION
	 * @model name="powerConsumption" literal="POWERCONSUMPTION"
	 * @generated
	 * @ordered
	 */
	public static final int POWER_CONSUMPTION_VALUE = 12;

	/**
	 * The '<em><b>Power Supply Independent</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Power Supply Independent</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #POWER_SUPPLY_INDEPENDENT
	 * @model name="powerSupplyIndependent" literal="POWERSUPPLYINDEPENDENT"
	 * @generated
	 * @ordered
	 */
	public static final int POWER_SUPPLY_INDEPENDENT_VALUE = 13;

	/**
	 * The '<em><b>Realization Different</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Realization Different</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REALIZATION_DIFFERENT
	 * @model name="realizationDifferent" literal="REALIZATIONDIFFERENT"
	 * @generated
	 * @ordered
	 */
	public static final int REALIZATION_DIFFERENT_VALUE = 14;

	/**
	 * The '<em><b>Realization Same</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Realization Same</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REALIZATION_SAME
	 * @model name="realizationSame" literal="REALIZATIONSAME"
	 * @generated
	 * @ordered
	 */
	public static final int REALIZATION_SAME_VALUE = 15;

	/**
	 * The '<em><b>Space Redundancy</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Space Redundancy</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SPACE_REDUNDANCY
	 * @model name="spaceRedundancy" literal="SPACEREDUNDANCY"
	 * @generated
	 * @ordered
	 */
	public static final int SPACE_REDUNDANCY_VALUE = 16;

	/**
	 * The '<em><b>Standard</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Standard</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #STANDARD
	 * @model name="standard" literal="STANDARD"
	 * @generated
	 * @ordered
	 */
	public static final int STANDARD_VALUE = 17;

	/**
	 * The '<em><b>Time Redundancy</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Time Redundancy</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TIME_REDUNDANCY
	 * @model name="timeRedundancy" literal="TIMEREDUNDANCY"
	 * @generated
	 * @ordered
	 */
	public static final int TIME_REDUNDANCY_VALUE = 18;

	/**
	 * The '<em><b>Utilization</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Utilization</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UTILIZATION
	 * @model name="utilization" literal="UTILIZATION"
	 * @generated
	 * @ordered
	 */
	public static final int UTILIZATION_VALUE = 19;

	/**
	 * The '<em><b>Volatile Memory</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Volatile Memory</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #VOLATILE_MEMORY
	 * @model name="volatileMemory" literal="VOLATILEMEMORY"
	 * @generated
	 * @ordered
	 */
	public static final int VOLATILE_MEMORY_VALUE = 20;

	/**
	 * The '<em><b>Voltage</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Voltage</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #VOLTAGE
	 * @model name="voltage" literal="VOLTAGE"
	 * @generated
	 * @ordered
	 */
	public static final int VOLTAGE_VALUE = 21;

	/**
	 * The '<em><b>Weight</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Weight</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #WEIGHT
	 * @model name="weight" literal="WEIGHT"
	 * @generated
	 * @ordered
	 */
	public static final int WEIGHT_VALUE = 22;

	/**
	 * An array of all the '<em><b>Generic Constraint Kind</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final GenericConstraintKind[] VALUES_ARRAY =
		new GenericConstraintKind[] {
			CABLE_LENGTH,
			COMPUTATIONAL_ELEMENT_KIND,
			CURRENT,
			DEVELOPMENT_COST,
			FUNCTION_ALLOCATION_DIFFERENT_HW,
			FUNCTION_ALLOCATION_SAME_HW,
			IMPEDANCE,
			INSULATION,
			MEMORY,
			NON_VOLATILE_MEMORY,
			OTHER,
			PIECE_COST,
			POWER_CONSUMPTION,
			POWER_SUPPLY_INDEPENDENT,
			REALIZATION_DIFFERENT,
			REALIZATION_SAME,
			SPACE_REDUNDANCY,
			STANDARD,
			TIME_REDUNDANCY,
			UTILIZATION,
			VOLATILE_MEMORY,
			VOLTAGE,
			WEIGHT,
		};

	/**
	 * A public read-only list of all the '<em><b>Generic Constraint Kind</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<GenericConstraintKind> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Generic Constraint Kind</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static GenericConstraintKind get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			GenericConstraintKind result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Generic Constraint Kind</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static GenericConstraintKind getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			GenericConstraintKind result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Generic Constraint Kind</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static GenericConstraintKind get(int value) {
		switch (value) {
			case CABLE_LENGTH_VALUE: return CABLE_LENGTH;
			case COMPUTATIONAL_ELEMENT_KIND_VALUE: return COMPUTATIONAL_ELEMENT_KIND;
			case CURRENT_VALUE: return CURRENT;
			case DEVELOPMENT_COST_VALUE: return DEVELOPMENT_COST;
			case FUNCTION_ALLOCATION_DIFFERENT_HW_VALUE: return FUNCTION_ALLOCATION_DIFFERENT_HW;
			case FUNCTION_ALLOCATION_SAME_HW_VALUE: return FUNCTION_ALLOCATION_SAME_HW;
			case IMPEDANCE_VALUE: return IMPEDANCE;
			case INSULATION_VALUE: return INSULATION;
			case MEMORY_VALUE: return MEMORY;
			case NON_VOLATILE_MEMORY_VALUE: return NON_VOLATILE_MEMORY;
			case OTHER_VALUE: return OTHER;
			case PIECE_COST_VALUE: return PIECE_COST;
			case POWER_CONSUMPTION_VALUE: return POWER_CONSUMPTION;
			case POWER_SUPPLY_INDEPENDENT_VALUE: return POWER_SUPPLY_INDEPENDENT;
			case REALIZATION_DIFFERENT_VALUE: return REALIZATION_DIFFERENT;
			case REALIZATION_SAME_VALUE: return REALIZATION_SAME;
			case SPACE_REDUNDANCY_VALUE: return SPACE_REDUNDANCY;
			case STANDARD_VALUE: return STANDARD;
			case TIME_REDUNDANCY_VALUE: return TIME_REDUNDANCY;
			case UTILIZATION_VALUE: return UTILIZATION;
			case VOLATILE_MEMORY_VALUE: return VOLATILE_MEMORY;
			case VOLTAGE_VALUE: return VOLTAGE;
			case WEIGHT_VALUE: return WEIGHT;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private GenericConstraintKind(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //GenericConstraintKind