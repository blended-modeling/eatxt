/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Configurable Container</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ConfigurableContainer is a marker class that marks an element identified by association configurableElement as a configurable container of some variable content, i.e. VariableElements and other, lower-level ConfigurableContainers. In order to describe the contained variability to the outside world and to allow configuration of it, the ConfigurableContainer can have a public feature model and an internal configuration decision model not visible from the outside, called "internal binding".
 * 
 * In addition, the ConfigurableContainer can be used to extend the EAST-ADL variability approach to other languages and standards by pointing from the ConfigurableContainer to the respective (non EAST-ADL) element with association configurableElement. This provides the public feature model and the ConfigurationDecisionModel to that non EAST-ADL element.
 * 
 * The variable content of a ConfigurableContainer is defined as all VariableElements and all other ConfigurableContainers that are directly or indirectly contained in the Identifiable denoted by association configurableElement. Instead of 'variable content' the term 'internal variability' may be used.
 * 
 * Note that, according to this rule, the containment between a ConfigurableContainer and its variable content, i.e. it's contained VariableElements and lower-level ConfigurableContainers, is not directly defined between these meta-classes. Instead, the containment is defined by the Identifiable pointed to by association configurableElement. For example, consider a FunctionType "WiperSystem" containing two FunctionPrototypes "front" and "rear" both typed by FunctionType "WiperMotor"; to make the wiper system configurable and the rear wiper motor optional, a ConfigurableContainer is created that points to FunctionType "WiperSystem" (with association configurableElement) and a VariableElement is created that points to FunctionPrototype "rear" (with association optionalElement); the containment between the ConfigurableContainer and the VariableElement is therefore not explicitly defined between these classes but instead only between FunctionType "WiperSystem" and "FunctionPrototype" rear. In addition, the variability-related visibility of "rear" can be changed with PrivateContent: by default the variability of "rear" will be public and visible for direct configuration from the outside of its containing ConfigurableContainer, i.e. "WiperSystem"; by defining a PrivateContent marker object pointing to the FunctionPrototype "rear", this can be changed to private and this variability will not be visible from the outside of "WiperSystem".
 * 
 * Constraints:
 * [1] Identifies one FunctionType or one HardwareComponentType.
 * 
 * [2] The publicFeatureModel is only allowed to contain Features (no VehicleFeatures).
 * 
 * Semantics:
 * Marks the element identified by association configurableElement as a configurable container of variable content (i.e. it contains VariableElements and/or other, lower-level ConfigurableContainers) and optionally provides a public feature model and an internal configuration decision model for it, thus providing configurability support for them.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.ConfigurableContainer</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurableContainer#getConfigurableElement <em>Configurable Element</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurableContainer#getVariationGroup <em>Variation Group</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurableContainer#getInternalBinding <em>Internal Binding</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurableContainer#getPublicFeatureModel <em>Public Feature Model</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurableContainer#getPrivateContent <em>Private Content</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurableContainer()
 * @model annotation="MetaData guid='{ADC87964-025A-43ff-AF24-E2EE8F5F934E}' id='104' EA\040name='ConfigurableContainer'"
 *        extendedMetaData="name='CONFIGURABLE-CONTAINER' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURABLE-CONTAINERS'"
 * @generated
 */
public interface ConfigurableContainer extends EAElement {
	/**
	 * Returns the value of the '<em><b>Configurable Element</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Configurable Element</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Configurable Element</em>' reference.
	 * @see #setConfigurableElement(Identifiable)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurableContainer_ConfigurableElement()
	 * @model required="true"
	 *        annotation="MetaData guid='{823C111C-0845-4210-B5FD-F7EA56554B19}' id='483' EA\040name=''"
	 *        extendedMetaData="name='CONFIGURABLE-ELEMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURABLE-ELEMENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Identifiable getConfigurableElement();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurableContainer#getConfigurableElement <em>Configurable Element</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Configurable Element</em>' reference.
	 * @see #getConfigurableElement()
	 * @generated
	 */
	void setConfigurableElement(Identifiable value);

	/**
	 * Returns the value of the '<em><b>Variation Group</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VariationGroup}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Variation Group</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Variation Group</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurableContainer_VariationGroup()
	 * @model containment="true"
	 *        annotation="MetaData guid='{DE3FD5B3-DAA9-4298-9F39-6B9B1A24A816}' id='489' EA\040name=''"
	 *        extendedMetaData="name='VARIATION-GROUP' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIATION-GROUPS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<VariationGroup> getVariationGroup();

	/**
	 * Returns the value of the '<em><b>Internal Binding</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Internal Binding</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Internal Binding</em>' containment reference.
	 * @see #setInternalBinding(InternalBinding)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurableContainer_InternalBinding()
	 * @model containment="true"
	 *        annotation="MetaData guid='{0E30C9AC-BF3A-4ded-B32F-4EE3A61140ED}' id='491' EA\040name=''"
	 *        extendedMetaData="name='INTERNAL-BINDING' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INTERNAL-BINDINGS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	InternalBinding getInternalBinding();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurableContainer#getInternalBinding <em>Internal Binding</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Internal Binding</em>' containment reference.
	 * @see #getInternalBinding()
	 * @generated
	 */
	void setInternalBinding(InternalBinding value);

	/**
	 * Returns the value of the '<em><b>Public Feature Model</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Public Feature Model</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Public Feature Model</em>' containment reference.
	 * @see #setPublicFeatureModel(FeatureModel)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurableContainer_PublicFeatureModel()
	 * @model containment="true"
	 *        annotation="MetaData guid='{C4136E91-0169-4536-AEEC-52279C6EC7A2}' id='701' EA\040name=''"
	 *        extendedMetaData="name='PUBLIC-FEATURE-MODEL' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PUBLIC-FEATURE-MODELS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FeatureModel getPublicFeatureModel();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurableContainer#getPublicFeatureModel <em>Public Feature Model</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Public Feature Model</em>' containment reference.
	 * @see #getPublicFeatureModel()
	 * @generated
	 */
	void setPublicFeatureModel(FeatureModel value);

	/**
	 * Returns the value of the '<em><b>Private Content</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.PrivateContent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Private Content</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Private Content</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurableContainer_PrivateContent()
	 * @model containment="true"
	 *        annotation="MetaData guid='{F7E122F4-7293-433e-8C44-EE161B1D5EA7}' id='505' EA\040name=''"
	 *        extendedMetaData="name='PRIVATE-CONTENT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRIVATE-CONTENTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<PrivateContent> getPrivateContent();

} // ConfigurableContainer
