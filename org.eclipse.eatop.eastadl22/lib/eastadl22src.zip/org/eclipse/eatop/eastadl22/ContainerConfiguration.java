/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Container Configuration</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ContainerConfiguration defines an actual configuration of the variable content of a ConfigurableContainer, in particular the selection or de-selection of contained VariableElements and the configuration of the public feature models of other contained ConfigurableContainers. For more details on the variable content of a ConfigurableContainer refer to the documentation of meta-class ConfigurableContainer.
 * 
 * The ContainerConfiguration inherits from ConfigurationDecisionModel even though it does not define a configuration link between feature models, similar to FeatureConfiguration. For more information on this, refer to the documentation of meta-class FeatureConfiguration.
 * 
 * The source and target feature models of a ContainerConfiguration are defined implicitly: it always has zero source feature models (as explained for FeatureConfiguration) and its target feature models can be deduced from the ConfigurableContainer being configured by applying the same rules as defined for InternalBinding.
 * 
 * Semantics:
 * The ContainerConfiguration specifies a concrete configuration of the variable content of a ConfigurableContainer.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.ContainerConfiguration</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ContainerConfiguration#getConfiguredContainer <em>Configured Container</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getContainerConfiguration()
 * @model annotation="MetaData guid='{96519B1A-EE71-45bd-8195-DAE4A16B08D7}' id='102' EA\040name='ContainerConfiguration'"
 *        extendedMetaData="name='CONTAINER-CONFIGURATION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONTAINER-CONFIGURATIONS'"
 * @generated
 */
public interface ContainerConfiguration extends ConfigurationDecisionModel {
	/**
	 * Returns the value of the '<em><b>Configured Container</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Configured Container</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Configured Container</em>' reference.
	 * @see #setConfiguredContainer(ConfigurableContainer)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getContainerConfiguration_ConfiguredContainer()
	 * @model required="true"
	 *        annotation="MetaData guid='{06F498B0-DCBA-46c0-B523-BD1DB7AEFE04}' id='487' EA\040name=''"
	 *        extendedMetaData="name='CONFIGURED-CONTAINER-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURED-CONTAINER-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	ConfigurableContainer getConfiguredContainer();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ContainerConfiguration#getConfiguredContainer <em>Configured Container</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Configured Container</em>' reference.
	 * @see #getConfiguredContainer()
	 * @generated
	 */
	void setConfiguredContainer(ConfigurableContainer value);

} // ContainerConfiguration
