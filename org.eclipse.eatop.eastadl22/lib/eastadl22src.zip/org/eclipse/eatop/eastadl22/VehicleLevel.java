/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vehicle Level</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The VehicleLevel represents the vehicle content from an external perspective through an arbitrary set of feature models. These contain VehicleFeatures that are organized to reflect the vehicle configuration and that have associated requirements, use cases, etc. for its definition.
 * 
 * Constraints:
 * [1] All contained feature models are FeatureModels that only contain VehicleFeatures.
 * 
 * Semantics:
 * The VehicleLevel represents the vehicle content through solution-independent features.
 * 
 * Notation:
 * The VehicleLevel is shown as a solid-outline rectangle containing the name. Contained entities may be shown (White-box view).
 * 
 * Extension: class.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.SystemModeling.VehicleLevel</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleLevel#getTechnicalFeatureModel <em>Technical Feature Model</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleLevel()
 * @model annotation="MetaData guid='{2E415077-DFCA-4f4c-B10B-02FDD889EC2C}' id='18' EA\040name='VehicleLevel'"
 *        annotation="Stereotype Stereotype='atpStructureElement'"
 *        extendedMetaData="name='VEHICLE-LEVEL' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VEHICLE-LEVELS'"
 * @generated
 */
public interface VehicleLevel extends Context {
	/**
	 * Returns the value of the '<em><b>Technical Feature Model</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FeatureModel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Technical Feature Model</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Technical Feature Model</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleLevel_TechnicalFeatureModel()
	 * @model containment="true"
	 *        annotation="MetaData guid='{6DA2505B-0C5B-4245-9186-ACEBB3303220}' id='737' EA\040name=''"
	 *        extendedMetaData="name='TECHNICAL-FEATURE-MODEL' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TECHNICAL-FEATURE-MODELS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<FeatureModel> getTechnicalFeatureModel();

} // VehicleLevel
