/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Use Case</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A UseCase specifies a usage of a system. Typically, they are used to capture the functionality of a system, that is, what a system is supposed to do.
 * 
 * Semantics:
 * A UseCase identifies a usage of its corresponding system. ExtensionPoint identifies where the use case can be extended with extend UseCases and include identifies UseCases inserted in the including UseCase.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.UseCases.UseCase</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.UseCase#getInteract <em>Interact</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.UseCase#getExtend <em>Extend</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.UseCase#getInclude <em>Include</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.UseCase#getExtensionPoint <em>Extension Point</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getUseCase()
 * @model annotation="MetaData guid='{2A1AB0FC-F92F-4954-BA09-3104239329F2}' id='126' EA\040name='UseCase'"
 *        extendedMetaData="name='USE-CASE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='USE-CASES'"
 * @generated
 */
public interface UseCase extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Interact</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Interact}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interact</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interact</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getUseCase_Interact()
	 * @model containment="true"
	 *        annotation="MetaData guid='{6F3FA70A-9B5C-4325-B53D-14025F265ECB}' id='785' EA\040name=''"
	 *        extendedMetaData="name='INTERACT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INTERACTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Interact> getInteract();

	/**
	 * Returns the value of the '<em><b>Extend</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Extend}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Extend</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extend</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getUseCase_Extend()
	 * @model containment="true"
	 *        annotation="MetaData guid='{98752442-8CD7-4ce9-97BD-4EE722910FD6}' id='424' EA\040name=''"
	 *        extendedMetaData="name='EXTEND' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTENDS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Extend> getExtend();

	/**
	 * Returns the value of the '<em><b>Include</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Include}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Include</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Include</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getUseCase_Include()
	 * @model containment="true"
	 *        annotation="MetaData guid='{88770EAB-5C44-4560-AD5E-12048A418270}' id='428' EA\040name=''"
	 *        extendedMetaData="name='INCLUDE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INCLUDES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Include> getInclude();

	/**
	 * Returns the value of the '<em><b>Extension Point</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ExtensionPoint}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Extension Point</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extension Point</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getUseCase_ExtensionPoint()
	 * @model containment="true"
	 *        annotation="MetaData guid='{BB4990E1-7483-47e9-A392-399F36EC8357}' id='432' EA\040name=''"
	 *        extendedMetaData="name='EXTENSION-POINT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTENSION-POINTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ExtensionPoint> getExtensionPoint();

} // UseCase
