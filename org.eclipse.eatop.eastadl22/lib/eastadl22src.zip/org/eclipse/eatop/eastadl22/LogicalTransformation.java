/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Logical Transformation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A logical transformation (LogicalTransformation) is a set of restrictions on the computation activity for some data. That is, given some in-&amp;local-data that meet certain preconditions, such a computation activity always maps such data to some out-data that meet the related postconditions if the time-&amp;value-invariants are not violated during the computation.
 * 
 * Each computation activity executes some functions for the mapping of quantities, which can be based on arithmetic, Boolean- or string-related calculations. The expressions (Expression) for any further lower level details of a transformation can be based on an external language, such as the MISRA-C.
 * 
 * A logical transformation can define the following conditions of computation activity:
 * 
 * 1. The pre-conditions, i.e. the quantifications that must be satisfied just prior to data-processing,
 * 2. The value-invariants, i.e. the value conditions that must be satisfied throughout the execution of data-processing,
 * 3. The time-invariants, i.e. the time conditions that must be satisfied throughout the execution of data-processing,
 * 4. The post-conditions, i.e. the quantifications that must be satisfied just after the execution of data-processing.
 * 
 * Constraints:
 * [1] If a logical transformation description is applied to a client-server interface (isClientServerInterface=true), it has at least one corresponding operation specified in a client-server interface definition (FunctionModelling::Operation). 
 * 
 * Semantics:
 * The computation activity of a logical transformation can be activated in logical paths or in state transitions. The execution follows the run-to-completion assumption. This means that the execution is only possible when the previous execution instance of the same transformation is fully completed. For a system function, the amount of time to execute its transformations is constrained by the EAST-ADL function event in the timing package.
 * 
 * Extension: 
 * EAElement.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.ComputationConstraint.LogicalTransformation</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getIsClientServerInterface <em>Is Client Server Interface</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getExpression <em>Expression</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getTimeInvariant <em>Time Invariant</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getPostCondition <em>Post Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getPreCondition <em>Pre Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getQuantificationInvariant <em>Quantification Invariant</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getIn <em>In</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getOut <em>Out</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getContained <em>Contained</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getClientServerInterfaceOperation <em>Client Server Interface Operation</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation()
 * @model annotation="MetaData guid='{6FCB8660-8F6C-4b52-8652-19C783A2DF7F}' id='313' EA\040name='LogicalTransformation'"
 *        extendedMetaData="name='LOGICAL-TRANSFORMATION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOGICAL-TRANSFORMATIONS'"
 * @generated
 */
public interface LogicalTransformation extends EAElement {
	/**
	 * Returns the value of the '<em><b>Is Client Server Interface</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Client Server Interface</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Client Server Interface</em>' attribute.
	 * @see #isSetIsClientServerInterface()
	 * @see #unsetIsClientServerInterface()
	 * @see #setIsClientServerInterface(Boolean)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_IsClientServerInterface()
	 * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Boolean" required="true"
	 *        annotation="MetaData guid='{337D6F1B-5384-4206-BABA-2A794FEAD482}' id='213' EA\040name='isClientServerInterface'"
	 *        extendedMetaData="name='IS-CLIENT-SERVER-INTERFACE' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-CLIENT-SERVER-INTERFACES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Boolean getIsClientServerInterface();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getIsClientServerInterface <em>Is Client Server Interface</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Client Server Interface</em>' attribute.
	 * @see #isSetIsClientServerInterface()
	 * @see #IsClientServerInterface()
	 * @see #getIsClientServerInterface()
	 * @generated
	 */
	void setIsClientServerInterface(Boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getIsClientServerInterface <em>Is Client Server Interface</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsClientServerInterface()
	 * @see #getIsClientServerInterface()
	 * @see #setIsClientServerInterface(Boolean)
	 * @generated
	 */
	void unsetIsClientServerInterface();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getIsClientServerInterface <em>Is Client Server Interface</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Client Server Interface</em>' attribute is set.
	 * @see #IsClientServerInterface()
	 * @see #getIsClientServerInterface()
	 * @see #setIsClientServerInterface(Boolean)
	 * @generated
	 */
	boolean isSetIsClientServerInterface();

	/**
	 * Returns the value of the '<em><b>Expression</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Expression</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Expression</em>' containment reference.
	 * @see #setExpression(EAExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_Expression()
	 * @model containment="true"
	 *        annotation="MetaData guid='{07AD2E88-A56A-4daa-86BE-E7E1501E7D5F}' id='99' EA\040name=''"
	 *        extendedMetaData="name='EXPRESSION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXPRESSIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EAExpression getExpression();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getExpression <em>Expression</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Expression</em>' containment reference.
	 * @see #getExpression()
	 * @generated
	 */
	void setExpression(EAExpression value);

	/**
	 * Returns the value of the '<em><b>Time Invariant</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time Invariant</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time Invariant</em>' reference.
	 * @see #setTimeInvariant(LogicalTimeCondition)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_TimeInvariant()
	 * @model annotation="MetaData guid='{9482405C-4501-4246-B9A3-983BA5706963}' id='37' EA\040name=''"
	 *        extendedMetaData="name='TIME-INVARIANT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIME-INVARIANT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	LogicalTimeCondition getTimeInvariant();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTransformation#getTimeInvariant <em>Time Invariant</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time Invariant</em>' reference.
	 * @see #getTimeInvariant()
	 * @generated
	 */
	void setTimeInvariant(LogicalTimeCondition value);

	/**
	 * Returns the value of the '<em><b>Post Condition</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Quantification}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Post Condition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Post Condition</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_PostCondition()
	 * @model annotation="MetaData guid='{BC993E8C-1F26-49cf-9A68-3CB84532E5AE}' id='44' EA\040name=''"
	 *        extendedMetaData="name='POST-CONDITION-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='POST-CONDITION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Quantification> getPostCondition();

	/**
	 * Returns the value of the '<em><b>Pre Condition</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Quantification}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pre Condition</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pre Condition</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_PreCondition()
	 * @model annotation="MetaData guid='{BAA94FF2-C371-4cd0-8CC7-2B55ACCC71E1}' id='45' EA\040name=''"
	 *        extendedMetaData="name='PRE-CONDITION-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRE-CONDITION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Quantification> getPreCondition();

	/**
	 * Returns the value of the '<em><b>Quantification Invariant</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Quantification}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Quantification Invariant</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Quantification Invariant</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_QuantificationInvariant()
	 * @model annotation="MetaData guid='{04BF149A-B2C4-42b4-810A-A7F5C6E4A1D9}' id='50' EA\040name=''"
	 *        extendedMetaData="name='QUANTIFICATION-INVARIANT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='QUANTIFICATION-INVARIANT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Quantification> getQuantificationInvariant();

	/**
	 * Returns the value of the '<em><b>In</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Attribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>In</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>In</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_In()
	 * @model annotation="MetaData guid='{76E80BA2-3D32-42e9-B0E5-10826A690FCB}' id='51' EA\040name=''"
	 *        extendedMetaData="name='IN-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IN-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Attribute> getIn();

	/**
	 * Returns the value of the '<em><b>Out</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Attribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Out</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Out</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_Out()
	 * @model annotation="MetaData guid='{68DAA475-9809-4519-8CFA-848F32DB9B59}' id='53' EA\040name=''"
	 *        extendedMetaData="name='OUT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OUT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Attribute> getOut();

	/**
	 * Returns the value of the '<em><b>Contained</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Attribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Contained</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contained</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_Contained()
	 * @model annotation="MetaData guid='{4356CD35-0779-4eec-8ACC-25DFB4F5C325}' id='54' EA\040name=''"
	 *        extendedMetaData="name='CONTAINED-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONTAINED-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Attribute> getContained();

	/**
	 * Returns the value of the '<em><b>Client Server Interface Operation</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Operation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Client Server Interface Operation</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Client Server Interface Operation</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTransformation_ClientServerInterfaceOperation()
	 * @model annotation="MetaData guid='{E56C64E1-6B80-4e84-A81A-803903972B6C}' id='649' EA\040name=''"
	 *        extendedMetaData="name='CLIENT-SERVER-INTERFACE-OPERATION-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CLIENT-SERVER-INTERFACE-OPERATION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Operation> getClientServerInterfaceOperation();

} // LogicalTransformation
