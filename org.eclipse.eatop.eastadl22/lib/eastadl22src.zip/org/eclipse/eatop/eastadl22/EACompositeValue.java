/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EA Composite Value</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Used to model values in a record.
 * 
 * Constraints:
 * [1] Shall be typed by an CompositeDatatype.
 * [2] The values in this EACompositeValue shall be typed and ordered in the same way as the EADatatypePrototypes in the typing CompositeDatatype.
 * 
 * Semantics:
 * The semantics of this value is defined by the element typed by the typing CompositeDatatype.
 * 
 * Extension:
 * UML2:LiteralSpecification
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Infrastructure.Values.EACompositeValue</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.EACompositeValue#getValue <em>Value</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEACompositeValue()
 * @model annotation="MetaData guid='{C75CA405-1DF7-4732-8BA9-35E62A0A6BD3}' id='277' EA\040name='EACompositeValue'"
 *        extendedMetaData="name='EA-COMPOSITE-VALUE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EA-COMPOSITE-VALUES'"
 * @generated
 */
public interface EACompositeValue extends EAValue {
	/**
	 * Returns the value of the '<em><b>Value</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.EAValue}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEACompositeValue_Value()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{FAE9286C-FBCF-4759-9DC8-A6CCF7104286}' id='84' EA\040name=''"
	 *        extendedMetaData="name='VALUE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VALUES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<EAValue> getValue();

} // EACompositeValue
