/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EA Array Value</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Used to hold the values in an array.
 * 
 * Constraints:
 * [1] Shall be typed by an ArrayDatatype.
 * 
 * Extension:
 * UML2:LiteralSpecification
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Infrastructure.Values.EAArrayValue</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.EAArrayValue#getValue <em>Value</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEAArrayValue()
 * @model annotation="MetaData guid='{522E6AF4-A0B3-4606-9FA4-75131A3115EC}' id='274' EA\040name='EAArrayValue'"
 *        extendedMetaData="name='EA-ARRAY-VALUE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EA-ARRAY-VALUES'"
 * @generated
 */
public interface EAArrayValue extends EAValue {
	/**
	 * Returns the value of the '<em><b>Value</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.EAValue}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEAArrayValue_Value()
	 * @model containment="true"
	 *        annotation="MetaData guid='{7A58A32F-F269-4dc4-884F-EFF0BD7E8D0F}' id='94' EA\040name=''"
	 *        extendedMetaData="name='VALUE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VALUES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<EAValue> getValue();

} // EAArrayValue
