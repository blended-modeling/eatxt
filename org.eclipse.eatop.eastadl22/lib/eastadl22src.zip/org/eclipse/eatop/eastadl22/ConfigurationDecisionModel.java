/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Configuration Decision Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A ConfigurationDecisionModel defines how to configure m target feature models, depending on a given configuration of n source feature models, thus establishing a configuration-related link from the n source feature models to the m target feature models (also called configuration link). With the information captured in a ConfigurationDecisionModel it is then possible to transform a given set of source configurations (one for every source feature model) into corresponding target configurations (one for every target feature model).
 * 
 * For example, a ConfigurationDecisionModel can capture information such as "if feature 'S-Class' is selected in the source feature model, then select feature 'RainSensor' in the target feature model" or "if feature 'USA' is selected in the source feature model, then select feature 'CupHolder' in the target feature model".
 * 
 * Note that in principle all ConfigurationDecisionModels have source / target feature models. However, they are only defined explicitly for those used on vehicle level; for ConfigurationDecisionModels used as an internal binding on FunctionTypes, the source and target feature models are defined implicitly (cf. metaclass InternalBinding). In addition, in the special case of FeatureConfiguration there is by definition no source and only a single target feature model, which is defined explicitly (cf. metaclass FeatureConfiguration).
 * 
 * The configuration information captured in a ConfigurationDecisionModel is represented by ConfigurationDecisions, each of which captures a single, atomized rule on how to configure the target feature model(s) depending on a given configuration of the source feature model(s).
 * 
 * Semantics:
 * See description.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.ConfigurationDecisionModel</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurationDecisionModel#getRootEntry <em>Root Entry</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecisionModel()
 * @model abstract="true"
 *        annotation="MetaData guid='{6A82AFBD-8DB3-4241-9609-A5D5DD230CB2}' id='98' EA\040name='ConfigurationDecisionModel'"
 *        extendedMetaData="name='CONFIGURATION-DECISION-MODEL' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURATION-DECISION-MODELS'"
 * @generated
 */
public interface ConfigurationDecisionModel extends EAElement {
	/**
	 * Returns the value of the '<em><b>Root Entry</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ConfigurationDecisionModelEntry}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Root Entry</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Root Entry</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecisionModel_RootEntry()
	 * @model containment="true"
	 *        annotation="MetaData guid='{FDDC6ED4-F621-4dfc-8E7A-0D44DB031662}' id='492' EA\040name=''"
	 *        extendedMetaData="name='ROOT-ENTRY' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ROOT-ENTRYS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ConfigurationDecisionModelEntry> getRootEntry();

} // ConfigurationDecisionModel
