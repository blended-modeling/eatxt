/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Function Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * FunctionBehavior represents the behavior of a particular FunctionType - referred to by the association to FunctionType. What is meant by behavior is a transfer function performing some data computation (in case of FlowPort interaction) or an operation that can be called by another function (in case of ClientServer interaction). The representation property indicates the kind of representation used to describe the behavior (see FunctionBehaviorKind). The representation itself (e.g., defined in an external model file) is identified by a URL String in the path property. If the representation is provided in the same model file as the system itself, the path property is not used. It is merely a placeholder for the purpose of containing information about and links to the external behavioral model.
 * 
 * FunctionBehavior may refer to execution modes by the association to the element Mode. This is not mandatory; however, when provided, the relation indicates the list of execution Modes in which the FunctionBehavior can potentially be executed (see element Mode).
 * 
 * The triggering of a FunctionBehavior is unknown to the behavior. It is defined by FunctionTriggers (see this element).
 * 
 * Note that the association between FunctionBehavior and FunctionType is specified as a one-way navigable link from FunctionBehavior to FunctionType: what this means is that the EAST-ADL language specification does not require a FunctionType be aware of the FunctionBehavior it is assigned to. Only the navigation from behavior to function is mandatory; the implementation of a reverse link might however be provided depending on the tool support.
 * 
 * Although each FunctionBehavior can refer to at most one FunctionType, note that several FunctionBehaviors can refer to the same FunctionType. In this case, when a FunctionType has several behaviors, only one behavior shall be active at any given time instant, i.e., no concurrent behaviors are allowed in EAST-ADL functions. For instance we cannot have one active behavior in Simulink and one in Modelica. Both can be referenced in the same function, but at any given time, only one is executable. Conditions such as modes and variability must prevent two behaviors being potentially active at the same time.
 * 
 * Note also that FunctionBehaviors are assigned to FunctionTypes and not to FunctionPrototypes. This means that among a set of FunctionPrototypes, which share the same type, behaviors are also shared. However when a FunctionBehavior refer to Modes, which are referred to by different FunctionTriggers, different triggering conditions can be provided among a set of FunctionPrototypes for the same set of behaviors - see FunctionTrigger.
 * 
 * In the case where the identified FunctionType is decomposed into parts, the behavior is a specification for the composed behavior of the FunctionType. 
 * 
 * 
 * Semantics:
 * The semantics of FunctionBehavior follows the semantics of the behavioral representation/tool used (for instance SIMULINK, ASCET, etc.). However, in relation to the EAST-ADL model, the FunctionBehavior has synchronous execution semantics:
 * 
 * 1. Read inputs from input ports
 * 2. Execute behavior with fixed inputs (run to completion)
 * 3. Provide outputs to output ports
 * 
 * The data transfer between the EAST-ADL ports and the FunctionBehavior is representation/tool-specific and considered part of the execution of the FunctionBehavior.
 * 
 * 
 * Notation:
 * FunctionBehavior appears as a solid-outline rectangle with "Behavior" at the top right. The rectangle contains the name. 
 * 
 * 
 * Extension: Behavior
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Behavior.FunctionBehavior</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getPath <em>Path</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getRepresentation <em>Representation</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getMode <em>Mode</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getFunction <em>Function</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionBehavior()
 * @model annotation="MetaData guid='{D49E3D16-69E7-4b31-80FC-ED9CE191F6E9}' id='88' EA\040name='FunctionBehavior'"
 *        extendedMetaData="name='FUNCTION-BEHAVIOR' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-BEHAVIORS'"
 * @generated
 */
public interface FunctionBehavior extends Context {
	/**
	 * Returns the value of the '<em><b>Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The path to the file or model entity containing the behavior.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Path</em>' attribute.
	 * @see #isSetPath()
	 * @see #unsetPath()
	 * @see #setPath(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionBehavior_Path()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String" required="true"
	 *        annotation="MetaData guid='{FEA18BEB-8C1F-4a0e-B2A9-E43A816B7D8D}' id='74' EA\040name='path'"
	 *        extendedMetaData="name='PATH' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PATHS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getPath();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getPath <em>Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Path</em>' attribute.
	 * @see #isSetPath()
	 * @see #Path()
	 * @see #getPath()
	 * @generated
	 */
	void setPath(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getPath <em>Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetPath()
	 * @see #getPath()
	 * @see #setPath(String)
	 * @generated
	 */
	void unsetPath();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getPath <em>Path</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Path</em>' attribute is set.
	 * @see #Path()
	 * @see #getPath()
	 * @see #setPath(String)
	 * @generated
	 */
	boolean isSetPath();

	/**
	 * Returns the value of the '<em><b>Representation</b></em>' attribute.
	 * The default value is <code>"SIMULINK"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.FunctionBehaviorKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The type of representation used to describe the behavior.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Representation</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.FunctionBehaviorKind
	 * @see #isSetRepresentation()
	 * @see #unsetRepresentation()
	 * @see #setRepresentation(FunctionBehaviorKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionBehavior_Representation()
	 * @model default="SIMULINK" unsettable="true" required="true"
	 *        annotation="MetaData guid='{CC537526-006C-4520-8B44-60D624AA9724}' id='75' EA\040name='representation'"
	 *        extendedMetaData="name='REPRESENTATION' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REPRESENTATIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FunctionBehaviorKind getRepresentation();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getRepresentation <em>Representation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Representation</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.FunctionBehaviorKind
	 * @see #isSetRepresentation()
	 * @see #Representation()
	 * @see #getRepresentation()
	 * @generated
	 */
	void setRepresentation(FunctionBehaviorKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getRepresentation <em>Representation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetRepresentation()
	 * @see #getRepresentation()
	 * @see #setRepresentation(FunctionBehaviorKind)
	 * @generated
	 */
	void unsetRepresentation();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getRepresentation <em>Representation</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Representation</em>' attribute is set.
	 * @see #Representation()
	 * @see #getRepresentation()
	 * @see #setRepresentation(FunctionBehaviorKind)
	 * @generated
	 */
	boolean isSetRepresentation();

	/**
	 * Returns the value of the '<em><b>Mode</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Mode}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mode</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mode</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionBehavior_Mode()
	 * @model annotation="MetaData guid='{A8F00DBB-9438-454c-BAFB-53B9AA27EC71}' id='527' EA\040name=''"
	 *        extendedMetaData="name='MODE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Mode> getMode();

	/**
	 * Returns the value of the '<em><b>Function</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function</em>' reference.
	 * @see #setFunction(FunctionType)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionBehavior_Function()
	 * @model annotation="MetaData guid='{37C8854A-9072-43cb-A1F0-BE61089C2D10}' id='647' EA\040name=''"
	 *        extendedMetaData="name='FUNCTION-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FunctionType getFunction();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FunctionBehavior#getFunction <em>Function</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function</em>' reference.
	 * @see #getFunction()
	 * @generated
	 */
	void setFunction(FunctionType value);

} // FunctionBehavior
