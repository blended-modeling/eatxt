/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Burst Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A BurstConstraint describes an event that occurs in semi-regular bursts.
 * 
 * A BurstConstraint expresses the maximum number of event occurrences that may appear in any interval of a given length, which is equivalent to constraining the same number of repeat spans (which count one extra occurrence at the end) to have a minimum width of length.
 * 
 * Semantics:
 * A system behavior satisfies a BurstConstraint c if and only if
 * the same system behavior concurrently satisfies
 * 
 * RepeatConstraint { event = c.event,
 * lower = c.length,
 * upper = infinity,
 * span = c.maxOccurrences }
 * 
 * and
 * 
 * RepeatConstraint { event = c.event,
 * lower = c.minimum }
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.BurstConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BurstConstraint#getMaxOccurrences <em>Max Occurrences</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BurstConstraint#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BurstConstraint#getLength <em>Length</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BurstConstraint#getEvent <em>Event</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBurstConstraint()
 * @model annotation="MetaData guid='{E7CF75D2-9121-47ca-917A-9E18B099C1C0}' id='179' EA\040name='BurstConstraint'"
 *        extendedMetaData="name='BURST-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BURST-CONSTRAINTS'"
 * @generated
 */
public interface BurstConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Max Occurrences</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Occurrences</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Occurrences</em>' attribute.
	 * @see #isSetMaxOccurrences()
	 * @see #unsetMaxOccurrences()
	 * @see #setMaxOccurrences(Integer)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBurstConstraint_MaxOccurrences()
	 * @model default="0" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Integer" required="true"
	 *        annotation="MetaData guid='{23B94CA7-8561-46f4-9E45-48671737CF64}' id='111' EA\040name='maxOccurrences'"
	 *        extendedMetaData="name='MAX-OCCURRENCES' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MAX-OCCURRENCESS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Integer getMaxOccurrences();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BurstConstraint#getMaxOccurrences <em>Max Occurrences</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Occurrences</em>' attribute.
	 * @see #isSetMaxOccurrences()
	 * @see #MaxOccurrences()
	 * @see #getMaxOccurrences()
	 * @generated
	 */
	void setMaxOccurrences(Integer value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.BurstConstraint#getMaxOccurrences <em>Max Occurrences</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetMaxOccurrences()
	 * @see #getMaxOccurrences()
	 * @see #setMaxOccurrences(Integer)
	 * @generated
	 */
	void unsetMaxOccurrences();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.BurstConstraint#getMaxOccurrences <em>Max Occurrences</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Max Occurrences</em>' attribute is set.
	 * @see #MaxOccurrences()
	 * @see #getMaxOccurrences()
	 * @see #setMaxOccurrences(Integer)
	 * @generated
	 */
	boolean isSetMaxOccurrences();

	/**
	 * Returns the value of the '<em><b>Minimum</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Minimum</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Minimum</em>' containment reference.
	 * @see #setMinimum(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBurstConstraint_Minimum()
	 * @model containment="true"
	 *        annotation="MetaData guid='{B0FD7A43-BA0F-405d-8E29-ED9D43179FC8}' id='302' EA\040name=''"
	 *        extendedMetaData="name='MINIMUM' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MINIMUMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getMinimum();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BurstConstraint#getMinimum <em>Minimum</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Minimum</em>' containment reference.
	 * @see #getMinimum()
	 * @generated
	 */
	void setMinimum(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Length</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Length</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Length</em>' containment reference.
	 * @see #setLength(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBurstConstraint_Length()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{3212BF0C-05FE-4880-AB89-CA2A50F5A47B}' id='321' EA\040name=''"
	 *        extendedMetaData="name='LENGTH' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LENGTHS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getLength();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BurstConstraint#getLength <em>Length</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Length</em>' containment reference.
	 * @see #getLength()
	 * @generated
	 */
	void setLength(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Event</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' reference.
	 * @see #setEvent(Event)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBurstConstraint_Event()
	 * @model required="true"
	 *        annotation="MetaData guid='{9B867708-D9C1-4085-BA22-2D48F2B4F5C2}' id='367' EA\040name=''"
	 *        extendedMetaData="name='EVENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Event getEvent();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BurstConstraint#getEvent <em>Event</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event</em>' reference.
	 * @see #getEvent()
	 * @generated
	 */
	void setEvent(Event value);

} // BurstConstraint
