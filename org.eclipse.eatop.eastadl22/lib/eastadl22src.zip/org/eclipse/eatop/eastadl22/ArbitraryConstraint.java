/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arbitrary Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An ArbitraryConstraint describes an event that occurs irregularly.
 * 
 * An ArbitraryConstraint is equivalent to a combination of Repeat constraints, each one constraining sequences of i+1 occurrences (that is, i repetition spans), with i ranging from 1 to some given n.
 * 
 * Constraints:
 * [1] The number of elements in minimum and maximum must be equal.
 * 
 * Semantics:
 * A system behavior satisfies an AribtraryConstraint c if and only if
 * for each c.minimum index i, the same system behavior satisfies
 * 
 * RepeatConstraint { event = c.event,
 * lower = c.minimum(i),
 * upper = c.maximum(i),
 * span = i  }
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.ArbitraryConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ArbitraryConstraint#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ArbitraryConstraint#getMaximum <em>Maximum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ArbitraryConstraint#getEvent <em>Event</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArbitraryConstraint()
 * @model annotation="MetaData guid='{BB4E5BBF-2D50-4312-9002-5945B3934AED}' id='175' EA\040name='ArbitraryConstraint'"
 *        extendedMetaData="name='ARBITRARY-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ARBITRARY-CONSTRAINTS'"
 * @generated
 */
public interface ArbitraryConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Minimum</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.TimingExpression}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Minimum</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Minimum</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArbitraryConstraint_Minimum()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{AA52D4D0-83F4-44cc-94CB-D5263BAB7BCE}' id='303' EA\040name=''"
	 *        extendedMetaData="name='MINIMUM' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MINIMUMS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<TimingExpression> getMinimum();

	/**
	 * Returns the value of the '<em><b>Maximum</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.TimingExpression}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Maximum</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Maximum</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArbitraryConstraint_Maximum()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{13EB992F-E4F5-43cf-8C08-115E5AF8D300}' id='323' EA\040name=''"
	 *        extendedMetaData="name='MAXIMUM' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MAXIMUMS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<TimingExpression> getMaximum();

	/**
	 * Returns the value of the '<em><b>Event</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' reference.
	 * @see #setEvent(Event)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArbitraryConstraint_Event()
	 * @model required="true"
	 *        annotation="MetaData guid='{41C95482-E206-4eb1-A3D8-36A887E74384}' id='378' EA\040name=''"
	 *        extendedMetaData="name='EVENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Event getEvent();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ArbitraryConstraint#getEvent <em>Event</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event</em>' reference.
	 * @see #getEvent()
	 * @generated
	 */
	void setEvent(Event value);

} // ArbitraryConstraint
