/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Binding Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * BehaviorConstraintBindingEvent is a specialization of BehaviorConstraintBindingParameter. 
 * 
 * It allows a behavior constraint type to declare the value attributes to be shared of its prototypes. 
 * 
 * See also BehaviorConstraintBindingParameter.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.BehaviorConstraintBindingAttribute</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintBindingAttribute()
 * @model annotation="MetaData guid='{5D32EC02-81B6-47f0-B1D2-7961AB3E9EBB}' id='293' EA\040name='BehaviorConstraintBindingAttribute'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-BINDING-ATTRIBUTE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-BINDING-ATTRIBUTES'"
 * @generated
 */
public interface BehaviorConstraintBindingAttribute extends Attribute, BehaviorConstraintInternalBinding {
} // BehaviorConstraintBindingAttribute
