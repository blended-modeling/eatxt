/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AUTOSAR Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An AUTOSAREvent instance refers to an event of the form defined by AUTOSAR.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.Events.AUTOSAREvent</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAUTOSAREvent()
 * @model annotation="MetaData guid='{B33E83F0-0EC4-459e-9A5B-B1E36CAAB35A}' id='155' EA\040name='AUTOSAREvent'"
 *        extendedMetaData="name='AUTOSAR-EVENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='AUTOSAR-EVENTS'"
 * @generated
 */
public interface AUTOSAREvent extends Event {
} // AUTOSAREvent
