/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VV Intended Outcome</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * VVIntendedOutcome represents the expected output of the testing environment represented by VVTarget when triggered by the corresponding VVStimuli of the containing concrete VVProcedure.
 * 
 * Since this entity only occurs on the concrete level (i.e. within the context of a concrete VVCase), the output must be provided in a form that can be directly compared to the output of the VVTarget(s) defined for the containing concrete VVCase.
 * 
 * Semantics:
 * VVIntendedOutcome represents the expected output of a Verification/Validation effort.
 * 
 * Extension: Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.VerificationValidation.VVIntendedOutcome</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVIntendedOutcome()
 * @model annotation="MetaData guid='{7F11E8C3-D7EE-4373-B3AD-47B39A28DE5F}' id='134' EA\040name='VVIntendedOutcome'"
 *        extendedMetaData="name='VV-INTENDED-OUTCOME' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-INTENDED-OUTCOMES'"
 * @generated
 */
public interface VVIntendedOutcome extends TraceableSpecification {
} // VVIntendedOutcome
