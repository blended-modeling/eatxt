/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Quality Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * QualityRequirements or non-functional requirements are used to introduce externally visible properties of the system considered as a whole. They specify criteria that can be used to judge the operation of a system. As opposed to a functional requirement specifying what a system is supposed to do, the non-functional requirements define how a system is supposed to be.
 * 
 * The attribute qualityRequirementType allows a more specific classification.
 * 
 * Semantics:
 * A QualityRequirement element represents a requirement which is non-functional.
 * 
 * Extension: 
 * Class, specializes Requirement
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.QualityRequirement</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.QualityRequirement#getKind <em>Kind</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getQualityRequirement()
 * @model annotation="MetaData guid='{1D04ACA0-73BB-440a-A10E-E051AA237AEF}' id='109' EA\040name='QualityRequirement'"
 *        extendedMetaData="name='QUALITY-REQUIREMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='QUALITY-REQUIREMENTS'"
 * @generated
 */
public interface QualityRequirement extends Requirement {
	/**
	 * Returns the value of the '<em><b>Kind</b></em>' attribute.
	 * The default value is <code>"AVAILABILITY"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.QualityRequirementKind}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Kind</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Kind</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.QualityRequirementKind
	 * @see #isSetKind()
	 * @see #unsetKind()
	 * @see #setKind(QualityRequirementKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getQualityRequirement_Kind()
	 * @model default="AVAILABILITY" unsettable="true" required="true"
	 *        annotation="MetaData guid='{008AF2A5-3068-4f7b-B571-40BDF856452E}' id='99' EA\040name='kind'"
	 *        extendedMetaData="name='KIND' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='KINDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	QualityRequirementKind getKind();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.QualityRequirement#getKind <em>Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Kind</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.QualityRequirementKind
	 * @see #isSetKind()
	 * @see #Kind()
	 * @see #getKind()
	 * @generated
	 */
	void setKind(QualityRequirementKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.QualityRequirement#getKind <em>Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetKind()
	 * @see #getKind()
	 * @see #setKind(QualityRequirementKind)
	 * @generated
	 */
	void unsetKind();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.QualityRequirement#getKind <em>Kind</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Kind</em>' attribute is set.
	 * @see #Kind()
	 * @see #getKind()
	 * @see #setKind(QualityRequirementKind)
	 * @generated
	 */
	boolean isSetKind();

} // QualityRequirement
