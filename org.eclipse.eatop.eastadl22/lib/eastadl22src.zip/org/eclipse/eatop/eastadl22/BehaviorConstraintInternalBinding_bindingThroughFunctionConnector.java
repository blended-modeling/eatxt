/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Internal Binding binding Through Function Connector</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription._instanceRef.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector#getFunctionPrototype <em>Function Prototype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector#getFunctionConnector <em>Function Connector</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding_bindingThroughFunctionConnector()
 * @model annotation="MetaData guid='{14ECFF0C-D6C1-4c43-8DD9-649EEECF99D7}' id='302' EA\040name='BehaviorConstraintInternalBinding_bindingThroughFunctionConnector'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='BEHAVIOR-CONSTRAINT-INTERNAL-BINDING--BINDING-THROUGH-FUNCTION-CONNECTOR-IREF'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-INTERNAL-BINDING--BINDING-THROUGH-FUNCTION-CONNECTOR-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-INTERNAL-BINDING--BINDING-THROUGH-FUNCTION-CONNECTOR-IREFS'"
 * @generated
 */
public interface BehaviorConstraintInternalBinding_bindingThroughFunctionConnector extends EObject {
	/**
	 * Returns the value of the '<em><b>Function Prototype</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Prototype</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Prototype</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding_bindingThroughFunctionConnector_FunctionPrototype()
	 * @model annotation="MetaData guid='{53149C71-F701-4813-B164-4B24F89BED26}' id='628' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.context'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='FUNCTION-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FunctionPrototype> getFunctionPrototype();

	/**
	 * Returns the value of the '<em><b>Function Connector</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Connector</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Connector</em>' reference.
	 * @see #setFunctionConnector(FunctionConnector)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding_bindingThroughFunctionConnector_FunctionConnector()
	 * @model required="true"
	 *        annotation="MetaData guid='{33696CD7-6724-4890-B699-BB6200CE1309}' id='658' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.target'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='FUNCTION-CONNECTOR-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-CONNECTOR-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FunctionConnector getFunctionConnector();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector#getFunctionConnector <em>Function Connector</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function Connector</em>' reference.
	 * @see #getFunctionConnector()
	 * @generated
	 */
	void setFunctionConnector(FunctionConnector value);

} // BehaviorConstraintInternalBinding_bindingThroughFunctionConnector
