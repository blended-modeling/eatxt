/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Non Concurrent Constraint exclusive</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing._instanceRef.NonConcurrentConstraint_exclusive</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.NonConcurrentConstraint_exclusive#getNameWasNotSet_0 <em>Name Was Not Set 0</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.NonConcurrentConstraint_exclusive#getNameWasNotSet_1 <em>Name Was Not Set 1</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getNonConcurrentConstraint_exclusive()
 * @model annotation="MetaData guid='{F24B847C-AA99-4890-B8AC-900EF32372A4}' id='336' EA\040name='NonConcurrentConstraint_exclusive'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='NON-CONCURRENT-CONSTRAINT--EXCLUSIVE-IREF'"
 *        extendedMetaData="name='NON-CONCURRENT-CONSTRAINT--EXCLUSIVE-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='NON-CONCURRENT-CONSTRAINT--EXCLUSIVE-IREFS'"
 * @generated
 */
public interface NonConcurrentConstraint_exclusive extends EObject {
	/**
	 * Returns the value of the '<em><b>Name Was Not Set 0</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Was Not Set 0</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Was Not Set 0</em>' reference.
	 * @see #setNameWasNotSet_0(FunctionPrototype)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getNonConcurrentConstraint_exclusive_NameWasNotSet_0()
	 * @model required="true"
	 *        annotation="MetaData guid='{17BAB99D-8058-402d-8F87-0ECD5F688588}' id='773' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.target'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='NAME-WAS-NOT-SET-0-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='NAME-WAS-NOT-SET-0-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FunctionPrototype getNameWasNotSet_0();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.NonConcurrentConstraint_exclusive#getNameWasNotSet_0 <em>Name Was Not Set 0</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name Was Not Set 0</em>' reference.
	 * @see #getNameWasNotSet_0()
	 * @generated
	 */
	void setNameWasNotSet_0(FunctionPrototype value);

	/**
	 * Returns the value of the '<em><b>Name Was Not Set 1</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name Was Not Set 1</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name Was Not Set 1</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getNonConcurrentConstraint_exclusive_NameWasNotSet_1()
	 * @model annotation="MetaData guid='{78116AF5-B4F4-4ff1-82F9-25D2C4F7C6F2}' id='774' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.context'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='NAME-WAS-NOT-SET-1-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='NAME-WAS-NOT-SET-1-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FunctionPrototype> getNameWasNotSet_1();

} // NonConcurrentConstraint_exclusive
