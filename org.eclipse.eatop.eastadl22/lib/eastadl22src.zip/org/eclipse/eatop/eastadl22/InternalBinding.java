/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Internal Binding</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The InternalBinding is the private, internal ConfigurationDecisionModel of the ConfigurableContainer. It defines how the internal, lower-level variability of the ConfigurableContainer is bound, i.e. configured, depending on a given configuration of the ConfigurableContainer's public feature model. This way, the binding of this internal variability is encapsulated and hidden behind the public feature model, which serves as a variability-related interface.
 * 
 * Note that for this use case, the source and target feature models need not be defined explicitly because they are deduced implicitly: the ConfigurableContainer's public feature model serves as the (single) target feature model, and the source feature models are deduced from the ConfigurableContainer's internal variability (esp. other, lower-level ConfigurableContainers which are contained).
 * 
 * For a definition of the precise meaning of 'internal variability' (also called variable content) refer to the documentation of meta-class ConfigurableContainer.
 * 
 * Semantics:
 * See description.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.InternalBinding</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getInternalBinding()
 * @model annotation="MetaData guid='{6C2879A9-48A4-4d95-A52D-E580CB3FBEE0}' id='99' EA\040name='InternalBinding'"
 *        extendedMetaData="name='INTERNAL-BINDING' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INTERNAL-BINDINGS'"
 * @generated
 */
public interface InternalBinding extends ConfigurationDecisionModel {
} // InternalBinding
