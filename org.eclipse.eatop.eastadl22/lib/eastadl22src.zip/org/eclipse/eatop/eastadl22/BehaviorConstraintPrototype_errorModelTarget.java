/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Prototype error Model Target</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription._instanceRef.BehaviorConstraintPrototype_errorModelTarget</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype_errorModelTarget#getErrorModelPrototype_context <em>Error Model Prototype context</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype_errorModelTarget#getErrorModelPrototype_target <em>Error Model Prototype target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype_errorModelTarget()
 * @model annotation="MetaData guid='{158FFB03-7C3D-4744-967A-C393CD32A96F}' id='303' EA\040name='BehaviorConstraintPrototype_errorModelTarget'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='BEHAVIOR-CONSTRAINT-PROTOTYPE--ERROR-MODEL-TARGET-IREF'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-PROTOTYPE--ERROR-MODEL-TARGET-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-PROTOTYPE--ERROR-MODEL-TARGET-IREFS'"
 * @generated
 */
public interface BehaviorConstraintPrototype_errorModelTarget extends EObject {
	/**
	 * Returns the value of the '<em><b>Error Model Prototype context</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ErrorModelPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Error Model Prototype context</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Error Model Prototype context</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype_errorModelTarget_ErrorModelPrototype_context()
	 * @model annotation="MetaData guid='{82BCB136-7A95-4ae9-882D-B8492DAFB23C}' id='224' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.context'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='ERROR-MODEL-PROTOTYPE-CONTEXT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-MODEL-PROTOTYPE-CONTEXT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<ErrorModelPrototype> getErrorModelPrototype_context();

	/**
	 * Returns the value of the '<em><b>Error Model Prototype target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Error Model Prototype target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Error Model Prototype target</em>' reference.
	 * @see #setErrorModelPrototype_target(ErrorModelPrototype)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype_errorModelTarget_ErrorModelPrototype_target()
	 * @model required="true"
	 *        annotation="MetaData guid='{6CFE108B-E3E4-4f0f-BB66-3BB0774BAA08}' id='226' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.target'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='ERROR-MODEL-PROTOTYPE-TARGET-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-MODEL-PROTOTYPE-TARGET-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	ErrorModelPrototype getErrorModelPrototype_target();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype_errorModelTarget#getErrorModelPrototype_target <em>Error Model Prototype target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Error Model Prototype target</em>' reference.
	 * @see #getErrorModelPrototype_target()
	 * @generated
	 */
	void setErrorModelPrototype_target(ErrorModelPrototype value);

} // BehaviorConstraintPrototype_errorModelTarget
