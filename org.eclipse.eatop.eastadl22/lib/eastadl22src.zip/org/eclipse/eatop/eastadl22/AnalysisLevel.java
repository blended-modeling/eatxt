/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Analysis Level</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The AnalysisLevel represents the vehicle electrical/electronic system in terms of its abstract functional definition. It includes the functional analysis architecture (FAA), which represents the functional structure.
 * 
 * Semantics:
 * AnalysisLevel represents the vehicle electrical/electronic system in terms of its abstract functional definition. It defines the logical functionality and a logical decomposition of functionality down to the appropriate granularity.
 * 
 * Notation:
 * The Analysis Architecture is shown as a solid-outline rectangle containing the name, with its ports or port groups on the perimeter. Contained entities may be shown with their connectors (White-box view).
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.SystemModeling.AnalysisLevel</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.AnalysisLevel#getFunctionalAnalysisArchitecture <em>Functional Analysis Architecture</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAnalysisLevel()
 * @model annotation="MetaData guid='{40348710-175F-4421-9CAA-2FAD1E1CA924}' id='20' EA\040name='AnalysisLevel'"
 *        annotation="Stereotype Stereotype='atpStructureElement'"
 *        extendedMetaData="name='ANALYSIS-LEVEL' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ANALYSIS-LEVELS'"
 * @generated
 */
public interface AnalysisLevel extends Context {
	/**
	 * Returns the value of the '<em><b>Functional Analysis Architecture</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Functional Analysis Architecture</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Functional Analysis Architecture</em>' containment reference.
	 * @see #setFunctionalAnalysisArchitecture(AnalysisFunctionPrototype)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAnalysisLevel_FunctionalAnalysisArchitecture()
	 * @model containment="true"
	 *        annotation="MetaData guid='{61D5867A-B6EA-49a5-ADC5-9B0CF6495AC0}' id='729' EA\040name=''"
	 *        extendedMetaData="name='FUNCTIONAL-ANALYSIS-ARCHITECTURE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTIONAL-ANALYSIS-ARCHITECTURES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	AnalysisFunctionPrototype getFunctionalAnalysisArchitecture();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.AnalysisLevel#getFunctionalAnalysisArchitecture <em>Functional Analysis Architecture</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Functional Analysis Architecture</em>' containment reference.
	 * @see #getFunctionalAnalysisArchitecture()
	 * @generated
	 */
	void setFunctionalAnalysisArchitecture(AnalysisFunctionPrototype value);

} // AnalysisLevel
