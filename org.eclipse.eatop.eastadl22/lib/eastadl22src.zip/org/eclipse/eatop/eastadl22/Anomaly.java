/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Anomaly</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The Anomaly metaclass represents a Fault that may occur internally in an ErrorModel or be propagated to it, or a Failure that is propagated out of an Error Model. The anomaly may represent different Faults or Failures depending on the range of its EADatatype. Typically, the EADatatype is an Enumeration, for example:
 * 
 * BrakeAnomaly:
 * 
 * - BrakePressureTooLow
 * 
 * Semantics="brake pressure is below 20% of requested value"
 * 
 * - Omission
 * 
 * Semantics="brake pressure is below 10% of maximal brake pressure"
 * 
 * - Comission
 * 
 * Semantics="brake pressure exceeds requested value with more than 10% of maximal brake pressure"
 * 
 * Semantics may also be a more formal expression defining in the type of the nominal datatype what value range is considered a fault. This depends on the user and tooling available.
 * 
 * 
 * Semantics:
 * An anomaly refers to a condition that deviates from expectations based on requirements specifications, design documents, user documents, standards, etc., or from someone's perceptions or experiences (ISO26262). The set of available faults or failures represented by the Anomaly is defined by its EADatatype, typically an enumeration type like {omission, commission}. It is an abstract class further specialized with metaclasses for different types of fault/failure.
 * 
 * 
 * Extension:
 * (UML::Part)
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.ErrorModel.Anomaly</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Anomaly#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAnomaly()
 * @model abstract="true"
 *        annotation="MetaData guid='{CDFE3B7E-F3DF-4e51-8496-7746D53180D4}' id='212' EA\040name='Anomaly'"
 *        annotation="Stereotype Stereotype='atpPrototype'"
 *        extendedMetaData="name='ANOMALY' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ANOMALYS'"
 * @generated
 */
public interface Anomaly extends EAElement {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' reference.
	 * @see #setType(EADatatype)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAnomaly_Type()
	 * @model required="true"
	 *        annotation="MetaData guid='{A73BD1B2-7EA5-4558-8803-8C99E71C13FF}' id='210' EA\040name=''"
	 *        annotation="Stereotype Stereotype='isOfType'"
	 *        extendedMetaData="name='TYPE-TREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TYPE-TREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EADatatype getType();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Anomaly#getType <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(EADatatype value);

} // Anomaly
