/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The Requirement represents a capability or condition that must (or should) be satisfied. A Requirement can also specify an informal constraint, e.g. "The development of the component X must be according to the standard Y", or "The realization of this function as a software component must adhere to the scope and external interface as specified by this function". It will be used to unite the common properties of specific requirement types. A Requirement may either be directly associated with a Context (by inheriting from TraceableSpecification) or it may be included in a RequirementsHierarchy, which represents a larger unit or module of specification information.
 * 
 * The traceability between Requirement entities and other specification or design entities will be ensured by the relationship dependencies described in the Infrastructure part of this specification.
 * 
 * Semantics:
 * The string in the text attribute inherited from TraceableSpecification is the capability or condition that applies to the Identifiable that is associated to the Requirement through the Satisfy relation.
 * 
 * Notation:
 * Requirement is shown as a solid rectangle with Req top right and its name.
 * 
 * Extension:
 * To specialize SysML::Requirement, which extends Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.Requirement</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Requirement#getFormalism <em>Formalism</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Requirement#getMode <em>Mode</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRequirement()
 * @model annotation="MetaData guid='{94BB3E6D-8BAE-46f7-B644-5992932FBB88}' id='113' EA\040name='Requirement'"
 *        extendedMetaData="name='REQUIREMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS'"
 * @generated
 */
public interface Requirement extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Formalism</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Specifies the language used for the requirement statement.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Formalism</em>' attribute.
	 * @see #isSetFormalism()
	 * @see #unsetFormalism()
	 * @see #setFormalism(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRequirement_Formalism()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String"
	 *        annotation="MetaData guid='{BAB2FE1F-E674-4f01-AAC2-E1DD7667E643}' id='100' EA\040name='formalism'"
	 *        extendedMetaData="name='FORMALISM' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FORMALISMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getFormalism();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Requirement#getFormalism <em>Formalism</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Formalism</em>' attribute.
	 * @see #isSetFormalism()
	 * @see #Formalism()
	 * @see #getFormalism()
	 * @generated
	 */
	void setFormalism(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.Requirement#getFormalism <em>Formalism</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetFormalism()
	 * @see #getFormalism()
	 * @see #setFormalism(String)
	 * @generated
	 */
	void unsetFormalism();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.Requirement#getFormalism <em>Formalism</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Formalism</em>' attribute is set.
	 * @see #Formalism()
	 * @see #getFormalism()
	 * @see #setFormalism(String)
	 * @generated
	 */
	boolean isSetFormalism();

	/**
	 * Returns the value of the '<em><b>Mode</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Mode}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mode</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mode</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRequirement_Mode()
	 * @model annotation="MetaData guid='{34DF21CE-B633-4a50-976F-F28BF868A4B1}' id='534' EA\040name=''"
	 *        extendedMetaData="name='MODE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Mode> getMode();

} // Requirement
