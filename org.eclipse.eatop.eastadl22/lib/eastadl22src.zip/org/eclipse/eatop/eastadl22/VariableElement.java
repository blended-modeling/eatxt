/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Variable Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * VariableElement is a marker class that marks an artifact element denoted by association optionalElement as being optional, i.e. it will not be present in all configurations of the complete system. A typical example is an optional FunctionPrototype, FunctionPort, FunctionConnector, etc. but even an optional ClampConnector, an optional UseCase or an optional requirement or constraint.
 * 
 * In addition, the VariableElement can be used to extend the EAST-ADL variability approach to other languages and standards by pointing from the VariableElement to the respective (non EAST-ADL) element with association optionalElement, thus marking the non EAST-ADL element as optional and providing configuration support within its containing ConfigurableContainer.
 * 
 * Refer to the documentation of meta-class ConfigurableContainer for a detailed explanation of how ConfigurableContainer and VariableElement work together.
 * 
 * Constraints:
 * none
 * 
 * Semantics:
 * Marks the element or the set of elements identified by association optionalElement as optional. If a set of elements is referred to it means that these elements always occur together or are removed together from the system.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.VariableElement</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.VariableElement#getActualBindingTime <em>Actual Binding Time</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VariableElement#getRequiredBindingTime <em>Required Binding Time</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VariableElement#getOptionalElement <em>Optional Element</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VariableElement#getReuseMetaInformation <em>Reuse Meta Information</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariableElement()
 * @model annotation="MetaData guid='{69EE1EC3-79AD-4dc0-9EB9-17F38822FEF6}' id='97' EA\040name='VariableElement'"
 *        extendedMetaData="name='VARIABLE-ELEMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIABLE-ELEMENTS'"
 * @generated
 */
public interface VariableElement extends EAElement {
	/**
	 * Returns the value of the '<em><b>Actual Binding Time</b></em>' attribute.
	 * The default value is <code>"SYSTEMDESIGNTIME"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.BindingTimeKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Variability can be bound (determined, decided) at different stages in development. The actual binding time describes the chosen/actual binding time for the VariableElement 
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Actual Binding Time</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.BindingTimeKind
	 * @see #isSetActualBindingTime()
	 * @see #unsetActualBindingTime()
	 * @see #setActualBindingTime(BindingTimeKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariableElement_ActualBindingTime()
	 * @model default="SYSTEMDESIGNTIME" unsettable="true"
	 *        annotation="MetaData guid='{7295A023-7994-4f24-8675-DC8F193D8B5E}' id='236' EA\040name='actualBindingTime'"
	 *        extendedMetaData="name='ACTUAL-BINDING-TIME' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ACTUAL-BINDING-TIMES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	BindingTimeKind getActualBindingTime();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VariableElement#getActualBindingTime <em>Actual Binding Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Actual Binding Time</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.BindingTimeKind
	 * @see #isSetActualBindingTime()
	 * @see #ActualBindingTime()
	 * @see #getActualBindingTime()
	 * @generated
	 */
	void setActualBindingTime(BindingTimeKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.VariableElement#getActualBindingTime <em>Actual Binding Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetActualBindingTime()
	 * @see #getActualBindingTime()
	 * @see #setActualBindingTime(BindingTimeKind)
	 * @generated
	 */
	void unsetActualBindingTime();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.VariableElement#getActualBindingTime <em>Actual Binding Time</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Actual Binding Time</em>' attribute is set.
	 * @see #ActualBindingTime()
	 * @see #getActualBindingTime()
	 * @see #setActualBindingTime(BindingTimeKind)
	 * @generated
	 */
	boolean isSetActualBindingTime();

	/**
	 * Returns the value of the '<em><b>Required Binding Time</b></em>' attribute.
	 * The default value is <code>"SYSTEMDESIGNTIME"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.BindingTimeKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Variability can be bound (determined, decided) at different stages in development. The required binding time describes the binding time that the VariableElement is intended to have. 
	 * 
	 * 
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Required Binding Time</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.BindingTimeKind
	 * @see #isSetRequiredBindingTime()
	 * @see #unsetRequiredBindingTime()
	 * @see #setRequiredBindingTime(BindingTimeKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariableElement_RequiredBindingTime()
	 * @model default="SYSTEMDESIGNTIME" unsettable="true"
	 *        annotation="MetaData guid='{5FA0B8B8-41D3-4608-9367-292331642C34}' id='237' EA\040name='requiredBindingTime'"
	 *        extendedMetaData="name='REQUIRED-BINDING-TIME' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIRED-BINDING-TIMES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	BindingTimeKind getRequiredBindingTime();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VariableElement#getRequiredBindingTime <em>Required Binding Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Required Binding Time</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.BindingTimeKind
	 * @see #isSetRequiredBindingTime()
	 * @see #RequiredBindingTime()
	 * @see #getRequiredBindingTime()
	 * @generated
	 */
	void setRequiredBindingTime(BindingTimeKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.VariableElement#getRequiredBindingTime <em>Required Binding Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetRequiredBindingTime()
	 * @see #getRequiredBindingTime()
	 * @see #setRequiredBindingTime(BindingTimeKind)
	 * @generated
	 */
	void unsetRequiredBindingTime();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.VariableElement#getRequiredBindingTime <em>Required Binding Time</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Required Binding Time</em>' attribute is set.
	 * @see #RequiredBindingTime()
	 * @see #getRequiredBindingTime()
	 * @see #setRequiredBindingTime(BindingTimeKind)
	 * @generated
	 */
	boolean isSetRequiredBindingTime();

	/**
	 * Returns the value of the '<em><b>Optional Element</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Identifiable}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Optional Element</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Optional Element</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariableElement_OptionalElement()
	 * @model required="true"
	 *        annotation="MetaData guid='{ABAC037A-4A09-4931-BA14-3A57B512E7A6}' id='496' EA\040name=''"
	 *        extendedMetaData="name='OPTIONAL-ELEMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OPTIONAL-ELEMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Identifiable> getOptionalElement();

	/**
	 * Returns the value of the '<em><b>Reuse Meta Information</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Reuse Meta Information</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reuse Meta Information</em>' containment reference.
	 * @see #setReuseMetaInformation(ReuseMetaInformation)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariableElement_ReuseMetaInformation()
	 * @model containment="true"
	 *        annotation="MetaData guid='{0EDD419C-6973-4ff4-84D1-774975BF2711}' id='500' EA\040name=''"
	 *        extendedMetaData="name='REUSE-META-INFORMATION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REUSE-META-INFORMATIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	ReuseMetaInformation getReuseMetaInformation();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VariableElement#getReuseMetaInformation <em>Reuse Meta Information</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Reuse Meta Information</em>' containment reference.
	 * @see #getReuseMetaInformation()
	 * @generated
	 */
	void setReuseMetaInformation(ReuseMetaInformation value);

} // VariableElement
