/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Logical Path</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The EAST-ADL logical path (LogicalPath) is a set of restrictions on the cause-effect flows of some observable logical and executional events. It provides the modeling support for annotating the expected cause-effect traces across a system or a component.
 * 
 * A logical path specifies the overall causality of computation by relating execution events with logical transformations and logical events. An execution event can be the triggering of function, port reading or writing, which constitutes the basis for the description of execution control using timing event chains (Timing::EventChain). Compared to such execution events, the logical transformation and logical events are only concerned with the computational logic.  The specification of logical path allows the internal causality of the computations of a function/component to be captured and merged explicitly with the related external execution events. 
 * 
 * Logical paths can be combined in parallel (strand) or in sequence (segment).
 * 
 * Semantics:
 * A logical path is a set of restrictions on the cause-effect flows of computation. When applied to a function/component, a logical path defines the correspondence from a triple of logical stimulus (logicalStimulus), logical transformation (transformationOccurrance), and logical response (logicalResponse), to a triple of preceding execution event chains (precedingEventChain), the corresponding execution event chains (correspondingExecutionEventChain), and the succeeding execution event chains (succeedingEventChain).
 * 
 * By describing the internal causality of a function/component, a logical path may refine an execution event chain (correspondingExecutionEventChain), which is primarily used to capture the causality of triggering, port reading and writing events. 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.ComputationConstraint.LogicalPath</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalPath#getSegment <em>Segment</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalPath#getStrand <em>Strand</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalPath#getLogicalStimulus <em>Logical Stimulus</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalPath#getLogicalResponse <em>Logical Response</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalPath#getCorrespondingExecutionEventChain <em>Corresponding Execution Event Chain</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalPath#getSucceedingExecutionEventChain <em>Succeeding Execution Event Chain</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalPath#getPrecedingExecutionEventChain <em>Preceding Execution Event Chain</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalPath#getTransformationOccurrence <em>Transformation Occurrence</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalPath()
 * @model annotation="MetaData guid='{9C2F01C9-DCA0-467c-97D9-CD2D9490C519}' id='315' EA\040name='LogicalPath'"
 *        extendedMetaData="name='LOGICAL-PATH' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOGICAL-PATHS'"
 * @generated
 */
public interface LogicalPath extends EAElement {
	/**
	 * Returns the value of the '<em><b>Segment</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.LogicalPath}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Segment</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Segment</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalPath_Segment()
	 * @model annotation="MetaData guid='{C34521B9-30B3-47ed-9749-607BC9F405BF}' id='34' EA\040name=''"
	 *        extendedMetaData="name='SEGMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SEGMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<LogicalPath> getSegment();

	/**
	 * Returns the value of the '<em><b>Strand</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.LogicalPath}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Strand</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Strand</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalPath_Strand()
	 * @model annotation="MetaData guid='{0DAEC6F1-DF69-478e-A9DD-CE73C94B4D38}' id='35' EA\040name=''"
	 *        extendedMetaData="name='STRAND-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STRAND-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<LogicalPath> getStrand();

	/**
	 * Returns the value of the '<em><b>Logical Stimulus</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.LogicalEvent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Logical Stimulus</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Logical Stimulus</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalPath_LogicalStimulus()
	 * @model annotation="MetaData guid='{DD70D8C1-B701-4a7f-9B42-33368AC0E941}' id='55' EA\040name=''"
	 *        extendedMetaData="name='LOGICAL-STIMULUS-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOGICAL-STIMULUS-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<LogicalEvent> getLogicalStimulus();

	/**
	 * Returns the value of the '<em><b>Logical Response</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.LogicalEvent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Logical Response</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Logical Response</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalPath_LogicalResponse()
	 * @model annotation="MetaData guid='{2B91BA26-AA3E-409e-91ED-3923162DF341}' id='57' EA\040name=''"
	 *        extendedMetaData="name='LOGICAL-RESPONSE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOGICAL-RESPONSE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<LogicalEvent> getLogicalResponse();

	/**
	 * Returns the value of the '<em><b>Corresponding Execution Event Chain</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.EventChain}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Corresponding Execution Event Chain</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Corresponding Execution Event Chain</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalPath_CorrespondingExecutionEventChain()
	 * @model annotation="MetaData guid='{B55E5D00-405D-402b-9CB5-B24D4E000A20}' id='349' EA\040name=''"
	 *        extendedMetaData="name='CORRESPONDING-EXECUTION-EVENT-CHAIN-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CORRESPONDING-EXECUTION-EVENT-CHAIN-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<EventChain> getCorrespondingExecutionEventChain();

	/**
	 * Returns the value of the '<em><b>Succeeding Execution Event Chain</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.EventChain}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Succeeding Execution Event Chain</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Succeeding Execution Event Chain</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalPath_SucceedingExecutionEventChain()
	 * @model annotation="MetaData guid='{9BD69CB2-2D79-4316-BC39-106885358769}' id='351' EA\040name=''"
	 *        extendedMetaData="name='SUCCEEDING-EXECUTION-EVENT-CHAIN-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SUCCEEDING-EXECUTION-EVENT-CHAIN-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<EventChain> getSucceedingExecutionEventChain();

	/**
	 * Returns the value of the '<em><b>Preceding Execution Event Chain</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.EventChain}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Preceding Execution Event Chain</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Preceding Execution Event Chain</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalPath_PrecedingExecutionEventChain()
	 * @model annotation="MetaData guid='{2E035067-3E5D-4199-A198-0F0F2CB9C7C8}' id='355' EA\040name=''"
	 *        extendedMetaData="name='PRECEDING-EXECUTION-EVENT-CHAIN-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRECEDING-EXECUTION-EVENT-CHAIN-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<EventChain> getPrecedingExecutionEventChain();

	/**
	 * Returns the value of the '<em><b>Transformation Occurrence</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transformation Occurrence</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transformation Occurrence</em>' containment reference.
	 * @see #setTransformationOccurrence(TransformationOccurrence)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalPath_TransformationOccurrence()
	 * @model containment="true"
	 *        annotation="MetaData guid='{DEFF4001-AA74-4768-83D2-D6FC1D99047D}' id='41' EA\040name=''"
	 *        extendedMetaData="name='TRANSFORMATION-OCCURRENCE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TRANSFORMATION-OCCURRENCES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TransformationOccurrence getTransformationOccurrence();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalPath#getTransformationOccurrence <em>Transformation Occurrence</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transformation Occurrence</em>' containment reference.
	 * @see #getTransformationOccurrence()
	 * @generated
	 */
	void setTransformationOccurrence(TransformationOccurrence value);

} // LogicalPath
