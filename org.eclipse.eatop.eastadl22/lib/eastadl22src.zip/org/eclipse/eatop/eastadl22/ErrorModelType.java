/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Error Model Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ErrorModelType and ErrorModelPrototype support the hierarchical composition of error models based on the type-prototype pattern also adopted for the nominal architecture composition. The purpose of the error models is to represent information relating to the anomalies of a nominal model element. 
 * 
 * An ErrorModelType represents the internal faults and fault propagations of the nominal element that it targets. 
 * 
 * Typically the target is a system/subsystem, a function, a software component, or a hardware device.
 * 
 * ErrorModelType inherits the abstract metaclass TraceableSpecification, allowing the ErrorModelType to be referenced from its design context in a similar way as requirements, test cases and other specifications. 
 * 
 * Constraints:
 * None
 * 
 * Semantics:
 * The ErrorModelType represents a specification of the faults and fault propagations of its target element.
 * 
 * The fault propagation may be defined by 
 * - The ErrorModelPrototypes 
 * - One ErrorBehaviorDescription
 * -Multiple ErrorBehaviorDescription, in which case the propagation is the concatenation of these
 * - Neither, in which case any propagation may occurr
 *  
 * 
 * Both types and prototypes may be targets, and the following cases are relevant:
 * 
 * - One nominal type:
 * 
 * The ErrorModelType represents the identified nominal type wherever this nominal type is instantiated.
 * 
 * - Several nominal types:
 * 
 * The ErrorModelType represents the identified nominal types individually, i.e. the same error model applies to all nominal types and is reused.
 * 
 * - One nominal prototype:
 * 
 * The ErrorModelType represents the identified nominal prototype whenever its context, i.e. its top-level composition is instantiated.
 * 
 * - Several nominal prototypes with instanceref:
 * 
 * The ErrorModelType represents the identified set of nominal prototypes (together) whenever their context, i.e. their top-level composition, is instantiated.
 * 
 * The fault propagation of an errorModelType is defined by its contained parts, the ErrorModelPrototypes and their connections. In case it contains both parts and an errorBehaviorDescription, the errorBehaviorDescription shall be consistent with the parts.
 * 
 * FaultFailurePropagationLinks define valid propagation paths in the ErrorModelType. In case the contained FaultInPorts and FailureOutPorts reference nominal ports, the connectivity of the nominal model may serve as a pattern for connecting ports in the ErrorModelType.
 * 
 * The ErrorModelType contains internalFaults and externalFaults, representing faults that are either propagated to externalFailures or masked, according to the definition of its fault propagation.
 * 
 * A processFault represents a flaw introduced during design, and may lead to any of the failures represented by the ErrorModelType. A processFault therefore has a direct propagation to all failures and cannot be masked. 
 * 
 * 
 * Extension:
 * (see TraceableSpecfication)
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.ErrorModel.ErrorModelType</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelType#getErrorBehaviorDescription <em>Error Behavior Description</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelType#getExternalFault <em>External Fault</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelType#getPart <em>Part</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelType#getFaultFailureConnector <em>Fault Failure Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelType#getHwTarget <em>Hw Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelType#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelType#getFailure <em>Failure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelType#getInternalFault <em>Internal Fault</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelType#getProcessFault <em>Process Fault</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType()
 * @model annotation="MetaData guid='{E0C6937F-F472-4929-9F7E-A6A5D42F4608}' id='214' EA\040name='ErrorModelType'"
 *        annotation="Stereotype Stereotype='atpType'"
 *        extendedMetaData="name='ERROR-MODEL-TYPE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-MODEL-TYPES'"
 * @generated
 */
public interface ErrorModelType extends TraceableSpecification, EAType {
	/**
	 * Returns the value of the '<em><b>Error Behavior Description</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ErrorBehavior}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Error Behavior Description</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Error Behavior Description</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType_ErrorBehaviorDescription()
	 * @model containment="true"
	 *        annotation="MetaData guid='{CCB9667E-E1AF-4706-AAEB-35CF7B4BD837}' id='202' EA\040name=''"
	 *        extendedMetaData="name='ERROR-BEHAVIOR-DESCRIPTION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-BEHAVIOR-DESCRIPTIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ErrorBehavior> getErrorBehaviorDescription();

	/**
	 * Returns the value of the '<em><b>External Fault</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FaultInPort}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>External Fault</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>External Fault</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType_ExternalFault()
	 * @model containment="true"
	 *        annotation="MetaData guid='{4D5F6B27-42FE-45b1-B50D-44C454576232}' id='215' EA\040name=''"
	 *        extendedMetaData="name='EXTERNAL-FAULT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTERNAL-FAULTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<FaultInPort> getExternalFault();

	/**
	 * Returns the value of the '<em><b>Part</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ErrorModelPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Part</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Part</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType_Part()
	 * @model containment="true"
	 *        annotation="MetaData guid='{5BB25DDA-1EB1-41c8-ABAF-29208D911AF2}' id='227' EA\040name=''"
	 *        extendedMetaData="name='PART' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PARTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ErrorModelPrototype> getPart();

	/**
	 * Returns the value of the '<em><b>Fault Failure Connector</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FaultFailurePropagationLink}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fault Failure Connector</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fault Failure Connector</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType_FaultFailureConnector()
	 * @model containment="true"
	 *        annotation="MetaData guid='{ACAF900D-0A28-4a97-AB16-0BCCCECF6EFD}' id='239' EA\040name=''"
	 *        extendedMetaData="name='FAULT-FAILURE-CONNECTOR' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE-CONNECTORS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<FaultFailurePropagationLink> getFaultFailureConnector();

	/**
	 * Returns the value of the '<em><b>Hw Target</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.HardwareComponentType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hw Target</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hw Target</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType_HwTarget()
	 * @model annotation="MetaData guid='{C7AA9534-F12A-459f-AADB-B26B37C4496D}' id='541' EA\040name=''"
	 *        extendedMetaData="name='HW-TARGET-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HW-TARGET-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<HardwareComponentType> getHwTarget();

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType_Target()
	 * @model annotation="MetaData guid='{370C7F2B-2A1C-42ff-9322-3F65C4FBD20F}' id='648' EA\040name=''"
	 *        extendedMetaData="name='TARGET-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FunctionType> getTarget();

	/**
	 * Returns the value of the '<em><b>Failure</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FailureOutPort}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Failure</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Failure</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType_Failure()
	 * @model containment="true"
	 *        annotation="MetaData guid='{8A004A0E-C5E3-4edc-A7EB-CF88A4FB729F}' id='220' EA\040name=''"
	 *        extendedMetaData="name='FAILURE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAILURES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<FailureOutPort> getFailure();

	/**
	 * Returns the value of the '<em><b>Internal Fault</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.InternalFaultPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Internal Fault</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Internal Fault</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType_InternalFault()
	 * @model containment="true"
	 *        annotation="MetaData guid='{60D8D2FA-2530-42d6-8809-28BFBF71E769}' id='245' EA\040name=''"
	 *        extendedMetaData="name='INTERNAL-FAULT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INTERNAL-FAULTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<InternalFaultPrototype> getInternalFault();

	/**
	 * Returns the value of the '<em><b>Process Fault</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ProcessFaultPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Process Fault</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Process Fault</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelType_ProcessFault()
	 * @model containment="true"
	 *        annotation="MetaData guid='{519F91E6-E905-4674-B8DD-062A6A4AFC4B}' id='234' EA\040name=''"
	 *        extendedMetaData="name='PROCESS-FAULT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PROCESS-FAULTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ProcessFaultPrototype> getProcessFault();

} // ErrorModelType
