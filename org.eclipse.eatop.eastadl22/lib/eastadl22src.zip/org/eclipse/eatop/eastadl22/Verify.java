/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Verify</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Verify is a relationship metaclass, which signifies a dependency relationship between a Requirement and a VVCase. It shows the relationship when a client VVCase and an optional abstract VVProcedure verifies the supplier Requirement.
 * 
 * Semantics:
 * The Verify metaclass signifies a refined requirement/verified by relationship between a Requirement and a VVCase, where the modification of the supplier Requirement may impact the verifying client VVCase and optional abstract VVProcedure. The Verify metaclass implies that the semantics of the verifying client VVCase is not complete, without the supplier Requirement. 
 * 
 * Notation:
 * A Verify relationship is shown as a dashed arrow between the Requirements and VVCase.
 * 
 * Extension:
 * To specializes SysML::Verify, which specializes the UML stereotype Trace, which extends Dependency.
 * 
 * Temporary change in the profile (to overcome bug in Eclipse/UML2 concerning standard stereotypes)
 * - added extension towards Dependency
 * - removed generalization link towards SysML::Verify
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.VerificationValidation.Verify</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Verify#getVerifiedByCase <em>Verified By Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Verify#getVerifiedByProcedure <em>Verified By Procedure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Verify#getVerifiedRequirement <em>Verified Requirement</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVerify()
 * @model annotation="MetaData guid='{C6899161-87AC-4ca7-A690-3018E18D772B}' id='138' EA\040name='Verify'"
 *        extendedMetaData="name='VERIFY' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VERIFYS'"
 * @generated
 */
public interface Verify extends RequirementsRelationship {
	/**
	 * Returns the value of the '<em><b>Verified By Case</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVCase}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Verified By Case</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Verified By Case</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVerify_VerifiedByCase()
	 * @model required="true"
	 *        annotation="MetaData guid='{D5901D32-B80C-42af-B393-A2F355507DA6}' id='397' EA\040name=''"
	 *        extendedMetaData="name='VERIFIED-BY-CASE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VERIFIED-BY-CASE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<VVCase> getVerifiedByCase();

	/**
	 * Returns the value of the '<em><b>Verified By Procedure</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVProcedure}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Verified By Procedure</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Verified By Procedure</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVerify_VerifiedByProcedure()
	 * @model annotation="MetaData guid='{37316D09-0C74-43c4-B548-8BA86AFD1D87}' id='418' EA\040name=''"
	 *        extendedMetaData="name='VERIFIED-BY-PROCEDURE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VERIFIED-BY-PROCEDURE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<VVProcedure> getVerifiedByProcedure();

	/**
	 * Returns the value of the '<em><b>Verified Requirement</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Requirement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Verified Requirement</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Verified Requirement</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVerify_VerifiedRequirement()
	 * @model required="true"
	 *        annotation="MetaData guid='{1056EF80-7E67-44e7-BC32-B4BE1F2A8A3A}' id='463' EA\040name=''"
	 *        extendedMetaData="name='VERIFIED-REQUIREMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VERIFIED-REQUIREMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Requirement> getVerifiedRequirement();

} // Verify
