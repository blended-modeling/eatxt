/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Extend</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Extend represents the specification that the behavior of a UseCase may be extended by the behavior of another (usually supplementary) UseCase. The extension takes place at one or more specific ExtensionPoints defined in the extended UseCase. Note, however, that the extended UseCase is defined independently of the extending UseCase and is meaningful independently of the extending UseCase. On the other hand, the extending UseCase typically defines behavior that may not necessarily be meaningful by itself. Instead, the extending UseCase defines a set of modular behavior increments that augment an execution of the extended UseCase under specific conditions. Note that the same extending UseCase can extend more than one UseCases. Furthermore, an extending UseCase may itself be extended.
 * 
 * Semantics:
 * An Extension relation identifies an extension UseCase which extends an extendedCase UseCase.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.UseCases.Extend</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Extend#getExtendedCase <em>Extended Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Extend#getExtensionLocation <em>Extension Location</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getExtend()
 * @model annotation="MetaData guid='{2AD76CCF-3366-4e84-B697-8804146E2920}' id='127' EA\040name='Extend'"
 *        extendedMetaData="name='EXTEND' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTENDS'"
 * @generated
 */
public interface Extend extends Relationship {
	/**
	 * Returns the value of the '<em><b>Extended Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Extended Case</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extended Case</em>' reference.
	 * @see #setExtendedCase(UseCase)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getExtend_ExtendedCase()
	 * @model required="true"
	 *        annotation="MetaData guid='{32C32BA8-8704-46c2-BD1C-825076248038}' id='426' EA\040name=''"
	 *        extendedMetaData="name='EXTENDED-CASE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTENDED-CASE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	UseCase getExtendedCase();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Extend#getExtendedCase <em>Extended Case</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Extended Case</em>' reference.
	 * @see #getExtendedCase()
	 * @generated
	 */
	void setExtendedCase(UseCase value);

	/**
	 * Returns the value of the '<em><b>Extension Location</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ExtensionPoint}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Extension Location</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extension Location</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getExtend_ExtensionLocation()
	 * @model required="true"
	 *        annotation="MetaData guid='{C9F5E8D9-C871-4955-A12B-37B661F2A6C2}' id='431' EA\040name=''"
	 *        extendedMetaData="name='EXTENSION-LOCATION-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTENSION-LOCATION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<ExtensionPoint> getExtensionLocation();

} // Extend
