/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VV Stimuli</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * VVStimuli represents the input values of the testing environment represented by VVTarget in order to perform the corresponding VVProcedure.
 * 
 * Since this entity only occurs on the concrete level (i.e. within the context of a concrete VVCase), the input values must be provided in a form that is directly applicable to the VVTarget(s) defined for the containing concrete VVCase.
 * 
 * Semantics:
 * VVStimuli represents the concrete input values used for a VVProcedure during a Verification/Validation effort of a VVTarget.
 * 
 * Extension: Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.VerificationValidation.VVStimuli</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVStimuli()
 * @model annotation="MetaData guid='{219FED5B-DC76-42ac-81A5-D72A806CBF5F}' id='131' EA\040name='VVStimuli'"
 *        extendedMetaData="name='VV-STIMULI' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-STIMULIS'"
 * @generated
 */
public interface VVStimuli extends TraceableSpecification {
} // VVStimuli
