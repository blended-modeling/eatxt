/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vehicle Level Binding</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * This class represents a binding on the vehicle level or coming from the vehicle level with explicitly defined source and target feature models. The source feature models must be on vehicle level, but the target feature models may be located on artifact level, e.g. the public feature model of the top-level FunctionType in the FDA. This way, a VehicleLevelBinding may be used to bridge the gap from vehicle level variability management to that on the artifact level.
 * 
 * Source feature models may be either the core technical feature model (as defined by association technicalFeatureModel of meta-class VehicleLevel) or one of the optional product feature models (as defined by association productFeatureModel of meta-class Variability in the variability extension).
 * 
 * Constraints:
 * [1] The sourceVehicleFeatureModels shall only contain VehicleFeatures.
 * [2] The sourceVehicleFeatureModels shall be different from the targetFeatureModels.
 * 
 * Semantics:
 * See description.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.VehicleLevelBinding</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleLevelBinding#getTargetFeatureModel <em>Target Feature Model</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleLevelBinding#getSourceVehicleFeatureModel <em>Source Vehicle Feature Model</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleLevelBinding()
 * @model annotation="MetaData guid='{0E2A0B24-B768-4284-8B6C-92C9ECDA7A6E}' id='93' EA\040name='VehicleLevelBinding'"
 *        extendedMetaData="name='VEHICLE-LEVEL-BINDING' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VEHICLE-LEVEL-BINDINGS'"
 * @generated
 */
public interface VehicleLevelBinding extends ConfigurationDecisionModel {
	/**
	 * Returns the value of the '<em><b>Target Feature Model</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FeatureModel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target Feature Model</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target Feature Model</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleLevelBinding_TargetFeatureModel()
	 * @model annotation="MetaData guid='{4B9AF883-5AA5-44bc-95C2-D0B9A0FA15A5}' id='703' EA\040name=''"
	 *        extendedMetaData="name='TARGET-FEATURE-MODEL-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-FEATURE-MODEL-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FeatureModel> getTargetFeatureModel();

	/**
	 * Returns the value of the '<em><b>Source Vehicle Feature Model</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FeatureModel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source Vehicle Feature Model</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source Vehicle Feature Model</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleLevelBinding_SourceVehicleFeatureModel()
	 * @model annotation="MetaData guid='{2F9D3F7B-DCF0-4cfb-B688-895962832595}' id='704' EA\040name=''"
	 *        extendedMetaData="name='SOURCE-VEHICLE-FEATURE-MODEL-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SOURCE-VEHICLE-FEATURE-MODEL-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FeatureModel> getSourceVehicleFeatureModel();

} // VehicleLevelBinding
