/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Non Concurrence Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The NonConcurrenceConstraint represents a particular constraint applied on the execution of functions: The referenced functions are not allowed to run in parallel.
 * 
 * Semantics:
 * The semantics for the NonConcurrenceConstraint metaclass is to define an association relationship between Functions, indicating the association relationship such that all referenced functions are not allowed to run in parallel.
 * 
 * Notation:
 * PrecedenceConstraint is shown as a dashed bidirectional arrow with "NonConcurrent" next to it.
 * 
 * Extension: 
 * The NonConcurrenceConstraint extends UML2 metaclass Class and Dependency.
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.NonConcurrenceConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.NonConcurrenceConstraint#getExclusive <em>Exclusive</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getNonConcurrenceConstraint()
 * @model annotation="MetaData guid='{669C6C9A-D009-4ec8-8222-86668EF72DF3}' id='335' EA\040name='NonConcurrenceConstraint'"
 *        extendedMetaData="name='NON-CONCURRENCE-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='NON-CONCURRENCE-CONSTRAINTS'"
 * @generated
 */
public interface NonConcurrenceConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Exclusive</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.NonConcurrentConstraint_exclusive}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Exclusive</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exclusive</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getNonConcurrenceConstraint_Exclusive()
	 * @model containment="true" lower="2"
	 *        annotation="MetaData guid='{63A0DE7C-F8D0-4444-8EC4-A11B07EFA9F4}' id='772' EA\040name=''"
	 *        annotation="TaggedValues xml.name='EXCLUSIVE-IREF' xml.namePlural='EXCLUSIVE-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='EXCLUSIVE-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXCLUSIVE-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<NonConcurrentConstraint_exclusive> getExclusive();

} // NonConcurrenceConstraint
