/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Actor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Actor represents a type of role played by an entity that interacts with the UseCase, e.g. by exchanging signals and data, but which is external to the subject, i.e., in the sense that an instance of an Actor is not a part of the instance of its corresponding subject. Actors may represent roles played by human users, external hardware, or other subjects. Note that an Actor does not necessarily represent a specific physical entity but merely a particular facet (i.e., "role") of some entity that is relevant to the specification of its associated UseCases. Thus, a single physical instance may play the role of several different Actors and, conversely, a given Actor may be played by multiple different instances. Since an Actor is external to the subject, it is typically defined in the same classifier or package that incorporates the subject classifier.
 * 
 * Semantics:
 * The Actor element represents entities that interacts with a UseCase.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.UseCases.Actor</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getActor()
 * @model annotation="MetaData guid='{DCD6B253-474B-4fba-8991-1A07861F5917}' id='128' EA\040name='Actor'"
 *        extendedMetaData="name='ACTOR' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ACTORS'"
 * @generated
 */
public interface Actor extends TraceableSpecification {
} // Actor
