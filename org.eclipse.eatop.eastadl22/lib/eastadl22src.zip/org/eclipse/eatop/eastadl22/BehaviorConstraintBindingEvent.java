/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Binding Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * BehaviorConstraintBindingEvent is a specialization of BehaviorConstraintBindingParameter. It allows a behavior constraint type to declare the discrete events to be shared by its prototypes. 
 * 
 * See also BehaviorConstraintBindingParameter.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.BehaviorConstraintBindingEvent</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintBindingEvent()
 * @model annotation="MetaData guid='{FE59D3B1-FDAD-4753-9F15-629C7E05D8F9}' id='297' EA\040name='BehaviorConstraintBindingEvent'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-BINDING-EVENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-BINDING-EVENTS'"
 * @generated
 */
public interface BehaviorConstraintBindingEvent extends TransitionEvent, BehaviorConstraintInternalBinding {
} // BehaviorConstraintBindingEvent
