/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Logical Time Condition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The logical time condition is an abstract notion of time for the descriptions of behavior constraints. Declarations of such time conditions can be used to define the time basis of continuous- and discrete-time dynamics or the timing concerns in statemachine or data-processing related behaviors.
 * 
 * The semantics of logical time conditions can be further refined by associating such conditions to the occurrences of execution events (TransitionEvents), such as for defining the change of an environmental condition or the triggering of a function. This makes it possible to precisely define the reference points of a time interval (i.e. startPointReference and endPointReference).
 * 
 * A time condition can have a consecutive time condition on the same time line. E.g. if condition1=[t1, t2], then the consecutive time condition is condition2=[t2, t3].
 * 
 * With EAST-ADL, the expression of the value of a logical time condition is based on the Timing::TimeDuration in the format of CseCode as in AUTOSAR and MSR/ASAM. For descriptions where the notion of time proceeding is not of interest, a time condition with isLogicalTimeSuspended=true has to be explicitly declared and used.
 * 
 * Semantics:
 * A logical time condition (LTC) is an infinite sequence of time intervals 
 * 
 * Extension: 
 * EAElement.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.TemporalConstraint.LogicalTimeCondition</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getIsLogicalTimeSuspended <em>Is Logical Time Suspended</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getUpper <em>Upper</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getLower <em>Lower</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getWidth <em>Width</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getConsecutiveTimeCondition <em>Consecutive Time Condition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getStartPointReference <em>Start Point Reference</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getEndPointReference <em>End Point Reference</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTimeCondition()
 * @model annotation="MetaData guid='{5CEEC95C-95A3-4466-9C59-474581A163AC}' id='318' EA\040name='LogicalTimeCondition'"
 *        extendedMetaData="name='LOGICAL-TIME-CONDITION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOGICAL-TIME-CONDITIONS'"
 * @generated
 */
public interface LogicalTimeCondition extends EAElement {
	/**
	 * Returns the value of the '<em><b>Is Logical Time Suspended</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Logical Time Suspended</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Logical Time Suspended</em>' attribute.
	 * @see #isSetIsLogicalTimeSuspended()
	 * @see #unsetIsLogicalTimeSuspended()
	 * @see #setIsLogicalTimeSuspended(Boolean)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTimeCondition_IsLogicalTimeSuspended()
	 * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Boolean" required="true"
	 *        annotation="MetaData guid='{2205A051-9AB9-4fd5-A9B1-8908CBFE7BEF}' id='214' EA\040name='isLogicalTimeSuspended'"
	 *        extendedMetaData="name='IS-LOGICAL-TIME-SUSPENDED' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-LOGICAL-TIME-SUSPENDEDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Boolean getIsLogicalTimeSuspended();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getIsLogicalTimeSuspended <em>Is Logical Time Suspended</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Logical Time Suspended</em>' attribute.
	 * @see #isSetIsLogicalTimeSuspended()
	 * @see #IsLogicalTimeSuspended()
	 * @see #getIsLogicalTimeSuspended()
	 * @generated
	 */
	void setIsLogicalTimeSuspended(Boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getIsLogicalTimeSuspended <em>Is Logical Time Suspended</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsLogicalTimeSuspended()
	 * @see #getIsLogicalTimeSuspended()
	 * @see #setIsLogicalTimeSuspended(Boolean)
	 * @generated
	 */
	void unsetIsLogicalTimeSuspended();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getIsLogicalTimeSuspended <em>Is Logical Time Suspended</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Logical Time Suspended</em>' attribute is set.
	 * @see #IsLogicalTimeSuspended()
	 * @see #getIsLogicalTimeSuspended()
	 * @see #setIsLogicalTimeSuspended(Boolean)
	 * @generated
	 */
	boolean isSetIsLogicalTimeSuspended();

	/**
	 * Returns the value of the '<em><b>Upper</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Upper</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Upper</em>' containment reference.
	 * @see #setUpper(EAValue)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTimeCondition_Upper()
	 * @model containment="true"
	 *        annotation="MetaData guid='{CD8897DB-9870-469c-8AAF-E055D7C4FC5F}' id='86' EA\040name=''"
	 *        extendedMetaData="name='UPPER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='UPPERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EAValue getUpper();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getUpper <em>Upper</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Upper</em>' containment reference.
	 * @see #getUpper()
	 * @generated
	 */
	void setUpper(EAValue value);

	/**
	 * Returns the value of the '<em><b>Lower</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lower</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lower</em>' containment reference.
	 * @see #setLower(EAValue)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTimeCondition_Lower()
	 * @model containment="true"
	 *        annotation="MetaData guid='{AC8E169B-D5AF-4036-B15E-93CA8F321F50}' id='87' EA\040name=''"
	 *        extendedMetaData="name='LOWER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOWERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EAValue getLower();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getLower <em>Lower</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lower</em>' containment reference.
	 * @see #getLower()
	 * @generated
	 */
	void setLower(EAValue value);

	/**
	 * Returns the value of the '<em><b>Width</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Width</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Width</em>' containment reference.
	 * @see #setWidth(EAValue)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTimeCondition_Width()
	 * @model containment="true"
	 *        annotation="MetaData guid='{3943E51E-7EAB-4b7d-A21A-C7FFA30F5AAC}' id='91' EA\040name=''"
	 *        extendedMetaData="name='WIDTH' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='WIDTHS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EAValue getWidth();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getWidth <em>Width</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Width</em>' containment reference.
	 * @see #getWidth()
	 * @generated
	 */
	void setWidth(EAValue value);

	/**
	 * Returns the value of the '<em><b>Consecutive Time Condition</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Consecutive Time Condition</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consecutive Time Condition</em>' reference.
	 * @see #setConsecutiveTimeCondition(LogicalTimeCondition)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTimeCondition_ConsecutiveTimeCondition()
	 * @model annotation="MetaData guid='{CF399646-1539-46f2-B4D6-501D40C17ECE}' id='25' EA\040name=''"
	 *        extendedMetaData="name='CONSECUTIVE-TIME-CONDITION-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONSECUTIVE-TIME-CONDITION-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	LogicalTimeCondition getConsecutiveTimeCondition();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getConsecutiveTimeCondition <em>Consecutive Time Condition</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Consecutive Time Condition</em>' reference.
	 * @see #getConsecutiveTimeCondition()
	 * @generated
	 */
	void setConsecutiveTimeCondition(LogicalTimeCondition value);

	/**
	 * Returns the value of the '<em><b>Start Point Reference</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start Point Reference</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start Point Reference</em>' reference.
	 * @see #setStartPointReference(TransitionEvent)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTimeCondition_StartPointReference()
	 * @model annotation="MetaData guid='{F8A6A26F-6A9D-4c06-AA9E-B6AF8DC6D6AD}' id='30' EA\040name=''"
	 *        extendedMetaData="name='START-POINT-REFERENCE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='START-POINT-REFERENCE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TransitionEvent getStartPointReference();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getStartPointReference <em>Start Point Reference</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start Point Reference</em>' reference.
	 * @see #getStartPointReference()
	 * @generated
	 */
	void setStartPointReference(TransitionEvent value);

	/**
	 * Returns the value of the '<em><b>End Point Reference</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>End Point Reference</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End Point Reference</em>' reference.
	 * @see #setEndPointReference(TransitionEvent)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getLogicalTimeCondition_EndPointReference()
	 * @model annotation="MetaData guid='{C26F1093-72D6-4869-B9A4-736BE74756D1}' id='32' EA\040name=''"
	 *        extendedMetaData="name='END-POINT-REFERENCE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='END-POINT-REFERENCE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TransitionEvent getEndPointReference();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.LogicalTimeCondition#getEndPointReference <em>End Point Reference</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End Point Reference</em>' reference.
	 * @see #getEndPointReference()
	 * @generated
	 */
	void setEndPointReference(TransitionEvent value);

} // LogicalTimeCondition
