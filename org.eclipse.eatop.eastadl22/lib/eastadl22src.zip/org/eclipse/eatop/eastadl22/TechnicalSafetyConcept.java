/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Technical Safety Concept</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * TechnicalSafetyConcept represents the set of technical safety requirements that together fulfills a FunctionalSafetyConcept and SafetyGoal in accordance with ISO 26262.
 * 
 * These are derived from FunctionalSafetyConcepts i.e. TechnicalSafetyRequirements are derived from FunctionalSafetyRequirements.
 * 
 * 
 * Semantics:
 * The TechnicalSafetyConcept consists of the technical safety requirements and details the functional safety concept considering the functional concept and the preliminary architectural design. It corresponds to the Technical Safety Concept of ISO26262.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.SafetyRequirement.TechnicalSafetyConcept</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.TechnicalSafetyConcept#getTechnicalSafetyRequirement <em>Technical Safety Requirement</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTechnicalSafetyConcept()
 * @model annotation="MetaData guid='{D8EB4357-37A2-4806-A3AC-A243E60B9377}' id='223' EA\040name='TechnicalSafetyConcept'"
 *        extendedMetaData="name='TECHNICAL-SAFETY-CONCEPT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TECHNICAL-SAFETY-CONCEPTS'"
 * @generated
 */
public interface TechnicalSafetyConcept extends RequirementsHierarchy {
	/**
	 * Returns the value of the '<em><b>Technical Safety Requirement</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Requirement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Technical Safety Requirement</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Technical Safety Requirement</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTechnicalSafetyConcept_TechnicalSafetyRequirement()
	 * @model annotation="MetaData guid='{3799099D-57C2-47f4-B646-4926C4D88A91}' id='460' EA\040name=''"
	 *        extendedMetaData="name='TECHNICAL-SAFETY-REQUIREMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TECHNICAL-SAFETY-REQUIREMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Requirement> getTechnicalSafetyRequirement();

} // TechnicalSafetyConcept
