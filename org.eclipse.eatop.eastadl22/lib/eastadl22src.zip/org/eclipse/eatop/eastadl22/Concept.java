/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Concept</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An abstract or general idea inferred or derived from specific instances. [Webster]
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.Needs.Concept</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConcept()
 * @model abstract="true"
 *        annotation="MetaData guid='{B22DC556-9D66-4e33-8B35-C72BEFB3EC7C}' id='332' EA\040name='Concept'"
 *        extendedMetaData="name='CONCEPT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONCEPTS'"
 * @generated
 */
public interface Concept extends EAElement {
} // Concept
