/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VV Procedure</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * VVProcedure represents an individual task in a V&amp;V effort (represented by a VVCase), which has to be performed in order to achieve that effort's overall objective. As with VVCases, the definition of VVProcedures is separated in to two levels: an abstract and a concrete level.
 * 
 * The concrete VVProcedure represents such a task on a concrete level. It is defined with a concrete testing environment in mind and provides stimuli and the expected outcome of the procedure in a form which is directly applicable to this testing environment.
 * 
 * Semantics:
 * VVProcedure represents an individual task in a Verifcation/Validation effort.
 * 
 * Constraints:
 * [1] Only a concrete VVProcedure can have vvStimuli.
 * [2] Only a concrete VVProcedure can have vvIntendedOutcome.
 * [3] Only a concrete VVProcedure can have an abstractVVProcedure.
 * 
 * Extension: Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.VerificationValidation.VVProcedure</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.VVProcedure#getVvIntendedOutcome <em>Vv Intended Outcome</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VVProcedure#getVvStimuli <em>Vv Stimuli</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VVProcedure#getAbstractVVProcedure <em>Abstract VV Procedure</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVProcedure()
 * @model annotation="MetaData guid='{1059574E-3937-43ec-8FFB-C666BC797378}' id='130' EA\040name='VVProcedure'"
 *        extendedMetaData="name='VV-PROCEDURE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-PROCEDURES'"
 * @generated
 */
public interface VVProcedure extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Vv Intended Outcome</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVIntendedOutcome}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vv Intended Outcome</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vv Intended Outcome</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVProcedure_VvIntendedOutcome()
	 * @model containment="true"
	 *        annotation="MetaData guid='{F9116E1D-9790-47a5-BFF5-12E8576332BA}' id='414' EA\040name=''"
	 *        extendedMetaData="name='VV-INTENDED-OUTCOME' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-INTENDED-OUTCOMES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<VVIntendedOutcome> getVvIntendedOutcome();

	/**
	 * Returns the value of the '<em><b>Vv Stimuli</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVStimuli}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vv Stimuli</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vv Stimuli</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVProcedure_VvStimuli()
	 * @model containment="true"
	 *        annotation="MetaData guid='{AC43BBD2-F8F9-48ce-B1EB-C607A551E81D}' id='415' EA\040name=''"
	 *        extendedMetaData="name='VV-STIMULI' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-STIMULIS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<VVStimuli> getVvStimuli();

	/**
	 * Returns the value of the '<em><b>Abstract VV Procedure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Abstract VV Procedure</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Abstract VV Procedure</em>' reference.
	 * @see #setAbstractVVProcedure(VVProcedure)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVProcedure_AbstractVVProcedure()
	 * @model annotation="MetaData guid='{79CE9634-7364-4279-9D8C-0DD5A98676DC}' id='416' EA\040name=''"
	 *        extendedMetaData="name='ABSTRACT-VV-PROCEDURE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ABSTRACT-VV-PROCEDURE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	VVProcedure getAbstractVVProcedure();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VVProcedure#getAbstractVVProcedure <em>Abstract VV Procedure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Abstract VV Procedure</em>' reference.
	 * @see #getAbstractVVProcedure()
	 * @generated
	 */
	void setAbstractVVProcedure(VVProcedure value);

} // VVProcedure
