/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Function Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * FunctionTrigger represents the triggering parameters necessary to define the execution of an identified FunctionType or FunctionPrototype. When referring to a FunctionType, a FunctionTrigger applies to all FunctionPrototypes of the given type. When referring to a FunctionPrototype, the trigger is only valid for this particular FunctionPrototype.
 * 
 * Triggering is defined either as event-driven or time-driven - depending on the property triggerPolicy. If set to TIME, the timing constraint is defined with an event constraint associated with the Function's or FunctionPrototype's EventFunction. The function event refers to the activation of the function. If set to EVENT the referenced ports trigger the function using AND semantics, i.e., activate the function.
 * 
 * In addition, a FunctionTrigger may refer to a list of Modes in which the trigger will be considered as potentially active. As of FunctionBehaviors may also refer to Modes, it is possible to arrange various function configurations for which different sets of triggers and behaviors are active. And this, at various levels of granularity, either with a type-wise scope (by referring to a FunctionType) or specifically at prototype level (by referring to a FunctionPrototype).
 * 
 * Note that several FunctionTriggers may be assigned to the same Function (Type or Prototype), for instance to define alternative trigger conditions and/or timing constraints.
 * 
 * Semantics:
 * Association Mode defines in which modes the trigger is active.
 * 
 * The FunctionBehavior referenced by the FunctionTrigger is invoked when the FunctionTrigger is active. If multiple ports are referenced, this implies an AND semantics.
 * 
 * It is possible to have multiple triggers on a function, e.g., a slow period complemented with an event trigger allows fast response when needed but a minimal execution rate.
 * 
 * Constraints:
 * [1] The port association must not be empty when triggerPolicy is EVENT.
 * 
 * [2] The port association is empty when triggerPolicy is TIME.
 * 
 * [3] Function and functionPrototype are mutually exclusive associations. A FunctionTrigger either identifies a FunctionType or a FunctionPrototype as its target function, but not both.
 * 
 * [4] Only FunctionFlowPort of direction=in shall be referred to in the association port.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Behavior.FunctionTrigger</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getTriggerPolicy <em>Trigger Policy</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getMode <em>Mode</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getFunctionPrototype <em>Function Prototype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getFunction <em>Function</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getPort <em>Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionTrigger()
 * @model annotation="MetaData guid='{EE12DCE1-F561-4c7e-A224-C664BB641485}' id='90' EA\040name='FunctionTrigger'"
 *        extendedMetaData="name='FUNCTION-TRIGGER' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-TRIGGERS'"
 * @generated
 */
public interface FunctionTrigger extends EAElement, EAExpression {
	/**
	 * Returns the value of the '<em><b>Trigger Policy</b></em>' attribute.
	 * The default value is <code>"EVENT"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.TriggerPolicyKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Defines the triggering policy, either EVENT or TIME. The function event refers to the activation of the function. If set to EVENT, one or several ports of the Function triggers the function, i.e., activates the function.
	 * 
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Trigger Policy</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.TriggerPolicyKind
	 * @see #isSetTriggerPolicy()
	 * @see #unsetTriggerPolicy()
	 * @see #setTriggerPolicy(TriggerPolicyKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionTrigger_TriggerPolicy()
	 * @model default="EVENT" unsettable="true" required="true"
	 *        annotation="MetaData guid='{AE07BB17-ED1C-4b68-A52D-0A1436A5D1CC}' id='77' EA\040name='triggerPolicy'"
	 *        extendedMetaData="name='TRIGGER-POLICY' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TRIGGER-POLICYS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TriggerPolicyKind getTriggerPolicy();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getTriggerPolicy <em>Trigger Policy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trigger Policy</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.TriggerPolicyKind
	 * @see #isSetTriggerPolicy()
	 * @see #TriggerPolicy()
	 * @see #getTriggerPolicy()
	 * @generated
	 */
	void setTriggerPolicy(TriggerPolicyKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getTriggerPolicy <em>Trigger Policy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetTriggerPolicy()
	 * @see #getTriggerPolicy()
	 * @see #setTriggerPolicy(TriggerPolicyKind)
	 * @generated
	 */
	void unsetTriggerPolicy();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getTriggerPolicy <em>Trigger Policy</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Trigger Policy</em>' attribute is set.
	 * @see #TriggerPolicy()
	 * @see #getTriggerPolicy()
	 * @see #setTriggerPolicy(TriggerPolicyKind)
	 * @generated
	 */
	boolean isSetTriggerPolicy();

	/**
	 * Returns the value of the '<em><b>Mode</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Mode}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mode</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mode</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionTrigger_Mode()
	 * @model annotation="MetaData guid='{C86563A9-2413-4190-9D1D-DF87CC301C13}' id='526' EA\040name=''"
	 *        extendedMetaData="name='MODE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Mode> getMode();

	/**
	 * Returns the value of the '<em><b>Function Prototype</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Prototype</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Prototype</em>' reference.
	 * @see #setFunctionPrototype(FunctionPrototype)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionTrigger_FunctionPrototype()
	 * @model annotation="MetaData guid='{E1CB7EB2-7455-4d4c-8317-36897D8D0166}' id='613' EA\040name=''"
	 *        extendedMetaData="name='FUNCTION-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FunctionPrototype getFunctionPrototype();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getFunctionPrototype <em>Function Prototype</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function Prototype</em>' reference.
	 * @see #getFunctionPrototype()
	 * @generated
	 */
	void setFunctionPrototype(FunctionPrototype value);

	/**
	 * Returns the value of the '<em><b>Function</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function</em>' reference.
	 * @see #setFunction(FunctionType)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionTrigger_Function()
	 * @model annotation="MetaData guid='{F4F947D9-E14A-4044-8386-E3D5D27D1BBB}' id='640' EA\040name=''"
	 *        extendedMetaData="name='FUNCTION-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FunctionType getFunction();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FunctionTrigger#getFunction <em>Function</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function</em>' reference.
	 * @see #getFunction()
	 * @generated
	 */
	void setFunction(FunctionType value);

	/**
	 * Returns the value of the '<em><b>Port</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionPort}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Port</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionTrigger_Port()
	 * @model annotation="MetaData guid='{905971B3-ABBD-4800-B88A-52D0A4637842}' id='673' EA\040name=''"
	 *        extendedMetaData="name='PORT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PORT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FunctionPort> getPort();

} // FunctionTrigger
