/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Non Preemptive Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The NonPreemptiveConstraint represents a particular constraint applied on the execution sequence of functions, represented by an event chain composed solely of EventFunctions: the sequence of the functions is not allowed to be preempted by any other function.
 * 
 * Semantics:
 * The semantics for the NonPreemptiveConstraint metaclass is to define a non-preemptive execution sequence of the EventFunctions referenced by the referenced event chain. No function of the system is allowed to preempt the referenced function sequence referenced by the event chain of the NonPreemptiveConstraint.
 * An EventChain referenced by a NonPreemptiveConstraint is called "atomic".
 * 
 * Notation:
 * NonPreemptiveConstraint is shown as a box with its name/icon. It points to the event chain.
 * 
 * Constraints:
 * [1] A NonPreemptiveConstraint  refers to any EventChain that solely contains EventFunctions.
 * 
 * Extension: 
 * The NonPreemptiveConstraint extends UML2 metaclass Class and Dependency.
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.NonPreemptiveConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.NonPreemptiveConstraint#getEventChain <em>Event Chain</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getNonPreemptiveConstraint()
 * @model annotation="MetaData guid='{DBDC8035-ADC9-4ae6-84A3-4AEFA5B2B832}' id='338' EA\040name='NonPreemptiveConstraint'"
 *        extendedMetaData="name='NON-PREEMPTIVE-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='NON-PREEMPTIVE-CONSTRAINTS'"
 * @generated
 */
public interface NonPreemptiveConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Event Chain</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event Chain</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event Chain</em>' reference.
	 * @see #setEventChain(EventChain)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getNonPreemptiveConstraint_EventChain()
	 * @model required="true"
	 *        annotation="MetaData guid='{3468ABB2-EA95-495c-AAC1-68FC8E791EF0}' id='778' EA\040name=''"
	 *        extendedMetaData="name='EVENT-CHAIN-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-CHAIN-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EventChain getEventChain();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.NonPreemptiveConstraint#getEventChain <em>Event Chain</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event Chain</em>' reference.
	 * @see #getEventChain()
	 * @generated
	 */
	void setEventChain(EventChain value);

} // NonPreemptiveConstraint
