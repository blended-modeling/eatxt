/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Architectural Description</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A collection of products to document an architecture. [IEEE 1471]
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.Needs.ArchitecturalDescription</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ArchitecturalDescription#getIdentifies <em>Identifies</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ArchitecturalDescription#getAggregates <em>Aggregates</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArchitecturalDescription()
 * @model annotation="MetaData guid='{596EB56B-DDFC-4333-BBD5-18871B8DD025}' id='328' EA\040name='ArchitecturalDescription'"
 *        extendedMetaData="name='ARCHITECTURAL-DESCRIPTION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ARCHITECTURAL-DESCRIPTIONS'"
 * @generated
 */
public interface ArchitecturalDescription extends Concept {
	/**
	 * Returns the value of the '<em><b>Identifies</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Stakeholder}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Identifies</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Identifies</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArchitecturalDescription_Identifies()
	 * @model required="true"
	 *        annotation="MetaData guid='{98BF5529-7F9C-4d24-AA26-42EFC06ABD7C}' id='6' EA\040name=''"
	 *        extendedMetaData="name='IDENTIFIES-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IDENTIFIES-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Stakeholder> getIdentifies();

	/**
	 * Returns the value of the '<em><b>Aggregates</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ArchitecturalModel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Aggregates</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aggregates</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArchitecturalDescription_Aggregates()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{350F4C1F-BC3C-4cc5-ACC2-B0FD50F1E4DE}' id='11' EA\040name=''"
	 *        extendedMetaData="name='AGGREGATES' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='AGGREGATESS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ArchitecturalModel> getAggregates();

} // ArchitecturalDescription
