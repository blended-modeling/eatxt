/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Timing</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The collection of timing descriptions, namely events and event chains, and the timing constraints imposed on these events and event chains. This collection can be done across the EAST-ADL abstraction levels.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.Timing</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Timing#getDescription <em>Description</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Timing#getConstraint <em>Constraint</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTiming()
 * @model annotation="MetaData guid='{2CEFEEF0-97DB-48b5-8F8A-A8FF889DF84D}' id='143' EA\040name='Timing'"
 *        extendedMetaData="name='TIMING' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIMINGS'"
 * @generated
 */
public interface Timing extends Context {
	/**
	 * Returns the value of the '<em><b>Description</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.TimingDescription}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Description</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTiming_Description()
	 * @model containment="true"
	 *        annotation="MetaData guid='{777BCAFB-E5E7-44f8-A91C-5ED1983703F6}' id='357' EA\040name=''"
	 *        extendedMetaData="name='DESCRIPTION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DESCRIPTIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<TimingDescription> getDescription();

	/**
	 * Returns the value of the '<em><b>Constraint</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.TimingConstraint}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Constraint</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Constraint</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTiming_Constraint()
	 * @model containment="true"
	 *        annotation="MetaData guid='{1DEF8ABA-B63A-4200-8E2E-A39A935FBC20}' id='358' EA\040name=''"
	 *        extendedMetaData="name='CONSTRAINT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONSTRAINTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<TimingConstraint> getConstraint();

} // Timing
