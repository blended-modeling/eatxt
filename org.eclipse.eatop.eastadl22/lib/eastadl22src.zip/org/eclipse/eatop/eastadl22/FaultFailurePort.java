/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fault Failure Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Abstract port for Faults and Failures.
 * 
 * Semantics:
 * FaultFailurePort is abstract. Semantics is defined on its specializations.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.ErrorModel.FaultFailurePort</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.FaultFailurePort#getFunctionTarget <em>Function Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FaultFailurePort#getHwTarget <em>Hw Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFaultFailurePort()
 * @model abstract="true"
 *        annotation="MetaData guid='{D9C86659-D79C-428d-A2A4-C25086710155}' id='213' EA\040name='FaultFailurePort'"
 *        annotation="Stereotype Stereotype='atpPrototype'"
 *        extendedMetaData="name='FAULT-FAILURE-PORT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE-PORTS'"
 * @generated
 */
public interface FaultFailurePort extends EAPort, Anomaly {
	/**
	 * Returns the value of the '<em><b>Function Target</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FaultFailurePort_functionTarget}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Target</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Target</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFaultFailurePort_FunctionTarget()
	 * @model containment="true"
	 *        annotation="MetaData guid='{514D1EBA-F20D-4bc5-A976-06EE2EB753CF}' id='207' EA\040name=''"
	 *        annotation="TaggedValues xml.name='FUNCTION-TARGET-IREF' xml.namePlural='FUNCTION-TARGET-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='FUNCTION-TARGET-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-TARGET-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FaultFailurePort_functionTarget> getFunctionTarget();

	/**
	 * Returns the value of the '<em><b>Hw Target</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FaultFailurePort_hwTarget}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hw Target</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hw Target</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFaultFailurePort_HwTarget()
	 * @model containment="true"
	 *        annotation="MetaData guid='{14A3A643-FA0E-4994-AB07-1291E9AC04EC}' id='209' EA\040name=''"
	 *        annotation="TaggedValues xml.name='HW-TARGET-IREF' xml.namePlural='HW-TARGET-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='HW-TARGET-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HW-TARGET-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FaultFailurePort_hwTarget> getHwTarget();

} // FaultFailurePort
