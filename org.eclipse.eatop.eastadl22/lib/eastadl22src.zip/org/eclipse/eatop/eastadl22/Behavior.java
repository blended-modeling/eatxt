/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Behavior is a container of FunctionBehaviors. It enables grouping of the behaviors assigned to functions in a particular context on which TraceableSpecifications can be applied. This can take any appropriate form depending on the language implementation (for instance in a UML implementation it could be a Package).
 * 
 * The collection of functional behaviors can be performed across the EAST-ADL abstraction levels.
 * 
 * Semantics:
 * This element has the same role and semantics as Context, but for behavioral aspects.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Behavior.Behavior</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Behavior#getModeGroup <em>Mode Group</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Behavior#getBehavior <em>Behavior</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Behavior#getFunctionTrigger <em>Function Trigger</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehavior()
 * @model annotation="MetaData guid='{F91A9B7C-4E8A-493e-A3AC-6EABF3D20BA3}' id='91' EA\040name='Behavior'"
 *        extendedMetaData="name='BEHAVIOR' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIORS'"
 * @generated
 */
public interface Behavior extends Context {
	/**
	 * Returns the value of the '<em><b>Mode Group</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ModeGroup}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mode Group</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mode Group</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehavior_ModeGroup()
	 * @model containment="true"
	 *        annotation="MetaData guid='{D3AB94D2-D2EF-4402-B29A-C1284EE23C81}' id='518' EA\040name=''"
	 *        extendedMetaData="name='MODE-GROUP' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODE-GROUPS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ModeGroup> getModeGroup();

	/**
	 * Returns the value of the '<em><b>Behavior</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionBehavior}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Behavior</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Behavior</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehavior_Behavior()
	 * @model containment="true"
	 *        annotation="MetaData guid='{4C582E9A-0EA9-404c-93A3-33A5F971C109}' id='520' EA\040name=''"
	 *        extendedMetaData="name='BEHAVIOR' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIORS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<FunctionBehavior> getBehavior();

	/**
	 * Returns the value of the '<em><b>Function Trigger</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionTrigger}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Trigger</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Trigger</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehavior_FunctionTrigger()
	 * @model containment="true"
	 *        annotation="MetaData guid='{93C88F78-94DB-4138-BBAA-8E5EA8AD4EFB}' id='516' EA\040name=''"
	 *        extendedMetaData="name='FUNCTION-TRIGGER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-TRIGGERS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<FunctionTrigger> getFunctionTrigger();

} // Behavior
