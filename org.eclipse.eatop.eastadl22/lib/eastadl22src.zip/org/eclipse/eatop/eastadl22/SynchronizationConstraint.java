/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Synchronization Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A SynchronizationConstraint describes how tightly the occurrences of a group of events follow each other.
 * 
 * This form of synchronization only takes the width and completeness of each occurrence cluster into account; it does not care whether some events occur multiple times within a cluster or whether some clusters overlap and share occurrences. In particular, event occurrences are not partitioned into clusters according to their role or what has caused them. Stray occurrences of single events are not allowed, though, since these would just count as incomplete clusters according to this constraint.
 * 
 * Semantics:
 * A system behavior satisfies a SynchronizationConstraint c if and only if
 * there is a set of times X such that for each c.event index i, the same system behavior concurrently satisfies
 * 
 * DelayConstraint { source = X,
 * target = c.event(i),
 * lower = 0,
 * upper = c.tolerance }
 * 
 * and
 * 
 * DelayConstraint { source = c.event(i),
 * target = X,
 * lower = -c.tolerance,
 * upper = 0}
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.SynchronizationConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.SynchronizationConstraint#getTolerance <em>Tolerance</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.SynchronizationConstraint#getEvent <em>Event</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getSynchronizationConstraint()
 * @model annotation="MetaData guid='{CB1235FA-3BB1-493e-9531-EFD9DB76E640}' id='176' EA\040name='SynchronizationConstraint'"
 *        extendedMetaData="name='SYNCHRONIZATION-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SYNCHRONIZATION-CONSTRAINTS'"
 * @generated
 */
public interface SynchronizationConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Tolerance</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tolerance</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tolerance</em>' containment reference.
	 * @see #setTolerance(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getSynchronizationConstraint_Tolerance()
	 * @model containment="true"
	 *        annotation="MetaData guid='{9C5E4C56-7E38-48fc-A58E-6C337A43186D}' id='306' EA\040name=''"
	 *        extendedMetaData="name='TOLERANCE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TOLERANCES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getTolerance();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.SynchronizationConstraint#getTolerance <em>Tolerance</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tolerance</em>' containment reference.
	 * @see #getTolerance()
	 * @generated
	 */
	void setTolerance(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Event</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Event}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getSynchronizationConstraint_Event()
	 * @model lower="2"
	 *        annotation="MetaData guid='{16D52D2A-6352-4c98-92BF-C17C7BF8A853}' id='387' EA\040name=''"
	 *        extendedMetaData="name='EVENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Event> getEvent();

} // SynchronizationConstraint
