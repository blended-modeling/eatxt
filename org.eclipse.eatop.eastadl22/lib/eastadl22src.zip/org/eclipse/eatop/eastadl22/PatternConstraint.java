/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pattern Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A PatternConstraint describes an event that exhibits a known pattern relative to the occurrences of an imaginary event.
 * 
 * A PatternConstraint requires the constrained event occurrences to appear at a predetermined series of offsets from a sequence of reference points in time that are strictly periodic. The exact placement of these reference points is irrelevant; if one placement exists that is periodic and allows the event occurrences to be reached at the desired offsets, the constraint is satisfied.
 * 
 * Semantics:
 * A system behavior satisfies a PatternConstraint c if and only if
 * there is a set of times X such that the same system behavior concurrently satisfies
 * 
 * PeriodicConstraint { event = X,
 * period = c.period }
 * 
 * and for each c.offset index i,
 * 
 * DelayConstraint { source = X,
 * target = c.event,
 * lower = c.offset(i),
 * upper = c.offset(i) + c.jitter }
 * 
 * and
 * RepeatConstraint { event = c.event,
 * lower = c.minimum }
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.PatternConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.PatternConstraint#getPeriod <em>Period</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.PatternConstraint#getOffset <em>Offset</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.PatternConstraint#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.PatternConstraint#getJitter <em>Jitter</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.PatternConstraint#getEvent <em>Event</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPatternConstraint()
 * @model annotation="MetaData guid='{927FC932-AAB2-4563-BE23-3D4D4BDE0F5D}' id='171' EA\040name='PatternConstraint'"
 *        extendedMetaData="name='PATTERN-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PATTERN-CONSTRAINTS'"
 * @generated
 */
public interface PatternConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Period</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Period</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Period</em>' containment reference.
	 * @see #setPeriod(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPatternConstraint_Period()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{05A6D46B-DAE6-4e28-896E-F60839EE7AAC}' id='325' EA\040name=''"
	 *        extendedMetaData="name='PERIOD' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PERIODS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getPeriod();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.PatternConstraint#getPeriod <em>Period</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Period</em>' containment reference.
	 * @see #getPeriod()
	 * @generated
	 */
	void setPeriod(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Offset</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.TimingExpression}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Offset</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Offset</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPatternConstraint_Offset()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{F908E884-3CFF-4774-B8D4-11BE832358FB}' id='292' EA\040name=''"
	 *        extendedMetaData="name='OFFSET' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OFFSETS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<TimingExpression> getOffset();

	/**
	 * Returns the value of the '<em><b>Minimum</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Minimum</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Minimum</em>' containment reference.
	 * @see #setMinimum(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPatternConstraint_Minimum()
	 * @model containment="true"
	 *        annotation="MetaData guid='{7F5A1CD9-284E-49ed-B1A8-184B09C70761}' id='312' EA\040name=''"
	 *        extendedMetaData="name='MINIMUM' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MINIMUMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getMinimum();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.PatternConstraint#getMinimum <em>Minimum</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Minimum</em>' containment reference.
	 * @see #getMinimum()
	 * @generated
	 */
	void setMinimum(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Jitter</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Jitter</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Jitter</em>' containment reference.
	 * @see #setJitter(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPatternConstraint_Jitter()
	 * @model containment="true"
	 *        annotation="MetaData guid='{538E6842-2B4D-4196-9811-A4A98E6D563B}' id='319' EA\040name=''"
	 *        extendedMetaData="name='JITTER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='JITTERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getJitter();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.PatternConstraint#getJitter <em>Jitter</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Jitter</em>' containment reference.
	 * @see #getJitter()
	 * @generated
	 */
	void setJitter(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Event</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' reference.
	 * @see #setEvent(Event)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPatternConstraint_Event()
	 * @model required="true"
	 *        annotation="MetaData guid='{08C30D7E-C688-41e8-8063-9FE1AE8E1DAA}' id='388' EA\040name=''"
	 *        extendedMetaData="name='EVENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Event getEvent();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.PatternConstraint#getEvent <em>Event</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event</em>' reference.
	 * @see #getEvent()
	 * @generated
	 */
	void setEvent(Event value);

} // PatternConstraint
