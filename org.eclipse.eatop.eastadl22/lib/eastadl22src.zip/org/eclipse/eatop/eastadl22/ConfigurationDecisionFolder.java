/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Configuration Decision Folder</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ConfigurationDecisionFolder represents a grouping for ConfigurationDecisions.
 * 
 * 
 * Semantics:
 * ConfigurationDecisionFolder is a grouping entity for ConfigurationDecisions.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.ConfigurationDecisionFolder</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurationDecisionFolder#getChildEntry <em>Child Entry</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecisionFolder()
 * @model annotation="MetaData guid='{5A15B0F6-7F6A-43fb-BE86-FDE62A74EC30}' id='96' EA\040name='ConfigurationDecisionFolder'"
 *        extendedMetaData="name='CONFIGURATION-DECISION-FOLDER' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURATION-DECISION-FOLDERS'"
 * @generated
 */
public interface ConfigurationDecisionFolder extends ConfigurationDecisionModelEntry {
	/**
	 * Returns the value of the '<em><b>Child Entry</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ConfigurationDecisionModelEntry}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Child Entry</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Child Entry</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecisionFolder_ChildEntry()
	 * @model containment="true"
	 *        annotation="MetaData guid='{D0E39026-E04C-4dc7-926A-B907078F9D9F}' id='501' EA\040name=''"
	 *        extendedMetaData="name='CHILD-ENTRY' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CHILD-ENTRYS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ConfigurationDecisionModelEntry> getChildEntry();

} // ConfigurationDecisionFolder
