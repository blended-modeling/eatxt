/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Functional Safety Concept</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * FunctionalSafetyConcept represents the set of functional safety requirements that together fulfills a SafetyGoal in accordance with ISO 26262.
 * 
 * To comply with the SafetyGoals, the FunctionalSafetyConcept specifies the basic safety mechanisms and safety measures in the form of functional safety requirements.
 * 
 * Semantics:
 * The collection of requirements in the FunctionalSafetyConcept defines the requirements necessary to make the Item safe. The requirements are abstract and do not specify technical details.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.SafetyRequirement.FunctionalSafetyConcept</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionalSafetyConcept#getFunctionalSafetyRequirement <em>Functional Safety Requirement</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionalSafetyConcept()
 * @model annotation="MetaData guid='{F7FCC7A0-6D46-4ea7-AEDB-98049E412B32}' id='225' EA\040name='FunctionalSafetyConcept'"
 *        extendedMetaData="name='FUNCTIONAL-SAFETY-CONCEPT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTIONAL-SAFETY-CONCEPTS'"
 * @generated
 */
public interface FunctionalSafetyConcept extends RequirementsHierarchy {
	/**
	 * Returns the value of the '<em><b>Functional Safety Requirement</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Requirement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Functional Safety Requirement</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Functional Safety Requirement</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionalSafetyConcept_FunctionalSafetyRequirement()
	 * @model annotation="MetaData guid='{47C006C6-F0CD-46fb-8758-28365C7EEF85}' id='459' EA\040name=''"
	 *        extendedMetaData="name='FUNCTIONAL-SAFETY-REQUIREMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTIONAL-SAFETY-REQUIREMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Requirement> getFunctionalSafetyRequirement();

} // FunctionalSafetyConcept
