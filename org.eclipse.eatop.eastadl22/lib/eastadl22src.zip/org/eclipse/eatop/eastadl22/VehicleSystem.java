/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vehicle System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A collection of components organized to accomplish a specific function or set of functions. [IEEE 1471]
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.Needs.VehicleSystem</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleSystem#getHas <em>Has</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleSystem#getFulfills <em>Fulfills</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleSystem#getHasAn <em>Has An</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleSystem()
 * @model annotation="MetaData guid='{8D8412DD-4DAC-4d22-A90B-EAD5A74EE63F}' id='331' EA\040name='VehicleSystem'"
 *        extendedMetaData="name='VEHICLE-SYSTEM' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VEHICLE-SYSTEMS'"
 * @generated
 */
public interface VehicleSystem extends Concept {
	/**
	 * Returns the value of the '<em><b>Has</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Stakeholder}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Has</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Has</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleSystem_Has()
	 * @model required="true"
	 *        annotation="MetaData guid='{8CA99FE5-9C26-42a6-95FF-D3819AB28C51}' id='2' EA\040name=''"
	 *        extendedMetaData="name='HAS-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAS-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Stakeholder> getHas();

	/**
	 * Returns the value of the '<em><b>Fulfills</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Mission}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fulfills</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fulfills</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleSystem_Fulfills()
	 * @model required="true"
	 *        annotation="MetaData guid='{629143B8-3465-43d2-B5B5-E0B90C042930}' id='5' EA\040name=''"
	 *        extendedMetaData="name='FULFILLS-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FULFILLS-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Mission> getFulfills();

	/**
	 * Returns the value of the '<em><b>Has An</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Has An</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Has An</em>' reference.
	 * @see #setHasAn(Architecture)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleSystem_HasAn()
	 * @model required="true"
	 *        annotation="MetaData guid='{873B55D3-B008-47ff-99F2-F2AD6D832D51}' id='14' EA\040name=''"
	 *        extendedMetaData="name='HAS-AN-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAS-AN-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Architecture getHasAn();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VehicleSystem#getHasAn <em>Has An</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Has An</em>' reference.
	 * @see #getHasAn()
	 * @generated
	 */
	void setHasAn(Architecture value);

} // VehicleSystem
