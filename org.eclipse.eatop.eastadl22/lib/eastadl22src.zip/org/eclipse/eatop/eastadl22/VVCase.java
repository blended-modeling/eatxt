/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VV Case</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * VVCase represents a V&amp;V effort, i.e. it specifies concrete test subjects and targets and provides stimuli and the expected outcome on a concrete technical level.
 * 
 * Semantics:
 * VVCase is a grouping element for a set of VVProcedures that together makes up a concrete Verification/Validation effort.
 * 
 * Constraints:
 * [1] Only a concrete VVCase can have vvLog.
 * [2] Only a concrete VVCase can have vvTarget.
 * [3] Only a concrete VVCase can have an abstractVVCase.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.VerificationValidation.VVCase</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.VVCase#getAbstractVVCase <em>Abstract VV Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VVCase#getVvLog <em>Vv Log</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VVCase#getVvTarget <em>Vv Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VVCase#getVvProcedure <em>Vv Procedure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VVCase#getVvSubject <em>Vv Subject</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVCase()
 * @model annotation="MetaData guid='{9DD79931-183B-4bf2-9D86-4FC030488C2E}' id='135' EA\040name='VVCase'"
 *        extendedMetaData="name='VV-CASE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-CASES'"
 * @generated
 */
public interface VVCase extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Abstract VV Case</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Abstract VV Case</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Abstract VV Case</em>' reference.
	 * @see #setAbstractVVCase(VVCase)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVCase_AbstractVVCase()
	 * @model annotation="MetaData guid='{B425489B-8FE0-40b3-BD9B-81FCFF83AB6C}' id='399' EA\040name=''"
	 *        extendedMetaData="name='ABSTRACT-VV-CASE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ABSTRACT-VV-CASE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	VVCase getAbstractVVCase();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VVCase#getAbstractVVCase <em>Abstract VV Case</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Abstract VV Case</em>' reference.
	 * @see #getAbstractVVCase()
	 * @generated
	 */
	void setAbstractVVCase(VVCase value);

	/**
	 * Returns the value of the '<em><b>Vv Log</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVLog}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vv Log</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vv Log</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVCase_VvLog()
	 * @model containment="true"
	 *        annotation="MetaData guid='{A5D47DB5-56A7-4313-BDE7-E6E27DA7A2C2}' id='407' EA\040name=''"
	 *        extendedMetaData="name='VV-LOG' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-LOGS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<VVLog> getVvLog();

	/**
	 * Returns the value of the '<em><b>Vv Target</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVTarget}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vv Target</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vv Target</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVCase_VvTarget()
	 * @model annotation="MetaData guid='{2E42E174-964C-448c-8408-C06EC177FDDB}' id='410' EA\040name=''"
	 *        extendedMetaData="name='VV-TARGET-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-TARGET-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<VVTarget> getVvTarget();

	/**
	 * Returns the value of the '<em><b>Vv Procedure</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVProcedure}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vv Procedure</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vv Procedure</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVCase_VvProcedure()
	 * @model containment="true"
	 *        annotation="MetaData guid='{1D09171B-4DC3-40e9-8B79-0059FFDD429E}' id='420' EA\040name=''"
	 *        extendedMetaData="name='VV-PROCEDURE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-PROCEDURES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<VVProcedure> getVvProcedure();

	/**
	 * Returns the value of the '<em><b>Vv Subject</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVCase_vvSubject}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vv Subject</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vv Subject</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVCase_VvSubject()
	 * @model containment="true"
	 *        annotation="MetaData guid='{C8FC51E8-B843-413d-BBFE-E6AD471A841D}' id='398' EA\040name=''"
	 *        annotation="TaggedValues xml.name='VV-SUBJECT-IREF' xml.namePlural='VV-SUBJECT-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='VV-SUBJECT-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-SUBJECT-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<VVCase_vvSubject> getVvSubject();

} // VVCase
