/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Selection Criterion</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A mixed string description, identifying the source elements. This means that the SelectionCriterion could evaluate to True or False if a optional identifiable (feature or artifact) is referenced as target. Or evaluate to a numerical if a FeatureParameter is referenced as target.
 * 
 * Semantics:
 * If the target element of Selection Criterion is an optional element, it is retained only if the Boolean Expression represented by Selection Criterion evaluates to true. Operands are the elements identified by source instanceRef. Each operand is true if the source element is available in the model and false otherwise. 
 * If the target element of Selection Criterion is a FeatureParameter, the expression represents the value assigned to the FeatureParameter. 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.SelectionCriterion</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.SelectionCriterion#getSource <em>Source</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getSelectionCriterion()
 * @model annotation="MetaData guid='{ACC53B51-404F-47d2-8BF8-06EB513C765C}' id='103' EA\040name='SelectionCriterion'"
 *        extendedMetaData="name='SELECTION-CRITERION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SELECTION-CRITERIONS'"
 * @generated
 */
public interface SelectionCriterion extends EAExpression {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Identifiable}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getSelectionCriterion_Source()
	 * @model annotation="MetaData guid='{52471943-C235-4346-B3F3-84D3E0B20303}' id='486' EA\040name=''"
	 *        extendedMetaData="name='SOURCE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SOURCE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Identifiable> getSource();

} // SelectionCriterion
