/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Periodic Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A PeriodicConstraint describes an event that occurs periodically.
 * 
 * Semantics:
 * A system behavior satisfies a PeriodicConstraint c if and only if
 * the same system behavior satisfies
 * 
 * SporadicConstraint { event = c.event,
 * lower = c.period,
 * upper = c.period,
 * jitter = c.jitter,
 * minimum = c.minimum }
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.PeriodicConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.PeriodicConstraint#getJitter <em>Jitter</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.PeriodicConstraint#getPeriod <em>Period</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.PeriodicConstraint#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.PeriodicConstraint#getEvent <em>Event</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPeriodicConstraint()
 * @model annotation="MetaData guid='{EA564711-ED98-49ab-9481-D2051FE14FF1}' id='180' EA\040name='PeriodicConstraint'"
 *        extendedMetaData="name='PERIODIC-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PERIODIC-CONSTRAINTS'"
 * @generated
 */
public interface PeriodicConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Jitter</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Jitter</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Jitter</em>' containment reference.
	 * @see #setJitter(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPeriodicConstraint_Jitter()
	 * @model containment="true"
	 *        annotation="MetaData guid='{EBD38EB5-E701-4726-8240-2FF2F7F609D0}' id='293' EA\040name=''"
	 *        extendedMetaData="name='JITTER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='JITTERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getJitter();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.PeriodicConstraint#getJitter <em>Jitter</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Jitter</em>' containment reference.
	 * @see #getJitter()
	 * @generated
	 */
	void setJitter(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Period</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Period</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Period</em>' containment reference.
	 * @see #setPeriod(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPeriodicConstraint_Period()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{A58F99AE-A475-4619-96F9-EBF1625A67E4}' id='304' EA\040name=''"
	 *        extendedMetaData="name='PERIOD' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PERIODS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getPeriod();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.PeriodicConstraint#getPeriod <em>Period</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Period</em>' containment reference.
	 * @see #getPeriod()
	 * @generated
	 */
	void setPeriod(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Minimum</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Minimum</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Minimum</em>' containment reference.
	 * @see #setMinimum(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPeriodicConstraint_Minimum()
	 * @model containment="true"
	 *        annotation="MetaData guid='{79A3B144-4EC3-4fad-9CD9-ABBBCBFF9677}' id='314' EA\040name=''"
	 *        extendedMetaData="name='MINIMUM' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MINIMUMS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getMinimum();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.PeriodicConstraint#getMinimum <em>Minimum</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Minimum</em>' containment reference.
	 * @see #getMinimum()
	 * @generated
	 */
	void setMinimum(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Event</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' reference.
	 * @see #setEvent(Event)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPeriodicConstraint_Event()
	 * @model required="true"
	 *        annotation="MetaData guid='{92553A32-A921-4826-8A93-641D32B90091}' id='368' EA\040name=''"
	 *        extendedMetaData="name='EVENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Event getEvent();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.PeriodicConstraint#getEvent <em>Event</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event</em>' reference.
	 * @see #getEvent()
	 * @generated
	 */
	void setEvent(Event value);

} // PeriodicConstraint
