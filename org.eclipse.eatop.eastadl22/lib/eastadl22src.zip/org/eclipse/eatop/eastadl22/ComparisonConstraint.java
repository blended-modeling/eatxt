/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Comparison Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A ComparisonConstraint states that a certain ordering relation must exist between two timing expressions. 
 * 
 * This constraint is special in that it does not reference any events. Its main purpose is to express relations between arithmetic variables used in other constraint; for example, stating that the sum of the variables denoting segment delays in a time-budgeting scenario must be less than the maximum end-to-end deadline allowed.
 * 
 * Semantics:
 * A system behavior satisfies a ComparisonConstraint c if and only if
 * c.leftOperand and c.rightOperand are related according to the ordering relation given by c.operator.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.ComparisonConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ComparisonConstraint#getOperator <em>Operator</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ComparisonConstraint#getLeftOperand <em>Left Operand</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ComparisonConstraint#getRightOperand <em>Right Operand</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getComparisonConstraint()
 * @model annotation="MetaData guid='{3F6FF591-E47D-48cd-A68D-6E7E0B663014}' id='166' EA\040name='ComparisonConstraint'"
 *        extendedMetaData="name='COMPARISON-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='COMPARISON-CONSTRAINTS'"
 * @generated
 */
public interface ComparisonConstraint extends EObject {
	/**
	 * Returns the value of the '<em><b>Operator</b></em>' attribute.
	 * The default value is <code>"EQUAL"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.ComparisonKind}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Operator</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operator</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.ComparisonKind
	 * @see #isSetOperator()
	 * @see #unsetOperator()
	 * @see #setOperator(ComparisonKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getComparisonConstraint_Operator()
	 * @model default="EQUAL" unsettable="true" required="true"
	 *        annotation="MetaData guid='{64903AE1-EA4A-48b1-B5ED-7716B6BC2BA1}' id='109' EA\040name='operator'"
	 *        extendedMetaData="name='OPERATOR' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OPERATORS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	ComparisonKind getOperator();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ComparisonConstraint#getOperator <em>Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operator</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.ComparisonKind
	 * @see #isSetOperator()
	 * @see #Operator()
	 * @see #getOperator()
	 * @generated
	 */
	void setOperator(ComparisonKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.ComparisonConstraint#getOperator <em>Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetOperator()
	 * @see #getOperator()
	 * @see #setOperator(ComparisonKind)
	 * @generated
	 */
	void unsetOperator();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.ComparisonConstraint#getOperator <em>Operator</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Operator</em>' attribute is set.
	 * @see #Operator()
	 * @see #getOperator()
	 * @see #setOperator(ComparisonKind)
	 * @generated
	 */
	boolean isSetOperator();

	/**
	 * Returns the value of the '<em><b>Left Operand</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Left Operand</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Left Operand</em>' containment reference.
	 * @see #setLeftOperand(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getComparisonConstraint_LeftOperand()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{B9D56E36-B3AE-4814-B0CB-EAD46B523F1D}' id='301' EA\040name=''"
	 *        extendedMetaData="name='LEFT-OPERAND' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LEFT-OPERANDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getLeftOperand();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ComparisonConstraint#getLeftOperand <em>Left Operand</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Left Operand</em>' containment reference.
	 * @see #getLeftOperand()
	 * @generated
	 */
	void setLeftOperand(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Right Operand</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Right Operand</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Right Operand</em>' containment reference.
	 * @see #setRightOperand(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getComparisonConstraint_RightOperand()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{4BCE460A-2AB7-444f-9382-C90F2C98C8A2}' id='320' EA\040name=''"
	 *        extendedMetaData="name='RIGHT-OPERAND' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='RIGHT-OPERANDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getRightOperand();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ComparisonConstraint#getRightOperand <em>Right Operand</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Right Operand</em>' containment reference.
	 * @see #getRightOperand()
	 * @generated
	 */
	void setRightOperand(TimingExpression value);

} // ComparisonConstraint
