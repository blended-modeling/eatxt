/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Internal Fault Prototype</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The InternalFault metaclass represents the particular internal conditions of the target component/system that are of particular concern for its fault/failure definition. 
 * 
 * Semantics:
 * The system anomaly represented by an InternalFault, which when activated, can cause errors and failures of the target element.
 * 
 * Extension:
 * UML::Part / UML::Event
 * 
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.ErrorModel.InternalFaultPrototype</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getInternalFaultPrototype()
 * @model annotation="MetaData guid='{19AE897C-45E8-464a-A870-68F0603C7962}' id='204' EA\040name='InternalFaultPrototype'"
 *        extendedMetaData="name='INTERNAL-FAULT-PROTOTYPE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INTERNAL-FAULT-PROTOTYPES'"
 * @generated
 */
public interface InternalFaultPrototype extends Anomaly {
} // InternalFaultPrototype
