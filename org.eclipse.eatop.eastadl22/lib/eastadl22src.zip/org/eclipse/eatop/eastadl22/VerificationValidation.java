/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Verification Validation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The collection of verification and validation elements. This collection can be used across the EAST-ADL abstraction levels.
 * 
 * Semantics:
 * VerificationValidation is a container element for a set of related vvTarget and vvCase elements and verify relationships.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.VerificationValidation.VerificationValidation</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.VerificationValidation#getVerify <em>Verify</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VerificationValidation#getVvCase <em>Vv Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VerificationValidation#getVvTarget <em>Vv Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVerificationValidation()
 * @model annotation="MetaData guid='{BAF85B8E-7E65-414d-86F1-A7DB96B3AFCA}' id='136' EA\040name='VerificationValidation'"
 *        extendedMetaData="name='VERIFICATION-VALIDATION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VERIFICATION-VALIDATIONS'"
 * @generated
 */
public interface VerificationValidation extends Context {
	/**
	 * Returns the value of the '<em><b>Verify</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Verify}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Verify</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Verify</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVerificationValidation_Verify()
	 * @model containment="true"
	 *        annotation="MetaData guid='{E80ACC4D-751A-458b-BF14-9A4EB6EE82BE}' id='395' EA\040name=''"
	 *        extendedMetaData="name='VERIFY' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VERIFYS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Verify> getVerify();

	/**
	 * Returns the value of the '<em><b>Vv Case</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVCase}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vv Case</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vv Case</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVerificationValidation_VvCase()
	 * @model containment="true"
	 *        annotation="MetaData guid='{1E53C210-6D1F-4675-8E79-234AB219C581}' id='401' EA\040name=''"
	 *        extendedMetaData="name='VV-CASE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-CASES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<VVCase> getVvCase();

	/**
	 * Returns the value of the '<em><b>Vv Target</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVTarget}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vv Target</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vv Target</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVerificationValidation_VvTarget()
	 * @model containment="true"
	 *        annotation="MetaData guid='{48CDEBC8-AEA2-409d-A515-78218F0B9035}' id='409' EA\040name=''"
	 *        extendedMetaData="name='VV-TARGET' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-TARGETS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<VVTarget> getVvTarget();

} // VerificationValidation
