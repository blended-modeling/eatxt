/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Function Client Server Port port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.Events._instanceRef.EventFunctionClientServerPort_port</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPort_port#getFunctionClientServerPort <em>Function Client Server Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPort_port#getFunctionPrototype <em>Function Prototype</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunctionClientServerPort_port()
 * @model annotation="MetaData guid='{B33A7B0C-86B3-404f-83B1-4C932929BD00}' id='164' EA\040name='EventFunctionClientServerPort_port'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='EVENT-FUNCTION-CLIENT-SERVER-PORT--PORT-IREF'"
 *        extendedMetaData="name='EVENT-FUNCTION-CLIENT-SERVER-PORT--PORT-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-FUNCTION-CLIENT-SERVER-PORT--PORT-IREFS'"
 * @generated
 */
public interface EventFunctionClientServerPort_port extends EObject {
	/**
	 * Returns the value of the '<em><b>Function Client Server Port</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Client Server Port</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Client Server Port</em>' reference.
	 * @see #setFunctionClientServerPort(FunctionClientServerPort)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunctionClientServerPort_port_FunctionClientServerPort()
	 * @model required="true"
	 *        annotation="MetaData guid='{97D948DB-810B-4945-B66D-E0ED988613DE}' id='604' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.target'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='FUNCTION-CLIENT-SERVER-PORT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-CLIENT-SERVER-PORT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FunctionClientServerPort getFunctionClientServerPort();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPort_port#getFunctionClientServerPort <em>Function Client Server Port</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function Client Server Port</em>' reference.
	 * @see #getFunctionClientServerPort()
	 * @generated
	 */
	void setFunctionClientServerPort(FunctionClientServerPort value);

	/**
	 * Returns the value of the '<em><b>Function Prototype</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Prototype</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Prototype</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunctionClientServerPort_port_FunctionPrototype()
	 * @model annotation="MetaData guid='{5E4063E9-C9D0-4c8e-A8C8-6D9FEA3EA19A}' id='627' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.context'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='FUNCTION-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FunctionPrototype> getFunctionPrototype();

} // EventFunctionClientServerPort_port
