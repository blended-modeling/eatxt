/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Discrete transitions (Transition) describe the possible switches between discrete states due to the occurrences of discrete events or due to the violations of a state invariant in time or in value quantification.
 * 
 * See also Transition.
 * 
 * Constraints:
 * [1] A transition connects one or two states. This means that the from and to roles can be applied to two distinct states or a single state.
 * 
 * Semantics:
 * When all the given guard conditions are met, a transition will be fired. A transition, when fired, will lead to the exit of the associated "from" state and an entrance to the associated "to" state, while invoking one or more logical transformations (TransformationOccurrance! ) as the effects of the transition.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.TemporalConstraint.Transition</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Transition#getFrom <em>From</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Transition#getTo <em>To</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Transition#getTimeGuard <em>Time Guard</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Transition#getEffect <em>Effect</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Transition#getQuantificationGuard <em>Quantification Guard</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTransition()
 * @model annotation="MetaData guid='{7901347F-9D43-4391-9460-E29E61BBCF62}' id='319' EA\040name='Transition'"
 *        extendedMetaData="name='TRANSITION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TRANSITIONS'"
 * @generated
 */
public interface Transition extends EAElement {
	/**
	 * Returns the value of the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>From</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>From</em>' reference.
	 * @see #setFrom(State)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTransition_From()
	 * @model required="true"
	 *        annotation="MetaData guid='{8CD01BBF-A6BA-4cf4-A85A-516BBC18D902}' id='22' EA\040name=''"
	 *        extendedMetaData="name='FROM-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FROM-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	State getFrom();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Transition#getFrom <em>From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>From</em>' reference.
	 * @see #getFrom()
	 * @generated
	 */
	void setFrom(State value);

	/**
	 * Returns the value of the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To</em>' reference.
	 * @see #setTo(State)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTransition_To()
	 * @model required="true"
	 *        annotation="MetaData guid='{34570677-E66D-43e8-B614-C498CE84A8EE}' id='23' EA\040name=''"
	 *        extendedMetaData="name='TO-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TO-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	State getTo();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Transition#getTo <em>To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>To</em>' reference.
	 * @see #getTo()
	 * @generated
	 */
	void setTo(State value);

	/**
	 * Returns the value of the '<em><b>Time Guard</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.LogicalTimeCondition}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time Guard</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time Guard</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTransition_TimeGuard()
	 * @model annotation="MetaData guid='{5462361E-8AEF-4617-A566-397D8E3A7FDE}' id='27' EA\040name=''"
	 *        extendedMetaData="name='TIME-GUARD-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIME-GUARD-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<LogicalTimeCondition> getTimeGuard();

	/**
	 * Returns the value of the '<em><b>Effect</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Effect</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Effect</em>' reference.
	 * @see #setEffect(TransformationOccurrence)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTransition_Effect()
	 * @model annotation="MetaData guid='{E5CC2B3B-E3A8-4b6e-BD37-3BF59B7A5C1C}' id='40' EA\040name=''"
	 *        extendedMetaData="name='EFFECT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EFFECT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TransformationOccurrence getEffect();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Transition#getEffect <em>Effect</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Effect</em>' reference.
	 * @see #getEffect()
	 * @generated
	 */
	void setEffect(TransformationOccurrence value);

	/**
	 * Returns the value of the '<em><b>Quantification Guard</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Quantification}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Quantification Guard</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Quantification Guard</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTransition_QuantificationGuard()
	 * @model annotation="MetaData guid='{4B638531-043C-443a-91BA-72B30929D63D}' id='47' EA\040name=''"
	 *        extendedMetaData="name='QUANTIFICATION-GUARD-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='QUANTIFICATION-GUARD-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Quantification> getQuantificationGuard();

} // Transition
