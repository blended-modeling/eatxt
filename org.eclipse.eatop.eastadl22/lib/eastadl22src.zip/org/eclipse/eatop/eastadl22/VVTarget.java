/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VV Target</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * VVTarget represents a concrete testing environment in which a particular V&amp;V activity can be performed. This can be physical hardware or it can be pure software in case of a test by way of design level simulations.
 * 
 * Usually, a VVTarget will identify one or more elements. However, there are cases in which this is not true, for example when a VVTarget represents parts of the system's environment. Therefore the association to element has a minimum cardinality of 0.
 * 
 * VVTargets can be reused across several concrete VVCases.
 * 
 * Semantics:
 * VVTarget represents a concrete testing environment in which a particular Verification/Validation activity is performed.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.VerificationValidation.VVTarget</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.VVTarget#getElement <em>Element</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVTarget()
 * @model annotation="MetaData guid='{53B3D5E9-720A-4560-989E-F266753C39F4}' id='132' EA\040name='VVTarget'"
 *        extendedMetaData="name='VV-TARGET' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VV-TARGETS'"
 * @generated
 */
public interface VVTarget extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Element</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VVTarget_element}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Element</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVVTarget_Element()
	 * @model containment="true"
	 *        annotation="MetaData guid='{1EFC5CA3-9EA3-4361-8AAF-F0EB5E0AFA65}' id='411' EA\040name=''"
	 *        annotation="TaggedValues xml.name='ELEMENT-IREF' xml.namePlural='ELEMENT-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='ELEMENT-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ELEMENT-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<VVTarget_element> getElement();

} // VVTarget
