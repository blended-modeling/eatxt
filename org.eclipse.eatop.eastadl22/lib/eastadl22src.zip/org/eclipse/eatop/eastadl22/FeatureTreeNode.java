/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Tree Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The abstract base class for all nodes in a feature tree.
 * 
 * 
 * Semantics:
 * FeatureTreeNode has no specific semantics. Further subclasses of FeatureTreeNode will add semantics appropriate to the concept they represent.
 * 
 * 
 * Extension: 
 * abstract, no extension
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.FeatureModeling.FeatureTreeNode</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFeatureTreeNode()
 * @model abstract="true"
 *        annotation="MetaData guid='{4F6AC2C6-2625-48f5-B073-E8300DC4E645}' id='25' EA\040name='FeatureTreeNode'"
 *        extendedMetaData="name='FEATURE-TREE-NODE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURE-TREE-NODES'"
 * @generated
 */
public interface FeatureTreeNode extends Context {
} // FeatureTreeNode
