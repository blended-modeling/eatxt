/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Configuration Decision Model Entry</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ConfigurationDecisionModelEntry is the abstract base class for all content of a ConfigurationDecisionModel.
 * 
 * Semantics:
 * See description.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.ConfigurationDecisionModelEntry</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurationDecisionModelEntry#getIsActive <em>Is Active</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecisionModelEntry()
 * @model abstract="true"
 *        annotation="MetaData guid='{7B0AB772-1974-4f7d-A9CD-860916A0611A}' id='101' EA\040name='ConfigurationDecisionModelEntry'"
 *        extendedMetaData="name='CONFIGURATION-DECISION-MODEL-ENTRY' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURATION-DECISION-MODEL-ENTRYS'"
 * @generated
 */
public interface ConfigurationDecisionModelEntry extends EAElement {
	/**
	 * Returns the value of the '<em><b>Is Active</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * If active==TRUE then the ConfigurationDecisionModelEntry is actually applied when transforming source into target configurations; otherwise it will be ignored. With this attribute, configuration decisions can (temporarily) be disabled without having to delete them from the model.
	 * 
	 * If this is set to FALSE for a ConfigurationDecisionFolder, then the entire contents of this folder is deactivated, no matter to what value their isActive-attribute is set.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Active</em>' attribute.
	 * @see #isSetIsActive()
	 * @see #unsetIsActive()
	 * @see #setIsActive(Boolean)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecisionModelEntry_IsActive()
	 * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Boolean" required="true"
	 *        annotation="MetaData guid='{2C3604C1-12AA-4878-84A3-286A793C1420}' id='83' EA\040name='isActive'"
	 *        extendedMetaData="name='IS-ACTIVE' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-ACTIVES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Boolean getIsActive();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecisionModelEntry#getIsActive <em>Is Active</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Active</em>' attribute.
	 * @see #isSetIsActive()
	 * @see #IsActive()
	 * @see #getIsActive()
	 * @generated
	 */
	void setIsActive(Boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecisionModelEntry#getIsActive <em>Is Active</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsActive()
	 * @see #getIsActive()
	 * @see #setIsActive(Boolean)
	 * @generated
	 */
	void unsetIsActive();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecisionModelEntry#getIsActive <em>Is Active</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Active</em>' attribute is set.
	 * @see #IsActive()
	 * @see #getIsActive()
	 * @see #setIsActive(Boolean)
	 * @generated
	 */
	boolean isSetIsActive();

} // ConfigurationDecisionModelEntry
