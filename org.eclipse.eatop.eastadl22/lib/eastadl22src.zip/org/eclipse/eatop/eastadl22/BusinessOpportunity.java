/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Business Opportunity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The business opportunity represents a brief description of the business opportunity being met by developing the electrical/electronic system which establishes traceability from artifacts created later, for example to provide rationales to design decisions or trade-off analysis.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.Needs.BusinessOpportunity</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BusinessOpportunity#getBusinessOpportunity <em>Business Opportunity</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BusinessOpportunity#getProductPositioning <em>Product Positioning</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BusinessOpportunity#getProblemStatement <em>Problem Statement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BusinessOpportunity#getMotivatesDevelopmentOf <em>Motivates Development Of</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBusinessOpportunity()
 * @model annotation="MetaData guid='{0A1651B4-E270-4476-93DE-71CB68C8876B}' id='325' EA\040name='BusinessOpportunity'"
 *        extendedMetaData="name='BUSINESS-OPPORTUNITY' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BUSINESS-OPPORTUNITYS'"
 * @generated
 */
public interface BusinessOpportunity extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Business Opportunity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This attribute holds a brief description of the business opportunity being met by developing the electrical/electronic system. This redefines the text attribute in TraceableSpecification.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Business Opportunity</em>' attribute.
	 * @see #isSetBusinessOpportunity()
	 * @see #unsetBusinessOpportunity()
	 * @see #setBusinessOpportunity(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBusinessOpportunity_BusinessOpportunity()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String" required="true"
	 *        annotation="MetaData guid='{3B83FD7F-BF4B-4d76-946F-1FD0867F2B3E}' id='219' EA\040name='businessOpportunity'"
	 *        extendedMetaData="name='BUSINESS-OPPORTUNITY' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BUSINESS-OPPORTUNITYS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getBusinessOpportunity();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BusinessOpportunity#getBusinessOpportunity <em>Business Opportunity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Business Opportunity</em>' attribute.
	 * @see #isSetBusinessOpportunity()
	 * @see #BusinessOpportunity()
	 * @see #getBusinessOpportunity()
	 * @generated
	 */
	void setBusinessOpportunity(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.BusinessOpportunity#getBusinessOpportunity <em>Business Opportunity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetBusinessOpportunity()
	 * @see #getBusinessOpportunity()
	 * @see #setBusinessOpportunity(String)
	 * @generated
	 */
	void unsetBusinessOpportunity();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.BusinessOpportunity#getBusinessOpportunity <em>Business Opportunity</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Business Opportunity</em>' attribute is set.
	 * @see #BusinessOpportunity()
	 * @see #getBusinessOpportunity()
	 * @see #setBusinessOpportunity(String)
	 * @generated
	 */
	boolean isSetBusinessOpportunity();

	/**
	 * Returns the value of the '<em><b>Product Positioning</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ProductPositioning}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Positioning</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Positioning</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBusinessOpportunity_ProductPositioning()
	 * @model annotation="MetaData guid='{57C0CC70-73D6-4bda-BA7C-14B924E270C4}' id='12' EA\040name=''"
	 *        extendedMetaData="name='PRODUCT-POSITIONING-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRODUCT-POSITIONING-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<ProductPositioning> getProductPositioning();

	/**
	 * Returns the value of the '<em><b>Problem Statement</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ProblemStatement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Problem Statement</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Problem Statement</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBusinessOpportunity_ProblemStatement()
	 * @model annotation="MetaData guid='{13E26E58-B7E5-4709-93F6-448B72B13762}' id='13' EA\040name=''"
	 *        extendedMetaData="name='PROBLEM-STATEMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PROBLEM-STATEMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<ProblemStatement> getProblemStatement();

	/**
	 * Returns the value of the '<em><b>Motivates Development Of</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.SystemModel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Motivates Development Of</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motivates Development Of</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBusinessOpportunity_MotivatesDevelopmentOf()
	 * @model required="true"
	 *        annotation="MetaData guid='{F7606713-7962-436e-A91E-CF4A06A6E59F}' id='722' EA\040name=''"
	 *        extendedMetaData="name='MOTIVATES-DEVELOPMENT-OF-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MOTIVATES-DEVELOPMENT-OF-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<SystemModel> getMotivatesDevelopmentOf();

} // BusinessOpportunity
