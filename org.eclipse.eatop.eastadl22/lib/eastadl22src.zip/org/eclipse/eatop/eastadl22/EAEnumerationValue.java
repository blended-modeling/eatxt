/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EA Enumeration Value</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * EnumerationValue represents a value for an Enumeration or several values in a multivalued Enumeration.
 * 
 * Constraints:
 * [1] Shall be typed by an Enumeration.
 * 
 * Semantics:
 * The semantics of this value is defined by the typing Enumeration or the semantics defined in the EnumerationValue.
 * 
 * Extension:
 * UML:InstanceSpecification
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Infrastructure.Values.EAEnumerationValue</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.EAEnumerationValue#getValue <em>Value</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEAEnumerationValue()
 * @model annotation="MetaData guid='{3D2374C5-E3D6-4dd4-9029-D81A4E41938F}' id='273' EA\040name='EAEnumerationValue'"
 *        extendedMetaData="name='EA-ENUMERATION-VALUE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EA-ENUMERATION-VALUES'"
 * @generated
 */
public interface EAEnumerationValue extends EAValue {
	/**
	 * Returns the value of the '<em><b>Value</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.EnumerationLiteral}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEAEnumerationValue_Value()
	 * @model required="true"
	 *        annotation="MetaData guid='{674E5981-E731-4d98-9F3A-E180D6F4CAB6}' id='102' EA\040name=''"
	 *        extendedMetaData="name='VALUE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VALUE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<EnumerationLiteral> getValue();

} // EAEnumerationValue
