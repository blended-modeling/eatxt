/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Internal Binding</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * BehaviorConstraintInternalBinding is the modeling construct for the declaration of parameters to be shared by the parts (i.e. behavior constraint prototypes) of a behavior constraint type. In other words, a behavior constraint type uses such parameters to bind the parameters of its parts (BehaviorConstraintType.part:BehaviorConstraintPrototype.instantiationVariable). For such a binding, the declarations of prototype instantiation (BehaviorConstraintType.part:BehaviorConstraintPrototype.instantiationVariable) refer directly to the part binding parameters of the instantiation context (BehaviorConstraintType.partBindingParameter)
 * 
 * Each binding parameter can have a structural correspondence (bindingThroughFunctionConnector, bindingThroughClampConnector, bindingThrough-LogicalBus, or bindingThrough-HardwareConnector), stating the structural channels through which the binding takes place.
 * 
 * In the meta-model, the abstract binding parameter is further specialized into
 * * BehaviorConstraintBindingAttribute - the contextual parameters that are value attributes.
 * * BehaviorConstraintBindingEvent - the contextual parameters that are discrete events.
 * 
 * Constraints:
 * [1] When a binding of behavior constraint prototypes go across different system functions or components, there should be at least one corresponding structural communication connector through which such bindings can take place (i.e. bindingThroughFunctionConnector, bindingThroughClampConnector, bindingThrough-LogicalBus, or bindingThrough-HardwareConnector).
 * 
 * Semantics:
 * A BehaviorConstraintBindingParameter is an event- or data- channel connecting behaviors. See also Attribute and TransitionEvent.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.BehaviorConstraintInternalBinding</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding#getBindingThroughHardwareConnector <em>Binding Through Hardware Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding#getBindingThroughFunctionConnector <em>Binding Through Function Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding#getBindingThroughClampConnector <em>Binding Through Clamp Connector</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding()
 * @model abstract="true"
 *        annotation="MetaData guid='{07A70B5F-6F72-4d4f-A52F-E06ABEB9C222}' id='291' EA\040name='BehaviorConstraintInternalBinding'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-INTERNAL-BINDING' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-INTERNAL-BINDINGS'"
 * @generated
 */
public interface BehaviorConstraintInternalBinding extends EObject {
	/**
	 * Returns the value of the '<em><b>Binding Through Hardware Connector</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Binding Through Hardware Connector</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Binding Through Hardware Connector</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding_BindingThroughHardwareConnector()
	 * @model containment="true"
	 *        annotation="MetaData guid='{B067E5F6-FDCC-4186-A217-17FCFE4D2B63}' id='78' EA\040name=''"
	 *        annotation="TaggedValues xml.name='BINDING-THROUGH-HARDWARE-CONNECTOR-IREF' xml.namePlural='BINDING-THROUGH-HARDWARE-CONNECTOR-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='BINDING-THROUGH-HARDWARE-CONNECTOR-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BINDING-THROUGH-HARDWARE-CONNECTOR-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<BehaviorConstraintInternalBinding_bindingThroughHardwareConnector> getBindingThroughHardwareConnector();

	/**
	 * Returns the value of the '<em><b>Binding Through Function Connector</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Binding Through Function Connector</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Binding Through Function Connector</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding_BindingThroughFunctionConnector()
	 * @model containment="true"
	 *        annotation="MetaData guid='{75A9A639-344A-4665-9FFF-ED1418216E8F}' id='80' EA\040name=''"
	 *        annotation="TaggedValues xml.name='BINDING-THROUGH-FUNCTION-CONNECTOR-IREF' xml.namePlural='BINDING-THROUGH-FUNCTION-CONNECTOR-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='BINDING-THROUGH-FUNCTION-CONNECTOR-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BINDING-THROUGH-FUNCTION-CONNECTOR-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<BehaviorConstraintInternalBinding_bindingThroughFunctionConnector> getBindingThroughFunctionConnector();

	/**
	 * Returns the value of the '<em><b>Binding Through Clamp Connector</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ClampConnector}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Binding Through Clamp Connector</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Binding Through Clamp Connector</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding_BindingThroughClampConnector()
	 * @model annotation="MetaData guid='{3D165515-8139-4d3c-911A-CDB402D7ECAC}' id='539' EA\040name=''"
	 *        extendedMetaData="name='BINDING-THROUGH-CLAMP-CONNECTOR-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BINDING-THROUGH-CLAMP-CONNECTOR-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<ClampConnector> getBindingThroughClampConnector();

} // BehaviorConstraintInternalBinding
