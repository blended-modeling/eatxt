/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mission</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A mission is a use or operation for which a system is intended by one or more stakeholders to meet some set of objectives. [IEEE 1471]
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.Needs.Mission</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getMission()
 * @model annotation="MetaData guid='{5AC452A1-9F2D-4eb9-AB56-4A7A5C8CB728}' id='329' EA\040name='Mission'"
 *        extendedMetaData="name='MISSION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MISSIONS'"
 * @generated
 */
public interface Mission extends Concept {
} // Mission
