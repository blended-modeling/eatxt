/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Deviation Attribute Set</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * DeviationAttributeSet specifies the set of rules of allowed deviations from the reference model in a referring model. These rules are important, because they make sure that the different FeatureModels, referring to one reference model, follow specific rules for deviation, so a later integration into one FeatureModel may be possible.
 * 
 * Semantics:
 * See description.
 * 
 * Extension:
 * DataType
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.VehicleFeatureModeling.DeviationAttributeSet</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeAttribute <em>Allow Change Attribute</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeCardinality <em>Allow Change Cardinality</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeDescription <em>Allow Change Description</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeName <em>Allow Change Name</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowMove <em>Allow Move</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowReduction <em>Allow Reduction</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRefinement <em>Allow Refinement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRegrouping <em>Allow Regrouping</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRemoval <em>Allow Removal</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet()
 * @model annotation="MetaData guid='{9AC778D3-AA92-496b-B679-67EE67BA78FB}' id='33' EA\040name='DeviationAttributeSet'"
 *        extendedMetaData="name='DEVIATION-ATTRIBUTE-SET' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DEVIATION-ATTRIBUTE-SETS'"
 * @generated
 */
public interface DeviationAttributeSet extends EAElement {
	/**
	 * Returns the value of the '<em><b>Allow Change Attribute</b></em>' attribute.
	 * The default value is <code>"NO"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.DeviationPermissionKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This rule sets whether and how the VehicleFeature attributes may be changed. Allowed values: no, append, yes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Allow Change Attribute</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowChangeAttribute()
	 * @see #unsetAllowChangeAttribute()
	 * @see #setAllowChangeAttribute(DeviationPermissionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet_AllowChangeAttribute()
	 * @model default="NO" unsettable="true" required="true"
	 *        annotation="MetaData guid='{B01DD152-191A-4535-92A9-4C147AF447DC}' id='23' EA\040name='allowChangeAttribute'"
	 *        extendedMetaData="name='ALLOW-CHANGE-ATTRIBUTE' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOW-CHANGE-ATTRIBUTES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationPermissionKind getAllowChangeAttribute();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeAttribute <em>Allow Change Attribute</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allow Change Attribute</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowChangeAttribute()
	 * @see #AllowChangeAttribute()
	 * @see #getAllowChangeAttribute()
	 * @generated
	 */
	void setAllowChangeAttribute(DeviationPermissionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeAttribute <em>Allow Change Attribute</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAllowChangeAttribute()
	 * @see #getAllowChangeAttribute()
	 * @see #setAllowChangeAttribute(DeviationPermissionKind)
	 * @generated
	 */
	void unsetAllowChangeAttribute();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeAttribute <em>Allow Change Attribute</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Allow Change Attribute</em>' attribute is set.
	 * @see #AllowChangeAttribute()
	 * @see #getAllowChangeAttribute()
	 * @see #setAllowChangeAttribute(DeviationPermissionKind)
	 * @generated
	 */
	boolean isSetAllowChangeAttribute();

	/**
	 * Returns the value of the '<em><b>Allow Change Cardinality</b></em>' attribute.
	 * The default value is <code>"NO"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.DeviationPermissionKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This rule sets whether and how the VehicleFeature cardinality (i.e. variability of the VehicleFeature) may be changed. Allowed values: no, subset, yes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Allow Change Cardinality</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowChangeCardinality()
	 * @see #unsetAllowChangeCardinality()
	 * @see #setAllowChangeCardinality(DeviationPermissionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet_AllowChangeCardinality()
	 * @model default="NO" unsettable="true" required="true"
	 *        annotation="MetaData guid='{8267737E-743E-4c3a-8325-989505291719}' id='24' EA\040name='allowChangeCardinality'"
	 *        extendedMetaData="name='ALLOW-CHANGE-CARDINALITY' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOW-CHANGE-CARDINALITYS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationPermissionKind getAllowChangeCardinality();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeCardinality <em>Allow Change Cardinality</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allow Change Cardinality</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowChangeCardinality()
	 * @see #AllowChangeCardinality()
	 * @see #getAllowChangeCardinality()
	 * @generated
	 */
	void setAllowChangeCardinality(DeviationPermissionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeCardinality <em>Allow Change Cardinality</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAllowChangeCardinality()
	 * @see #getAllowChangeCardinality()
	 * @see #setAllowChangeCardinality(DeviationPermissionKind)
	 * @generated
	 */
	void unsetAllowChangeCardinality();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeCardinality <em>Allow Change Cardinality</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Allow Change Cardinality</em>' attribute is set.
	 * @see #AllowChangeCardinality()
	 * @see #getAllowChangeCardinality()
	 * @see #setAllowChangeCardinality(DeviationPermissionKind)
	 * @generated
	 */
	boolean isSetAllowChangeCardinality();

	/**
	 * Returns the value of the '<em><b>Allow Change Description</b></em>' attribute.
	 * The default value is <code>"NO"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.DeviationPermissionKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This rule sets whether and how the VehicleFeature description may be changed. Allowed values: no, append, yes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Allow Change Description</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowChangeDescription()
	 * @see #unsetAllowChangeDescription()
	 * @see #setAllowChangeDescription(DeviationPermissionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet_AllowChangeDescription()
	 * @model default="NO" unsettable="true" required="true"
	 *        annotation="MetaData guid='{A5B8E0A0-34DA-4978-92B2-7C24A121527A}' id='25' EA\040name='allowChangeDescription'"
	 *        extendedMetaData="name='ALLOW-CHANGE-DESCRIPTION' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOW-CHANGE-DESCRIPTIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationPermissionKind getAllowChangeDescription();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeDescription <em>Allow Change Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allow Change Description</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowChangeDescription()
	 * @see #AllowChangeDescription()
	 * @see #getAllowChangeDescription()
	 * @generated
	 */
	void setAllowChangeDescription(DeviationPermissionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeDescription <em>Allow Change Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAllowChangeDescription()
	 * @see #getAllowChangeDescription()
	 * @see #setAllowChangeDescription(DeviationPermissionKind)
	 * @generated
	 */
	void unsetAllowChangeDescription();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeDescription <em>Allow Change Description</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Allow Change Description</em>' attribute is set.
	 * @see #AllowChangeDescription()
	 * @see #getAllowChangeDescription()
	 * @see #setAllowChangeDescription(DeviationPermissionKind)
	 * @generated
	 */
	boolean isSetAllowChangeDescription();

	/**
	 * Returns the value of the '<em><b>Allow Change Name</b></em>' attribute.
	 * The default value is <code>"NO"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.DeviationPermissionKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This rule sets whether and how the VehicleFeature name may be changed. Allowed values: no, append, yes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Allow Change Name</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowChangeName()
	 * @see #unsetAllowChangeName()
	 * @see #setAllowChangeName(DeviationPermissionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet_AllowChangeName()
	 * @model default="NO" unsettable="true" required="true"
	 *        annotation="MetaData guid='{3949E4E3-C901-4c8a-8357-EF04B86CC3E7}' id='26' EA\040name='allowChangeName'"
	 *        extendedMetaData="name='ALLOW-CHANGE-NAME' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOW-CHANGE-NAMES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationPermissionKind getAllowChangeName();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeName <em>Allow Change Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allow Change Name</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowChangeName()
	 * @see #AllowChangeName()
	 * @see #getAllowChangeName()
	 * @generated
	 */
	void setAllowChangeName(DeviationPermissionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeName <em>Allow Change Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAllowChangeName()
	 * @see #getAllowChangeName()
	 * @see #setAllowChangeName(DeviationPermissionKind)
	 * @generated
	 */
	void unsetAllowChangeName();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowChangeName <em>Allow Change Name</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Allow Change Name</em>' attribute is set.
	 * @see #AllowChangeName()
	 * @see #getAllowChangeName()
	 * @see #setAllowChangeName(DeviationPermissionKind)
	 * @generated
	 */
	boolean isSetAllowChangeName();

	/**
	 * Returns the value of the '<em><b>Allow Move</b></em>' attribute.
	 * The default value is <code>"NO"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.DeviationPermissionKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This rule sets whether and how the VehicleFeature may be moved to another place in the feature diagram. Allowed values: no, subtree, yes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Allow Move</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowMove()
	 * @see #unsetAllowMove()
	 * @see #setAllowMove(DeviationPermissionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet_AllowMove()
	 * @model default="NO" unsettable="true" required="true"
	 *        annotation="MetaData guid='{4AA19E52-C723-4f97-B3D1-F8308F6D654B}' id='27' EA\040name='allowMove'"
	 *        extendedMetaData="name='ALLOW-MOVE' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOW-MOVES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationPermissionKind getAllowMove();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowMove <em>Allow Move</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allow Move</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowMove()
	 * @see #AllowMove()
	 * @see #getAllowMove()
	 * @generated
	 */
	void setAllowMove(DeviationPermissionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowMove <em>Allow Move</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAllowMove()
	 * @see #getAllowMove()
	 * @see #setAllowMove(DeviationPermissionKind)
	 * @generated
	 */
	void unsetAllowMove();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowMove <em>Allow Move</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Allow Move</em>' attribute is set.
	 * @see #AllowMove()
	 * @see #getAllowMove()
	 * @see #setAllowMove(DeviationPermissionKind)
	 * @generated
	 */
	boolean isSetAllowMove();

	/**
	 * Returns the value of the '<em><b>Allow Reduction</b></em>' attribute.
	 * The default value is <code>"NO"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.DeviationPermissionKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This rule sets if the reference feature may have a child without a corresponding referring feature among the children of the referring feature. Allowed values: no, subtree, yes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Allow Reduction</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowReduction()
	 * @see #unsetAllowReduction()
	 * @see #setAllowReduction(DeviationPermissionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet_AllowReduction()
	 * @model default="NO" unsettable="true" required="true"
	 *        annotation="MetaData guid='{140981EA-E7C2-4440-BDC3-A97B0C5D4446}' id='28' EA\040name='allowReduction'"
	 *        extendedMetaData="name='ALLOW-REDUCTION' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOW-REDUCTIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationPermissionKind getAllowReduction();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowReduction <em>Allow Reduction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allow Reduction</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowReduction()
	 * @see #AllowReduction()
	 * @see #getAllowReduction()
	 * @generated
	 */
	void setAllowReduction(DeviationPermissionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowReduction <em>Allow Reduction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAllowReduction()
	 * @see #getAllowReduction()
	 * @see #setAllowReduction(DeviationPermissionKind)
	 * @generated
	 */
	void unsetAllowReduction();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowReduction <em>Allow Reduction</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Allow Reduction</em>' attribute is set.
	 * @see #AllowReduction()
	 * @see #getAllowReduction()
	 * @see #setAllowReduction(DeviationPermissionKind)
	 * @generated
	 */
	boolean isSetAllowReduction();

	/**
	 * Returns the value of the '<em><b>Allow Refinement</b></em>' attribute.
	 * The default value is <code>"NO"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.DeviationPermissionKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This rule sets whether and how adding may be done of a child feature (without a corresponding feature in the reference model). Allowed values: no, yes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Allow Refinement</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowRefinement()
	 * @see #unsetAllowRefinement()
	 * @see #setAllowRefinement(DeviationPermissionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet_AllowRefinement()
	 * @model default="NO" unsettable="true" required="true"
	 *        annotation="MetaData guid='{51EA7728-3078-4f80-98C5-66EEB6EB1967}' id='29' EA\040name='allowRefinement'"
	 *        extendedMetaData="name='ALLOW-REFINEMENT' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOW-REFINEMENTS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationPermissionKind getAllowRefinement();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRefinement <em>Allow Refinement</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allow Refinement</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowRefinement()
	 * @see #AllowRefinement()
	 * @see #getAllowRefinement()
	 * @generated
	 */
	void setAllowRefinement(DeviationPermissionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRefinement <em>Allow Refinement</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAllowRefinement()
	 * @see #getAllowRefinement()
	 * @see #setAllowRefinement(DeviationPermissionKind)
	 * @generated
	 */
	void unsetAllowRefinement();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRefinement <em>Allow Refinement</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Allow Refinement</em>' attribute is set.
	 * @see #AllowRefinement()
	 * @see #getAllowRefinement()
	 * @see #setAllowRefinement(DeviationPermissionKind)
	 * @generated
	 */
	boolean isSetAllowRefinement();

	/**
	 * Returns the value of the '<em><b>Allow Regrouping</b></em>' attribute.
	 * The default value is <code>"NO"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.DeviationPermissionKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This rule sets whether and how the immediate child features of the VehicleFeature are allowed to be regrouped (i.e. creation or deletion of FeatureGroups below the respective VehicleFeature). Allowed values: no, widen, yes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Allow Regrouping</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowRegrouping()
	 * @see #unsetAllowRegrouping()
	 * @see #setAllowRegrouping(DeviationPermissionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet_AllowRegrouping()
	 * @model default="NO" unsettable="true" required="true"
	 *        annotation="MetaData guid='{63807EC9-5A97-4abd-B103-8B146759F488}' id='30' EA\040name='allowRegrouping'"
	 *        extendedMetaData="name='ALLOW-REGROUPING' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOW-REGROUPINGS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationPermissionKind getAllowRegrouping();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRegrouping <em>Allow Regrouping</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allow Regrouping</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowRegrouping()
	 * @see #AllowRegrouping()
	 * @see #getAllowRegrouping()
	 * @generated
	 */
	void setAllowRegrouping(DeviationPermissionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRegrouping <em>Allow Regrouping</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAllowRegrouping()
	 * @see #getAllowRegrouping()
	 * @see #setAllowRegrouping(DeviationPermissionKind)
	 * @generated
	 */
	void unsetAllowRegrouping();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRegrouping <em>Allow Regrouping</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Allow Regrouping</em>' attribute is set.
	 * @see #AllowRegrouping()
	 * @see #getAllowRegrouping()
	 * @see #setAllowRegrouping(DeviationPermissionKind)
	 * @generated
	 */
	boolean isSetAllowRegrouping();

	/**
	 * Returns the value of the '<em><b>Allow Removal</b></em>' attribute.
	 * The default value is <code>"NO"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.DeviationPermissionKind}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This rule sets if the feature in the referring model (compared to the reference model) may be deleted. Allowed values: no, yes.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Allow Removal</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowRemoval()
	 * @see #unsetAllowRemoval()
	 * @see #setAllowRemoval(DeviationPermissionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getDeviationAttributeSet_AllowRemoval()
	 * @model default="NO" unsettable="true" required="true"
	 *        annotation="MetaData guid='{6796F6C3-3F8A-4487-B2C1-472CC763B50A}' id='31' EA\040name='allowRemoval'"
	 *        extendedMetaData="name='ALLOW-REMOVAL' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOW-REMOVALS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationPermissionKind getAllowRemoval();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRemoval <em>Allow Removal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allow Removal</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.DeviationPermissionKind
	 * @see #isSetAllowRemoval()
	 * @see #AllowRemoval()
	 * @see #getAllowRemoval()
	 * @generated
	 */
	void setAllowRemoval(DeviationPermissionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRemoval <em>Allow Removal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetAllowRemoval()
	 * @see #getAllowRemoval()
	 * @see #setAllowRemoval(DeviationPermissionKind)
	 * @generated
	 */
	void unsetAllowRemoval();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.DeviationAttributeSet#getAllowRemoval <em>Allow Removal</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Allow Removal</em>' attribute is set.
	 * @see #AllowRemoval()
	 * @see #getAllowRemoval()
	 * @see #setAllowRemoval(DeviationPermissionKind)
	 * @generated
	 */
	boolean isSetAllowRemoval();

} // DeviationAttributeSet
