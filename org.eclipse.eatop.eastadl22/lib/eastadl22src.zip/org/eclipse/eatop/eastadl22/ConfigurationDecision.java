/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Configuration Decision</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ConfigurationDecision represents a single, atomized rule on how to configure the target feature model(s) of the containing ConfigurationDecisionModel, depending on a given configuration of the source feature model(s). Two examples are: "all North American (USA+Canada) cars except A-Class have cruise control" (one ConfigurationDecision) or "all Canadian cars have adaptive cruise control" (another ConfigurationDecision). All ConfigurationDecisions within a single ConfigurationDecisionModel then specify how the target feature model(s) are to be configured depending on the configuration of the source feature model(s).
 * 
 * Example: 
 * Let's assume we have two FeatureModels: FM1 and FM2. FM1 has possible end-customer decisions like USA, Canada, EU, Japan and A-Class, C-Class, etc. FM2 has another possible end-customer decision such as CruiseControl, AdaptiveCruiseControl, RearWiper, RainSensor. End-customer decisions in FM2 describe possible technical features of the delivered products. By way of a set of ConfigurationDecisions it is now possible to define the configuration of FM2 (i.e. if there is a RainSensor, etc.) dependent on a configuration of FM1. In other words, with a ConfigurationDecision we can express something like: "If USA is selected in FM1 AND A-Class is not selected in FM1, then CruiseControl will be selected in FM2".
 * 
 * The two most important constituents of a ConfigurationDecision are its 'criterion' and 'effect'. The effect is a list of things to select and deselect in the target configuration(s), whereas the criterion formulates a condition on the source configuration(s) under which this ConfigurationDecision's effect will actually be applied to the target configuration(s). In the first example above, the criterion would be "USA &amp; not A-Class" and the effect would be "CruiseControl[+]".
 * 
 * 
 * Semantics:
 * There are two alternative semantics depending on usage:
 * a) Entities referenced by "Target" Association are included only if SelectionCriterion evaluates to True
 * b) Entities referenced in the "effect" attribute are included based on the expression in the "criterion" attribute. The syntax and semantics of the expression depends on the variability resolution framework used. Associations "selectionCriterion" and "target" may be used to have non-ambiguous references to model elements.
 * 
 * Constraints:
 * [1] Attribute "criterion" or association "selectionCriterion" (or both) must be defined.
 * [2] Attribute "effect" or association "target" (or both) must be defined.
 * 
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.ConfigurationDecision</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getCriterion <em>Criterion</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getEffect <em>Effect</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getIsEquivalence <em>Is Equivalence</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getSelectionCriterion <em>Selection Criterion</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecision()
 * @model annotation="MetaData guid='{0A3995CD-1FFF-4856-A172-68D080D30EE2}' id='92' EA\040name='ConfigurationDecision'"
 *        extendedMetaData="name='CONFIGURATION-DECISION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURATION-DECISIONS'"
 * @generated
 */
public interface ConfigurationDecision extends ConfigurationDecisionModelEntry {
	/**
	 * Returns the value of the '<em><b>Criterion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The criterion is a logical expression on the source configuration(s) that states under which condition the 'effect' will be applied to the target configuration(s). This attribute adheres to the syntax and semantics of the VSL language.
	 * 
	 * Note that association "selectionCriterion" provides an alternative means for defining such an expression in the form of an AUTOSAR mixed string expression. If both "criterion" and "selectionCriterion" are defined, they are assumed to be semantically equivalent and a tool may choose which one to use for variability and configuration management.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Criterion</em>' attribute.
	 * @see #isSetCriterion()
	 * @see #unsetCriterion()
	 * @see #setCriterion(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecision_Criterion()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String"
	 *        annotation="MetaData guid='{C134C80B-3B1E-46bf-ABD2-16EB8129BC3B}' id='78' EA\040name='criterion'"
	 *        extendedMetaData="name='CRITERION' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CRITERIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getCriterion();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getCriterion <em>Criterion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Criterion</em>' attribute.
	 * @see #isSetCriterion()
	 * @see #Criterion()
	 * @see #getCriterion()
	 * @generated
	 */
	void setCriterion(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getCriterion <em>Criterion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetCriterion()
	 * @see #getCriterion()
	 * @see #setCriterion(String)
	 * @generated
	 */
	void unsetCriterion();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getCriterion <em>Criterion</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Criterion</em>' attribute is set.
	 * @see #Criterion()
	 * @see #getCriterion()
	 * @see #setCriterion(String)
	 * @generated
	 */
	boolean isSetCriterion();

	/**
	 * Returns the value of the '<em><b>Effect</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * States which Features are included/selected by the ConfigurationDecision in case the logical expression in 'criterion' evaluates to true. Each of these Features needs to be defined in one of the target feature models of the containing ConfigurationDecisionModel. This attribute adheres to the syntax and semantics of the VSL language.
	 * 
	 * The Features are documented as a comma-separated list of strings. Each string has the form &lt;Name of FeatureModel&gt;#&lt;Name of Feature&gt;. If a string is unique in all the source and target FeatureModels of the ConfigurationDecisionModel containing this ConfigurationDecision, then the first part (the FeatureModel name and the #-separator) can be omitted. If a Feature name is not unique in a single FeatureModel, then a dot-notation may be used to prepend the name(s) of predecessors in order to identify the Feature.
	 * 
	 * Configuring a cloned feature does not mean selecting or deselecting it but instead instances of the cloned feature are created. Each such instance is provided with a name, which thus becomes a part of the configuration (not the feature model). If several instances are created for a single cloned feature, then the name is used to identify these instances. For example, consider a cloned feature Wiper with cardinality [*]. A first configuration decision might create an instance called "front" and a second might create another named "rear"; a third configuration decision creating or otherwise referring to an instance called "front" will denote the same instance as the first configuration decision. The name space for these instance names is a particular feature configuration.
	 * 
	 * As an example for the syntax and semantics of the effect attribute, assume there are two FeatureModels called FMa and FMb and they both contain the Features Wiper and ClimateControl. In FMa (but not in FMb), Wiper and ClimateControl are both refined into the child features Simple and Advanced. In addition, the wiper in FMa has a RainSensor. To denote the RainSensor in FMa you can state:
	 * 
	 * FMa#Wiper.RainSensor
	 * 
	 * or simply write:
	 * 
	 * RainSensor
	 * 
	 * This is sufficient here, because the name of Feature RainSensor is unique within FMa and within all FeatureModels referenced by the ConfigurationDecisionModel. In contrast, to denote the advanced version of the climate control in FMa you can specify:
	 * 
	 * FMa#ClimateControl.Advanced
	 * 
	 * or simply:
	 * 
	 * ClimateControl.Advanced
	 * 
	 * but merely stating "Advanced" would not suffice because there are two features with that name. Finally, to denote the wiper of feature model FMb you write:
	 * 
	 * FMb#Wiper
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Effect</em>' attribute.
	 * @see #isSetEffect()
	 * @see #unsetEffect()
	 * @see #setEffect(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecision_Effect()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String"
	 *        annotation="MetaData guid='{D20CF1D9-7723-44b0-9D98-1F71EAB64C62}' id='79' EA\040name='effect'"
	 *        extendedMetaData="name='EFFECT' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EFFECTS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getEffect();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getEffect <em>Effect</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Effect</em>' attribute.
	 * @see #isSetEffect()
	 * @see #Effect()
	 * @see #getEffect()
	 * @generated
	 */
	void setEffect(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getEffect <em>Effect</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetEffect()
	 * @see #getEffect()
	 * @see #setEffect(String)
	 * @generated
	 */
	void unsetEffect();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getEffect <em>Effect</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Effect</em>' attribute is set.
	 * @see #Effect()
	 * @see #getEffect()
	 * @see #setEffect(String)
	 * @generated
	 */
	boolean isSetEffect();

	/**
	 * Returns the value of the '<em><b>Is Equivalence</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Setting the attribute isEquivalence to true means that the features referred to in the ConfigurationDecision's effect are exclusively configured by this ConfigurationDecision (i.e. no other ConfigurationDecision in the same ConfigurationDecisionModel may refer to these features). This means that this ConfigurationDecision is the ONLY way in which these features can be selected and therefore the usual logical implication that a ConfigurationDecision represents is turned into a logical equivalence, hence the name: the effect is applied to the target configurations if and only if the specified criterion holds.
	 * 
	 * When setting this attribute to true, the modeler can state that the target-side features in this ConfigurationDecision's effect are exclusively configured by this ConfigurationDecision, i.e. no other ConfigurationDecision may influence these target-side features.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Equivalence</em>' attribute.
	 * @see #isSetIsEquivalence()
	 * @see #unsetIsEquivalence()
	 * @see #setIsEquivalence(Boolean)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecision_IsEquivalence()
	 * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Boolean" required="true"
	 *        annotation="MetaData guid='{22C42709-80D9-4a99-8D09-5195C548F617}' id='80' EA\040name='isEquivalence'"
	 *        extendedMetaData="name='IS-EQUIVALENCE' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-EQUIVALENCES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Boolean getIsEquivalence();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getIsEquivalence <em>Is Equivalence</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Equivalence</em>' attribute.
	 * @see #isSetIsEquivalence()
	 * @see #IsEquivalence()
	 * @see #getIsEquivalence()
	 * @generated
	 */
	void setIsEquivalence(Boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getIsEquivalence <em>Is Equivalence</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsEquivalence()
	 * @see #getIsEquivalence()
	 * @see #setIsEquivalence(Boolean)
	 * @generated
	 */
	void unsetIsEquivalence();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getIsEquivalence <em>Is Equivalence</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Equivalence</em>' attribute is set.
	 * @see #IsEquivalence()
	 * @see #getIsEquivalence()
	 * @see #setIsEquivalence(Boolean)
	 * @generated
	 */
	boolean isSetIsEquivalence();

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Identifiable}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecision_Target()
	 * @model annotation="MetaData guid='{FF229FD3-3CA9-4e46-8A26-0890A89BBA87}' id='510' EA\040name=''"
	 *        extendedMetaData="name='TARGET-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Identifiable> getTarget();

	/**
	 * Returns the value of the '<em><b>Selection Criterion</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Selection Criterion</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Selection Criterion</em>' containment reference.
	 * @see #setSelectionCriterion(SelectionCriterion)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getConfigurationDecision_SelectionCriterion()
	 * @model containment="true"
	 *        annotation="MetaData guid='{6B7847ED-42E2-49bd-821A-67BDFC117FA8}' id='512' EA\040name=''"
	 *        extendedMetaData="name='SELECTION-CRITERION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SELECTION-CRITERIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	SelectionCriterion getSelectionCriterion();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ConfigurationDecision#getSelectionCriterion <em>Selection Criterion</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Selection Criterion</em>' containment reference.
	 * @see #getSelectionCriterion()
	 * @generated
	 */
	void setSelectionCriterion(SelectionCriterion value);

} // ConfigurationDecision
