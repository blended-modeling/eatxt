/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mode Group</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ModeGroups serve as containers of Modes. The Modes in a ModeGroup are mutually exclusive. This means that only one Mode of a ModeGroup is active at any point in time. A precondition in the form of a Boolean expression is assigned to the ModeGroup so that ModeGroups can be switched on and off as a whole.
 * 
 * Semantics:
 * The ModeGroup defines a set of modes of which exactly one is active if precondition is true and otherwise none is active.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Behavior.ModeGroup</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ModeGroup#getPrecondition <em>Precondition</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ModeGroup#getMode <em>Mode</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getModeGroup()
 * @model annotation="MetaData guid='{E57AEEAC-2A22-435f-BC2F-90B0FA19BF4C}' id='89' EA\040name='ModeGroup'"
 *        extendedMetaData="name='MODE-GROUP' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODE-GROUPS'"
 * @generated
 */
public interface ModeGroup extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Precondition</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A Boolean expression that evaluates to true when the ModeGroup is active.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Precondition</em>' attribute.
	 * @see #isSetPrecondition()
	 * @see #unsetPrecondition()
	 * @see #setPrecondition(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getModeGroup_Precondition()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String" required="true"
	 *        annotation="MetaData guid='{ED4608B5-D811-4c67-AEBD-4FFA4F5ABB48}' id='76' EA\040name='precondition'"
	 *        extendedMetaData="name='PRECONDITION' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRECONDITIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getPrecondition();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ModeGroup#getPrecondition <em>Precondition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Precondition</em>' attribute.
	 * @see #isSetPrecondition()
	 * @see #Precondition()
	 * @see #getPrecondition()
	 * @generated
	 */
	void setPrecondition(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.ModeGroup#getPrecondition <em>Precondition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetPrecondition()
	 * @see #getPrecondition()
	 * @see #setPrecondition(String)
	 * @generated
	 */
	void unsetPrecondition();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.ModeGroup#getPrecondition <em>Precondition</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Precondition</em>' attribute is set.
	 * @see #Precondition()
	 * @see #getPrecondition()
	 * @see #setPrecondition(String)
	 * @generated
	 */
	boolean isSetPrecondition();

	/**
	 * Returns the value of the '<em><b>Mode</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Mode}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mode</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mode</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getModeGroup_Mode()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{E50B8147-D210-4448-A58A-A85EE9AC9127}' id='524' EA\040name=''"
	 *        extendedMetaData="name='MODE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MODES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Mode> getMode();

} // ModeGroup
