/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Implementation Level</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The ImplementationLevel represents the software architecture and the hardware architecture of the electrical/electronic system in the vehicle. The ImplementationLevel is defined by the AUTOSAR SystemArchitecture and SoftwareArchitecture. For example, functions of the FDA will be realized by AUTOSAR SW-Components in the ImplementationLevel. Traceability is supported from implementation level elements (AUTOSAR) to upper level elements by Realization relationships.
 * 
 * Semantics:
 * The ImplementationLevel is the representation of the vehicle electrical/electronic system on the implementation abstraction level. It corresponds to the system implementation in Software and Hardware.
 * 
 * Notation:
 * The ImplementationLevel is shown as a solid-outline rectangle containing the name.
 * 
 * Extension: Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.SystemModeling.ImplementationLevel</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getImplementationLevel()
 * @model annotation="MetaData guid='{D72539AA-5E9A-4037-AFBD-99F969D572BD}' id='21' EA\040name='ImplementationLevel'"
 *        annotation="Stereotype Stereotype='atpStructureElement'"
 *        extendedMetaData="name='IMPLEMENTATION-LEVEL' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IMPLEMENTATION-LEVELS'"
 * @generated
 */
public interface ImplementationLevel extends Context {
} // ImplementationLevel
