/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fault Failure anomaly</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.SafetyConstraints._instanceRef.FaultFailure_anomaly</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.FaultFailure_anomaly#getErrorModelPrototype <em>Error Model Prototype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FaultFailure_anomaly#getAnomaly <em>Anomaly</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFaultFailure_anomaly()
 * @model annotation="MetaData guid='{042B0060-F0E5-4d31-91B6-097F4166BBFB}' id='203' EA\040name='FaultFailure_anomaly'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='FAULT-FAILURE--ANOMALY-IREF'"
 *        extendedMetaData="name='FAULT-FAILURE--ANOMALY-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FAULT-FAILURE--ANOMALY-IREFS'"
 * @generated
 */
public interface FaultFailure_anomaly extends EObject {
	/**
	 * Returns the value of the '<em><b>Error Model Prototype</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ErrorModelPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Error Model Prototype</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Error Model Prototype</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFaultFailure_anomaly_ErrorModelPrototype()
	 * @model annotation="MetaData guid='{25F77B23-179F-4654-BA48-63F39133F2D4}' id='246' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.context'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='ERROR-MODEL-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-MODEL-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<ErrorModelPrototype> getErrorModelPrototype();

	/**
	 * Returns the value of the '<em><b>Anomaly</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Anomaly</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Anomaly</em>' reference.
	 * @see #setAnomaly(Anomaly)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFaultFailure_anomaly_Anomaly()
	 * @model required="true"
	 *        annotation="MetaData guid='{1AF16860-E025-4fa5-89B0-CD0C7DC50AB2}' id='247' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.target'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='ANOMALY-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ANOMALY-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Anomaly getAnomaly();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FaultFailure_anomaly#getAnomaly <em>Anomaly</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Anomaly</em>' reference.
	 * @see #getAnomaly()
	 * @generated
	 */
	void setAnomaly(Anomaly value);

} // FaultFailure_anomaly
