/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Prototype</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * BehaviorConstraintPrototype is the modeling construct for declaring the instantiated occurrence(s) of a behavior constraint type (BehaviorConstraintPrototype.type) in particular behavior specification context where the behavior constraint type acts as part.
 * 
 * BehaviorConstraintPrototype.instantiationVariable {ordered} is declared by BehaviorConstraintPrototype.type.interfaceVariable {ordered} 
 * 
 * Constraints:
 * [1] A BehaviorConstraintPrototype must has a type (BehaviorConstraintPrototype.type) and a context where it acts as part (BehaviorConstraintType.part).
 * 
 * BehaviorConstraintType.part:BehaviorConstraintPrototype.instantiationVariable can only be a subset of the BehaviorConstraintType.interfaceVariable. 
 * 
 * Semantics:
 * See BehaviorConstraintType.
 * 
 * Extension: 
 * TraceableSpecification.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.BehaviorConstraintPrototype</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype#getType <em>Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype#getInstantiationVariable <em>Instantiation Variable</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype#getTargetedVehicleFeatureElement <em>Targeted Vehicle Feature Element</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype#getErrorModelTarget <em>Error Model Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype#getFunctionTarget <em>Function Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype#getHardwareComponentTarget <em>Hardware Component Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype()
 * @model annotation="MetaData guid='{B4960A39-9F82-4713-B928-8C31AB6E61E9}' id='294' EA\040name='BehaviorConstraintPrototype'"
 *        annotation="Stereotype Stereotype='atpPrototype'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-PROTOTYPE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-PROTOTYPES'"
 * @generated
 */
public interface BehaviorConstraintPrototype extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' reference.
	 * @see #setType(BehaviorConstraintType)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype_Type()
	 * @model required="true"
	 *        annotation="MetaData guid='{438D13DF-971C-4419-8BBD-625AE874892C}' id='74' EA\040name=''"
	 *        annotation="Stereotype Stereotype='isOfType'"
	 *        extendedMetaData="name='TYPE-TREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TYPE-TREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	BehaviorConstraintType getType();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype#getType <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(BehaviorConstraintType value);

	/**
	 * Returns the value of the '<em><b>Instantiation Variable</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Instantiation Variable</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instantiation Variable</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype_InstantiationVariable()
	 * @model annotation="MetaData guid='{D578FE0E-1422-4547-A683-15107A14C9B6}' id='76' EA\040name=''"
	 *        extendedMetaData="name='INSTANTIATION-VARIABLE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INSTANTIATION-VARIABLE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<BehaviorConstraintInternalBinding> getInstantiationVariable();

	/**
	 * Returns the value of the '<em><b>Targeted Vehicle Feature Element</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VehicleFeature}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Targeted Vehicle Feature Element</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Targeted Vehicle Feature Element</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype_TargetedVehicleFeatureElement()
	 * @model annotation="MetaData guid='{6BDBB81D-89BF-48a9-B256-BF24492E89BA}' id='695' EA\040name=''"
	 *        extendedMetaData="name='TARGETED-VEHICLE-FEATURE-ELEMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGETED-VEHICLE-FEATURE-ELEMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<VehicleFeature> getTargetedVehicleFeatureElement();

	/**
	 * Returns the value of the '<em><b>Error Model Target</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype_errorModelTarget}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Error Model Target</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Error Model Target</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype_ErrorModelTarget()
	 * @model containment="true"
	 *        annotation="MetaData guid='{8F9DD3B4-4196-4931-8534-FC563A4FF364}' id='65' EA\040name=''"
	 *        annotation="TaggedValues xml.name='ERROR-MODEL-TARGET-IREF' xml.namePlural='ERROR-MODEL-TARGET-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='ERROR-MODEL-TARGET-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-MODEL-TARGET-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<BehaviorConstraintPrototype_errorModelTarget> getErrorModelTarget();

	/**
	 * Returns the value of the '<em><b>Function Target</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype_functionTarget}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Target</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Target</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype_FunctionTarget()
	 * @model containment="true"
	 *        annotation="MetaData guid='{4717065D-1FE6-4181-901A-9BA087BE2EF4}' id='66' EA\040name=''"
	 *        annotation="TaggedValues xml.name='FUNCTION-TARGET-IREF' xml.namePlural='FUNCTION-TARGET-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='FUNCTION-TARGET-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-TARGET-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<BehaviorConstraintPrototype_functionTarget> getFunctionTarget();

	/**
	 * Returns the value of the '<em><b>Hardware Component Target</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype_hardwareComponentTarget}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hardware Component Target</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hardware Component Target</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintPrototype_HardwareComponentTarget()
	 * @model containment="true"
	 *        annotation="MetaData guid='{1FF9D063-EB52-4c65-A160-1351BA34393F}' id='67' EA\040name=''"
	 *        annotation="TaggedValues xml.name='HARDWARE-COMPONENT-TARGET-IREF' xml.namePlural='HARDWARE-COMPONENT-TARGET-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='HARDWARE-COMPONENT-TARGET-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HARDWARE-COMPONENT-TARGET-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<BehaviorConstraintPrototype_hardwareComponentTarget> getHardwareComponentTarget();

} // BehaviorConstraintPrototype
