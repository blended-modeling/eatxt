/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Function</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * EventFunction refers to various events of the referenced Function, from the activation or triggering of the Function, the start i.e., when the input data is consumed to the stop, when function execution is completed. Preemption and resume events may occur in between. EventFunction of kind activate can be used in conjunction with FunctionTrigger to define a time-driven triggering for a function. In this case the FunctionTrigger points to the EventFunction of the function and defines a triggerPolicy set to TIME. The timing constraint associated to the EventFunction provides information about the period.
 * 
 * Compare categories of AUTOSAR runnables:
 * 
 * 1a triggering only on start and finish (this type of event)
 * 
 * 1b triggering allowed anytime during the execution (events on ports, see EventFunctionFlowPort).
 * 
 * 
 * Semantics:
 * The EventFunction refers to the different events related to the function execution, as defined by the eventKind attribute.  
 * Activate event correspond to triggering of the function and start is the time of execution and input data consumption. stop is the time of completion and output data provision. 
 * 
 * Constraints:
 * [1] An EventFunction either identifies a FunctionType or a FunctionPrototype as its target function.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.Events.EventFunction</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.EventFunction#getEventKind <em>Event Kind</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.EventFunction#getFunctionType <em>Function Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.EventFunction#getFunction <em>Function</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunction()
 * @model annotation="MetaData guid='{CFBC6010-83CD-45b8-92DD-58F1E878F136}' id='158' EA\040name='EventFunction'"
 *        extendedMetaData="name='EVENT-FUNCTION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-FUNCTIONS'"
 * @generated
 */
public interface EventFunction extends Event {
	/**
	 * Returns the value of the '<em><b>Event Kind</b></em>' attribute.
	 * The default value is <code>"START"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.EventFunctionKind}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event Kind</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event Kind</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.EventFunctionKind
	 * @see #isSetEventKind()
	 * @see #unsetEventKind()
	 * @see #setEventKind(EventFunctionKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunction_EventKind()
	 * @model default="START" unsettable="true" required="true"
	 *        annotation="MetaData guid='{D61E0B5C-8845-4c9b-A767-8DA3D6C7CE88}' id='248' EA\040name='eventKind'"
	 *        extendedMetaData="name='EVENT-KIND' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-KINDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EventFunctionKind getEventKind();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.EventFunction#getEventKind <em>Event Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event Kind</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.EventFunctionKind
	 * @see #isSetEventKind()
	 * @see #EventKind()
	 * @see #getEventKind()
	 * @generated
	 */
	void setEventKind(EventFunctionKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.EventFunction#getEventKind <em>Event Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetEventKind()
	 * @see #getEventKind()
	 * @see #setEventKind(EventFunctionKind)
	 * @generated
	 */
	void unsetEventKind();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.EventFunction#getEventKind <em>Event Kind</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Event Kind</em>' attribute is set.
	 * @see #EventKind()
	 * @see #getEventKind()
	 * @see #setEventKind(EventFunctionKind)
	 * @generated
	 */
	boolean isSetEventKind();

	/**
	 * Returns the value of the '<em><b>Function Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Type</em>' reference.
	 * @see #setFunctionType(FunctionType)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunction_FunctionType()
	 * @model annotation="MetaData guid='{B4EC8B8D-B856-4d2a-8A2E-D927FD248C31}' id='642' EA\040name=''"
	 *        extendedMetaData="name='FUNCTION-TYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-TYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FunctionType getFunctionType();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.EventFunction#getFunctionType <em>Function Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function Type</em>' reference.
	 * @see #getFunctionType()
	 * @generated
	 */
	void setFunctionType(FunctionType value);

	/**
	 * Returns the value of the '<em><b>Function</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function</em>' containment reference.
	 * @see #setFunction(EventFunction_function)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunction_Function()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{B5F32F9F-8BA3-44d3-93F1-1C51BDB1577C}' id='285' EA\040name=''"
	 *        annotation="TaggedValues xml.name='FUNCTION-IREF' xml.namePlural='FUNCTION-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='FUNCTION-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-IREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EventFunction_function getFunction();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.EventFunction#getFunction <em>Function</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function</em>' containment reference.
	 * @see #getFunction()
	 * @generated
	 */
	void setFunction(EventFunction_function value);

} // EventFunction
