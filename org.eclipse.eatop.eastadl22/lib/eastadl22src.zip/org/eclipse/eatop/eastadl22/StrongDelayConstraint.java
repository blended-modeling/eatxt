/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Strong Delay Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A StrongDelayConstraint imposes limits between each indexed occurrence of an event called source and the identically indexed occurrence of an event called target.
 * 
 * The strong delay notion requires source and target occurrences to appear in lock-step. Only one-to-one source-target patterns are allowed, and no stray target occurrences are accepted.
 * 
 * Strong synchronization differs from the ordinary form of SynchronizationConstraint by grouping event occurrences into synchronization clusters strictly according to their index. This means that multiple occurrences of a single event cannot belong to a single cluster, and clusters may not share occurrences. Strong synchronization tightens the requirements compared to ordinary synchronization in much the same way as StrongDelayConstraint refines the ordinary DelayConstraint.
 * 
 * Semantics:
 * A system behavior satisfies a StrongDelayConstraint c if and only if
 * c.source and c.target have the same number of occurrences, 
 * and for each index i,
 * 		if there is an i:th occurrence of c.source at time x 
 * 		there is also an i:th occurrence of c.target at time y 
 * 		such that
 * 			c.lower &lt;= y - x &lt;= c.upper
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.StrongDelayConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.StrongDelayConstraint#getUpper <em>Upper</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.StrongDelayConstraint#getLower <em>Lower</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.StrongDelayConstraint#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.StrongDelayConstraint#getSource <em>Source</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStrongDelayConstraint()
 * @model annotation="MetaData guid='{F43C9FBC-5CCC-4990-A22F-E74EC89972D9}' id='182' EA\040name='StrongDelayConstraint'"
 *        extendedMetaData="name='STRONG-DELAY-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STRONG-DELAY-CONSTRAINTS'"
 * @generated
 */
public interface StrongDelayConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Upper</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Upper</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Upper</em>' containment reference.
	 * @see #setUpper(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStrongDelayConstraint_Upper()
	 * @model containment="true"
	 *        annotation="MetaData guid='{983932B5-4335-4900-9427-070B14CDC038}' id='308' EA\040name=''"
	 *        extendedMetaData="name='UPPER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='UPPERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getUpper();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.StrongDelayConstraint#getUpper <em>Upper</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Upper</em>' containment reference.
	 * @see #getUpper()
	 * @generated
	 */
	void setUpper(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Lower</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lower</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lower</em>' containment reference.
	 * @see #setLower(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStrongDelayConstraint_Lower()
	 * @model containment="true"
	 *        annotation="MetaData guid='{58BAF19A-852C-49e3-88BE-5E6A1E8B944F}' id='317' EA\040name=''"
	 *        extendedMetaData="name='LOWER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOWERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getLower();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.StrongDelayConstraint#getLower <em>Lower</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lower</em>' containment reference.
	 * @see #getLower()
	 * @generated
	 */
	void setLower(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(Event)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStrongDelayConstraint_Target()
	 * @model required="true"
	 *        annotation="MetaData guid='{D369CE98-4646-43c2-938C-55C37A153831}' id='363' EA\040name=''"
	 *        extendedMetaData="name='TARGET-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Event getTarget();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.StrongDelayConstraint#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(Event value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(Event)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStrongDelayConstraint_Source()
	 * @model required="true"
	 *        annotation="MetaData guid='{674B140F-BEC5-4915-AE8A-E3E5AF4EA687}' id='373' EA\040name=''"
	 *        extendedMetaData="name='SOURCE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SOURCE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Event getSource();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.StrongDelayConstraint#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(Event value);

} // StrongDelayConstraint
