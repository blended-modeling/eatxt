/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Function Client Server Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The FunctionClientServerInterface is used to specify the operations in FunctionClientServerPorts.
 * 
 * Semantics:
 * The operations of the FunctionClientServerInterface are required or provided through the FunctionClientServerPorts typed by the FunctionClientServerInterface.
 * 
 * Extension: UML Interface
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.FunctionModeling.FunctionClientServerInterface</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.FunctionClientServerInterface#getOperation <em>Operation</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionClientServerInterface()
 * @model annotation="MetaData guid='{7437700A-B53A-4558-B709-93B1C33C8B72}' id='49' EA\040name='FunctionClientServerInterface'"
 *        annotation="Stereotype Stereotype='atpType'"
 *        extendedMetaData="name='FUNCTION-CLIENT-SERVER-INTERFACE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-CLIENT-SERVER-INTERFACES'"
 * @generated
 */
public interface FunctionClientServerInterface extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Operation</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Operation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Operation</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operation</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFunctionClientServerInterface_Operation()
	 * @model containment="true"
	 *        annotation="MetaData guid='{9E2B087B-33AF-4626-8067-675BAC88FBDD}' id='652' EA\040name=''"
	 *        extendedMetaData="name='OPERATION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='OPERATIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Operation> getOperation();

} // FunctionClientServerInterface
