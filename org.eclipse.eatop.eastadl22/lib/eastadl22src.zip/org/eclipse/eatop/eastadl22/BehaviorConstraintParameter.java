/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * BehaviorConstraintParameter is the modeling construct for the declarations of the parameters that a behavior constraint type offer for its instantiations. During the instantiation, a behavior constraint prototype declares the particular contextual parameters to be bound (BehaviorConstraintPrototype.BehaviorinstantiatedWithParameter) with the parameters of its corresponding behavior constraint types (BehaviorConstraintPrototype.type:BehaviorConstraintType.parameter). This allows thereby the values of those contextual parameters to be assigned to the parameters of prototypes. 
 * 
 * Constraints:
 * See Attribute and TransitionEvent.
 * 
 * Semantics:
 * See Attribute and TransitionEvent.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.BehaviorConstraintParameter</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintParameter()
 * @model abstract="true"
 *        annotation="MetaData guid='{BC728C0B-2D6A-48b8-BC9A-FB7F9B37C42D}' id='296' EA\040name='BehaviorConstraintParameter'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-PARAMETER' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-PARAMETERS'"
 * @generated
 */
public interface BehaviorConstraintParameter extends EObject {
} // BehaviorConstraintParameter
