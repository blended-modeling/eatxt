/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Warrant</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Warrant represents argumentation of the facts to the Claim in general ways.
 * 
 * The Warrant entity has associations with the decomposed goals and with the evidences for the SafetyCase.
 * 
 * Semantics:
 * The overall objective of an argument is to lead the evidence to the claim.
 * 
 * Arguments are actions of inferring a conclusion from premised propositions. An argument is considered valid if the conclusion can be logically derived from its premises. An argument is considered sound if it is valid and all premises are true.
 * 
 * A goal decomposition strategy breaks down a goal into a number of sub-goals. It is recommended that the strategies are of specific form.
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.SafetyCase.Warrant</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Warrant#getJustification <em>Justification</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Warrant#getDecomposedGoal <em>Decomposed Goal</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Warrant#getEvidence <em>Evidence</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getWarrant()
 * @model annotation="MetaData guid='{A8307FF2-0D46-4518-9535-28873F4DD01C}' id='228' EA\040name='Warrant'"
 *        extendedMetaData="name='WARRANT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='WARRANTS'"
 * @generated
 */
public interface Warrant extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Justification</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Rationale}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Justification</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Justification</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getWarrant_Justification()
	 * @model containment="true"
	 *        annotation="MetaData guid='{D76BD602-401F-4f8d-9802-F3D357CCE76E}' id='188' EA\040name=''"
	 *        extendedMetaData="name='JUSTIFICATION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='JUSTIFICATIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Rationale> getJustification();

	/**
	 * Returns the value of the '<em><b>Decomposed Goal</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Claim}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Decomposed Goal</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Decomposed Goal</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getWarrant_DecomposedGoal()
	 * @model annotation="MetaData guid='{B40FDE64-133E-4136-8598-515B5863ACAB}' id='189' EA\040name=''"
	 *        extendedMetaData="name='DECOMPOSED-GOAL-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DECOMPOSED-GOAL-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Claim> getDecomposedGoal();

	/**
	 * Returns the value of the '<em><b>Evidence</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Ground}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Evidence</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Evidence</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getWarrant_Evidence()
	 * @model annotation="MetaData guid='{8A388ECE-276F-49a0-A91B-2571362E6C93}' id='191' EA\040name=''"
	 *        extendedMetaData="name='EVIDENCE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVIDENCE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Ground> getEvidence();

} // Warrant
