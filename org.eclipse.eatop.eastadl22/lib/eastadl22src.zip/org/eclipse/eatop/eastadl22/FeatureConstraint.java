/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Captures a constraint on the containing feature model's configuration which is too complex to be expressed by way of a FeatureLink. In general, all constraints that can be expressed by a FeatureLink can also be expressed by a FeatureConstraint, but not vice versa.
 * 
 * Semantics:
 * See description.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.FeatureModeling.FeatureConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.FeatureConstraint#getCriterion <em>Criterion</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFeatureConstraint()
 * @model annotation="MetaData guid='{B723042E-A6C6-46dd-AF3B-02ACB2985719}' id='30' EA\040name='FeatureConstraint'"
 *        extendedMetaData="name='FEATURE-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURE-CONSTRAINTS'"
 * @generated
 */
public interface FeatureConstraint extends EAElement {
	/**
	 * Returns the value of the '<em><b>Criterion</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The actual constraint. This is a logic expression in VSL like the criterion of a ConfigurationDecision. For the constraint to be met this expression always has to evaluate to true.
	 * 
	 * For example, to express a mutual exclusion of two features, use the expression "! (Radar &amp; RainSensor)". However, note that this particular constraint could also be formulated as a FeatureLink with type "excludes".
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Criterion</em>' attribute.
	 * @see #isSetCriterion()
	 * @see #unsetCriterion()
	 * @see #setCriterion(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFeatureConstraint_Criterion()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String" required="true"
	 *        annotation="MetaData guid='{D28372D2-3D9A-4987-A686-4E2900913F45}' id='13' EA\040name='criterion'"
	 *        extendedMetaData="name='CRITERION' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CRITERIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getCriterion();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FeatureConstraint#getCriterion <em>Criterion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Criterion</em>' attribute.
	 * @see #isSetCriterion()
	 * @see #Criterion()
	 * @see #getCriterion()
	 * @generated
	 */
	void setCriterion(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.FeatureConstraint#getCriterion <em>Criterion</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetCriterion()
	 * @see #getCriterion()
	 * @see #setCriterion(String)
	 * @generated
	 */
	void unsetCriterion();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.FeatureConstraint#getCriterion <em>Criterion</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Criterion</em>' attribute is set.
	 * @see #Criterion()
	 * @see #getCriterion()
	 * @see #setCriterion(String)
	 * @generated
	 */
	boolean isSetCriterion();

} // FeatureConstraint
