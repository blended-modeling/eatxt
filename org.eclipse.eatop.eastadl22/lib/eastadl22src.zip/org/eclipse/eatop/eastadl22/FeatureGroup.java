/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Group</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * FeatureGroup is a specialization of the FeatureTreeNode, enabling grouping of several Features.
 * 
 * Semantics:
 * FeatureGroup is a grouping entity for sibling Features to reflect variability for a set of Features.
 * 
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.FeatureModeling.FeatureGroup</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.FeatureGroup#getCardinality <em>Cardinality</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.FeatureGroup#getChildFeature <em>Child Feature</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFeatureGroup()
 * @model annotation="MetaData guid='{776D6E42-62B5-49ee-8729-4C147A50EFD0}' id='27' EA\040name='FeatureGroup'"
 *        extendedMetaData="name='FEATURE-GROUP' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURE-GROUPS'"
 * @generated
 */
public interface FeatureGroup extends FeatureTreeNode {
	/**
	 * Returns the value of the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The cardinality of the FeatureGroup, specifies how the grouped features, in featureGroup, can be combined. For example, a FeatureGroup owning the two Features A and B, and with a cardinality of [1], means that A and B are alternatives, but only one of them can be chosen. Mandatory features among the child features count as 1 and for cloned features all instances created in the configuration count.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Cardinality</em>' attribute.
	 * @see #isSetCardinality()
	 * @see #unsetCardinality()
	 * @see #setCardinality(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFeatureGroup_Cardinality()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String" required="true"
	 *        annotation="MetaData guid='{2E717F5A-7DAD-4f54-838E-83FFF9E551EA}' id='9' EA\040name='cardinality'"
	 *        extendedMetaData="name='CARDINALITY' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CARDINALITYS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getCardinality();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FeatureGroup#getCardinality <em>Cardinality</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cardinality</em>' attribute.
	 * @see #isSetCardinality()
	 * @see #Cardinality()
	 * @see #getCardinality()
	 * @generated
	 */
	void setCardinality(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.FeatureGroup#getCardinality <em>Cardinality</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetCardinality()
	 * @see #getCardinality()
	 * @see #setCardinality(String)
	 * @generated
	 */
	void unsetCardinality();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.FeatureGroup#getCardinality <em>Cardinality</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Cardinality</em>' attribute is set.
	 * @see #Cardinality()
	 * @see #getCardinality()
	 * @see #setCardinality(String)
	 * @generated
	 */
	boolean isSetCardinality();

	/**
	 * Returns the value of the '<em><b>Child Feature</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Feature}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Child Feature</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Child Feature</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFeatureGroup_ChildFeature()
	 * @model containment="true" lower="2"
	 *        annotation="MetaData guid='{42F9582C-85D7-413e-AAA7-D5AB1281A083}' id='715' EA\040name=''"
	 *        extendedMetaData="name='CHILD-FEATURE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CHILD-FEATURES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Feature> getChildFeature();

} // FeatureGroup
