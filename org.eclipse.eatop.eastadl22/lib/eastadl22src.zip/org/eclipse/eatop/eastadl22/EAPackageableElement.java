/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.eatop.geastadl.ginfrastructure.gelements.GEAPackageableElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EA Packageable Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Elements that are packageable may be directly contained in a package.
 * 
 * Semantics:
 * Elements specializing EAPackageableElement can be created directly within an EAPackage.
 * 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Infrastructure.Elements.EAPackageableElement</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.EAPackageableElement#getEAPackage_element <em>EA Package element</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEAPackageableElement()
 * @model abstract="true"
 *        annotation="MetaData guid='{686C8F6A-E793-4d92-AF88-2BEBF5B710DA}' id='247' EA\040name='EAPackageableElement'"
 *        extendedMetaData="name='EA-PACKAGEABLE-ELEMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EA-PACKAGEABLE-ELEMENTS'"
 * @generated
 */
public interface EAPackageableElement extends EAElement, GEAPackageableElement {
	/**
	 * Returns the value of the '<em><b>EA Package element</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link org.eclipse.eatop.eastadl22.EAPackage#getElement <em>Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>EA Package element</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>EA Package element</em>' container reference.
	 * @see #setEAPackage_element(EAPackage)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEAPackageableElement_EAPackage_element()
	 * @see org.eclipse.eatop.eastadl22.EAPackage#getElement
	 * @model opposite="element"
	 *        extendedMetaData="name='EA-PACKAGE-ELEMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EA-PACKAGE-ELEMENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EAPackage getEAPackage_element();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.EAPackageableElement#getEAPackage_element <em>EA Package element</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>EA Package element</em>' container reference.
	 * @see #getEAPackage_element()
	 * @generated
	 */
	void setEAPackage_element(EAPackage value);

} // EAPackageableElement
