/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Variability</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The collection of variability descriptions, related feature models, and decision models. This collection can be done across the EAST-ADL abstraction levels.
 * 
 * Semantics:
 * See description.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.Variability</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Variability#getProductFeatureModel <em>Product Feature Model</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Variability#getConfigurableContainer <em>Configurable Container</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Variability#getVariableElement <em>Variable Element</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Variability#getConfiguration <em>Configuration</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Variability#getDecisionModel <em>Decision Model</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Variability#getContainerConfiguration <em>Container Configuration</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariability()
 * @model annotation="MetaData guid='{E26E1B9C-C049-4270-BE5E-F4A29D566864}' id='105' EA\040name='Variability'"
 *        extendedMetaData="name='VARIABILITY' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIABILITYS'"
 * @generated
 */
public interface Variability extends Context {
	/**
	 * Returns the value of the '<em><b>Product Feature Model</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FeatureModel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Feature Model</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Feature Model</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariability_ProductFeatureModel()
	 * @model containment="true"
	 *        annotation="MetaData guid='{D074206F-224D-45b1-BD80-C5AC859A8147}' id='700' EA\040name=''"
	 *        extendedMetaData="name='PRODUCT-FEATURE-MODEL' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRODUCT-FEATURE-MODELS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<FeatureModel> getProductFeatureModel();

	/**
	 * Returns the value of the '<em><b>Configurable Container</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ConfigurableContainer}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Configurable Container</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Configurable Container</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariability_ConfigurableContainer()
	 * @model containment="true"
	 *        annotation="MetaData guid='{187E0BB9-5E2A-4848-88CA-2CFF016BD707}' id='484' EA\040name=''"
	 *        extendedMetaData="name='CONFIGURABLE-CONTAINER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURABLE-CONTAINERS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ConfigurableContainer> getConfigurableContainer();

	/**
	 * Returns the value of the '<em><b>Variable Element</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VariableElement}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Variable Element</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Variable Element</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariability_VariableElement()
	 * @model containment="true"
	 *        annotation="MetaData guid='{7A44F09C-8FA1-462e-9055-1A00EB5BEA62}' id='497' EA\040name=''"
	 *        extendedMetaData="name='VARIABLE-ELEMENT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIABLE-ELEMENTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<VariableElement> getVariableElement();

	/**
	 * Returns the value of the '<em><b>Configuration</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FeatureConfiguration}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Configuration</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Configuration</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariability_Configuration()
	 * @model containment="true"
	 *        annotation="MetaData guid='{29B8EFD1-97EF-46ee-9441-DD0DE9E12006}' id='503' EA\040name=''"
	 *        extendedMetaData="name='CONFIGURATION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURATIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<FeatureConfiguration> getConfiguration();

	/**
	 * Returns the value of the '<em><b>Decision Model</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VehicleLevelBinding}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Decision Model</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Decision Model</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariability_DecisionModel()
	 * @model containment="true"
	 *        annotation="MetaData guid='{16081482-701E-4f9c-8AE7-16B0A892C0D0}' id='509' EA\040name=''"
	 *        extendedMetaData="name='DECISION-MODEL' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DECISION-MODELS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<VehicleLevelBinding> getDecisionModel();

	/**
	 * Returns the value of the '<em><b>Container Configuration</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ContainerConfiguration}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Container Configuration</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Container Configuration</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariability_ContainerConfiguration()
	 * @model containment="true"
	 *        annotation="MetaData guid='{FA7F6682-C785-47bb-8A40-CA1CAAF32513}' id='789' EA\040name=''"
	 *        extendedMetaData="name='CONTAINER-CONFIGURATION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONTAINER-CONFIGURATIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ContainerConfiguration> getContainerConfiguration();

} // Variability
