/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Timing Description</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An abstract metaclass describing the timing events and their relations by event chains within the timing model.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingDescription</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getTimingDescription()
 * @model abstract="true"
 *        annotation="MetaData guid='{38F3D4BF-090F-4282-AB8A-BF48F7B0B2EA}' id='145' EA\040name='TimingDescription'"
 *        extendedMetaData="name='TIMING-DESCRIPTION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TIMING-DESCRIPTIONS'"
 * @generated
 */
public interface TimingDescription extends EAElement {
} // TimingDescription
