/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute Quantification Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Attribute quantification constraints (AttributeQuantificationConstraint) are concerned with the value conditions of attributes underlying a behavior on a timeline. They are useful for declaring the variables (e.g. the input-, output- and internal variables of a function), their expected values and logical relations. An attribute quantification constraint can be expressed either by simple equations like F = m*a, V &gt;= 90, or dynamics models. When necessary, the straints on computational operations for data transformations and value assignment can be declared through the computation constraints (ComputationConstraint).
 * 
 * Semantics:
 * The attribute quantification constraint specification is a pair/tuple of two sets: 1. the set of attributes for the behavior being specified; 2. the set of quantification statements over the attributes.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.AttributeQuantificationConstraint.AttributeQuantificationConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.AttributeQuantificationConstraint#getAttribute <em>Attribute</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.AttributeQuantificationConstraint#getQuantification <em>Quantification</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAttributeQuantificationConstraint()
 * @model annotation="MetaData guid='{0B41219F-0A2E-4c62-94C9-4447AF15D554}' id='307' EA\040name='AttributeQuantificationConstraint'"
 *        extendedMetaData="name='ATTRIBUTE-QUANTIFICATION-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ATTRIBUTE-QUANTIFICATION-CONSTRAINTS'"
 * @generated
 */
public interface AttributeQuantificationConstraint extends EAElement {
	/**
	 * Returns the value of the '<em><b>Attribute</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Attribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attribute</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attribute</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAttributeQuantificationConstraint_Attribute()
	 * @model containment="true"
	 *        annotation="MetaData guid='{7CD350C9-D858-4bcb-A579-BB4B2E199794}' id='60' EA\040name=''"
	 *        extendedMetaData="name='ATTRIBUTE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ATTRIBUTES' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Attribute> getAttribute();

	/**
	 * Returns the value of the '<em><b>Quantification</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Quantification}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Quantification</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Quantification</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAttributeQuantificationConstraint_Quantification()
	 * @model containment="true"
	 *        annotation="MetaData guid='{35D0B484-1098-4b41-8140-F87863B7D05F}' id='61' EA\040name=''"
	 *        extendedMetaData="name='QUANTIFICATION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='QUANTIFICATIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Quantification> getQuantification();

} // AttributeQuantificationConstraint
