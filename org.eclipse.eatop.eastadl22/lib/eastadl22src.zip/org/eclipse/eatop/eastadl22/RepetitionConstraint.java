/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Repetition Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A RepetitionConstraint describes the distribution of the occurrences of a single event, including the allowance for jitter.
 * 
 * The RepetitionConstraint extends the basic notion of repeated occurrences by allowing local deviations from the ideal repetitive pattern described by a RepeatConstraint. Its jitter, lower and upper attributes all contribute to the width of the window in which occurrence number N is accepted, according to the formula N(upper-lower) + jitter. That is, with lower = upper, the uncertainty of where occurrence N may be found does not grow with an increasing N, unlike the case when lower differs from upper by a similar amount and jitter is 0. By adjusting all three attributes, a desired balance between accumulating and non-accumulating uncertainties can be obtained.
 * 
 * Semantics:
 * A system behavior satisfies a RepetitionConstraint c if and only if
 * the same system behavior concurrently satisfies
 * 
 * RepeatConstraint { event = X,
 * lower = c.lower,
 * upper = c.upper,
 * span = c.span }
 * 
 * and
 * 
 * StrongDelayConstraint { source = X,
 * target = c.event,
 * lower = 0,
 * upper = c.jitter }
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.RepetitionConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getSpan <em>Span</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getUpper <em>Upper</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getLower <em>Lower</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getJitter <em>Jitter</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getEvent <em>Event</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRepetitionConstraint()
 * @model annotation="MetaData guid='{E06C0C79-AB38-4696-84EA-C84729F71F34}' id='178' EA\040name='RepetitionConstraint'"
 *        extendedMetaData="name='REPETITION-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REPETITION-CONSTRAINTS'"
 * @generated
 */
public interface RepetitionConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Span</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Span</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Span</em>' attribute.
	 * @see #isSetSpan()
	 * @see #unsetSpan()
	 * @see #setSpan(Integer)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRepetitionConstraint_Span()
	 * @model default="0" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Integer" required="true"
	 *        annotation="MetaData guid='{B1C544F6-F930-4eb8-A522-B061E8A79E14}' id='110' EA\040name='span'"
	 *        extendedMetaData="name='SPAN' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SPANS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Integer getSpan();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getSpan <em>Span</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Span</em>' attribute.
	 * @see #isSetSpan()
	 * @see #Span()
	 * @see #getSpan()
	 * @generated
	 */
	void setSpan(Integer value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getSpan <em>Span</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetSpan()
	 * @see #getSpan()
	 * @see #setSpan(Integer)
	 * @generated
	 */
	void unsetSpan();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getSpan <em>Span</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Span</em>' attribute is set.
	 * @see #Span()
	 * @see #getSpan()
	 * @see #setSpan(Integer)
	 * @generated
	 */
	boolean isSetSpan();

	/**
	 * Returns the value of the '<em><b>Upper</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Upper</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Upper</em>' containment reference.
	 * @see #setUpper(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRepetitionConstraint_Upper()
	 * @model containment="true"
	 *        annotation="MetaData guid='{E98E1D9F-6167-4e05-84A9-28D93E811ACF}' id='294' EA\040name=''"
	 *        extendedMetaData="name='UPPER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='UPPERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getUpper();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getUpper <em>Upper</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Upper</em>' containment reference.
	 * @see #getUpper()
	 * @generated
	 */
	void setUpper(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Lower</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lower</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lower</em>' containment reference.
	 * @see #setLower(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRepetitionConstraint_Lower()
	 * @model containment="true"
	 *        annotation="MetaData guid='{A3AF9853-872C-44b4-88C0-BACC415338DE}' id='305' EA\040name=''"
	 *        extendedMetaData="name='LOWER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOWERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getLower();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getLower <em>Lower</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lower</em>' containment reference.
	 * @see #getLower()
	 * @generated
	 */
	void setLower(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Jitter</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Jitter</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Jitter</em>' containment reference.
	 * @see #setJitter(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRepetitionConstraint_Jitter()
	 * @model containment="true"
	 *        annotation="MetaData guid='{6870FFE2-1313-47b1-A11B-61C148A8B8F6}' id='316' EA\040name=''"
	 *        extendedMetaData="name='JITTER' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='JITTERS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getJitter();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getJitter <em>Jitter</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Jitter</em>' containment reference.
	 * @see #getJitter()
	 * @generated
	 */
	void setJitter(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Event</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' reference.
	 * @see #setEvent(Event)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRepetitionConstraint_Event()
	 * @model required="true"
	 *        annotation="MetaData guid='{436021CB-978A-4ac1-8423-80F8DAF96E80}' id='377' EA\040name=''"
	 *        extendedMetaData="name='EVENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Event getEvent();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.RepetitionConstraint#getEvent <em>Event</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event</em>' reference.
	 * @see #getEvent()
	 * @generated
	 */
	void setEvent(Event value);

} // RepetitionConstraint
