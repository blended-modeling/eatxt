/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Internal Binding binding Through Hardware Connector</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription._instanceRef.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector#getHardwareComponentPrototype <em>Hardware Component Prototype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector#getHardwareConnector <em>Hardware Connector</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding_bindingThroughHardwareConnector()
 * @model annotation="MetaData guid='{F7660468-FA34-43f8-8A5A-88E151DF890C}' id='305' EA\040name='BehaviorConstraintInternalBinding_bindingThroughHardwareConnector'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='BEHAVIOR-CONSTRAINT-INTERNAL-BINDING--BINDING-THROUGH-HARDWARE-CONNECTOR-IREF'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-INTERNAL-BINDING--BINDING-THROUGH-HARDWARE-CONNECTOR-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-INTERNAL-BINDING--BINDING-THROUGH-HARDWARE-CONNECTOR-IREFS'"
 * @generated
 */
public interface BehaviorConstraintInternalBinding_bindingThroughHardwareConnector extends EObject {
	/**
	 * Returns the value of the '<em><b>Hardware Component Prototype</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.HardwareComponentPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hardware Component Prototype</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hardware Component Prototype</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding_bindingThroughHardwareConnector_HardwareComponentPrototype()
	 * @model annotation="MetaData guid='{43020A29-4DEE-4a77-870B-DB2DAE909519}' id='578' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.context'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='HARDWARE-COMPONENT-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HARDWARE-COMPONENT-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<HardwareComponentPrototype> getHardwareComponentPrototype();

	/**
	 * Returns the value of the '<em><b>Hardware Connector</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hardware Connector</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hardware Connector</em>' reference.
	 * @see #setHardwareConnector(HardwareConnector)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintInternalBinding_bindingThroughHardwareConnector_HardwareConnector()
	 * @model required="true"
	 *        annotation="MetaData guid='{DB7B5981-8AB5-4dda-9313-C3014CB3A7D1}' id='583' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.target'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='HARDWARE-CONNECTOR-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HARDWARE-CONNECTOR-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	HardwareConnector getHardwareConnector();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector#getHardwareConnector <em>Hardware Connector</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hardware Connector</em>' reference.
	 * @see #getHardwareConnector()
	 * @generated
	 */
	void setHardwareConnector(HardwareConnector value);

} // BehaviorConstraintInternalBinding_bindingThroughHardwareConnector
