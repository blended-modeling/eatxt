/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Extension Point</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ExtensionPoint represents a feature of a UseCase that identifies a point where the behavior of a UseCase can be augmented with elements of another (extending) UseCase.
 * 
 * Semantics:
 * ExtensionPoint identifies the point where the useCase UseCase ca be extended.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.UseCases.ExtensionPoint</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getExtensionPoint()
 * @model annotation="MetaData guid='{021DB515-A163-4273-93C1-89CFDD95E0B0}' id='124' EA\040name='ExtensionPoint'"
 *        extendedMetaData="name='EXTENSION-POINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EXTENSION-POINTS'"
 * @generated
 */
public interface ExtensionPoint extends RedefinableElement {
} // ExtensionPoint
