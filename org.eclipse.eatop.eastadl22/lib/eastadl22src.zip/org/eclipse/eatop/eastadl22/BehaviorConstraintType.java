/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The specification of behavior constraints provides the modeling support for formalizing, integrating, and managing various behavioral concerns in a common context of system architecture design. A behavior constraint can be annotated either for refining requirements or for precisely defining the behavioral properties of design and analysis artifacts. 
 * 
 * According to the fundamental needs of system design and analysis, an EAST-ADL behavior constraint specification is subdivided into three categories (i.e. AttributeQuantificationConstraint, TemporalConstraint, and ComputationConstraint). It is up to the users of EAST-ADL language, according to their particular design and analysis contexts, to decide the exact types and degree of constraints to be applied.
 * 
 * A behavior constraint specification has both type and prototype(s) based on a type-prototype pattern for composition. The behavior constraint type specification establishes a template for a range of behavioral concerns that share some common declarations and semantics. A behavior constraint type can have parameters (i.e. events and data) for its instantiations in particular contexts. A behavior constraint type can also have internal parameters shareable by its own prototypes. The behavior constraint prototype specifications declare the particular instantiations of the type. During an instantiation, the parameters of behavior constraint type are bound to some parameters of the contexts (which are the partBindingParameter of the contextual behavior constraint types). Through such binding declarations, the prototypes of behavior constraint types (i.e. their instantiations) are connected to the contextual parameters. 
 * 
 * EAST-ADL associates behavior constraints to the requirements, design or analysis artifacts. Due to such associations, a behavior constraint specification can get many different roles in system development and thereby be composed with or related to other behavior constraints in many different ways. 
 * 
 * 1. When associated to requirements with a Refine relationship, a behavior constraint specification refines the textual requirement descriptions.  
 * 
 * 2. When associated to functions and function behaviors, a behavior constraint specification defines the behavioral properties that have to be satisfied for the reasoning of system design (i.e. the compositionality and composability) and realizations.
 * 
 * 3. When associated to modes, a behavior constraint specification defines the behavioral concerns of system modes, including their relations to other system application and execution behaviors. 
 * 
 * 4. When associated to error models, a behavior constraint specification refines the definitions of estimated failure modes by providing a precise specification of faulty conditions in value and time and constitutes a basis for capturing the transitions between nominal states and errors.
 * 
 * Constraints:
 * [1] A behavior constraint references at least one requirement, vehicle feature, mode, function type, function behavior, function trigger, or error behavior definition. 
 * 
 * Semantics:
 * The EAST-ADL support for explicit behavior description is fundamentally a Hybrid-System Model, i.e. an aggregation of AttributeQuantificationConstraint, TemporalConstraint, and ComputationConstraint.
 * 
 * A behavior constraint type is instantiated with prototypes.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.BehaviorConstraintType</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintType#getPart <em>Part</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintType#getInterfaceVariable <em>Interface Variable</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintType#getSharedVariable <em>Shared Variable</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintType#getAttributeQuantificationConstraint <em>Attribute Quantification Constraint</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintType#getComputationConstraint <em>Computation Constraint</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintType#getTemporalConstraint <em>Temporal Constraint</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintType()
 * @model annotation="MetaData guid='{5D04C798-F855-4d2b-8563-BF3ECFF838C3}' id='292' EA\040name='BehaviorConstraintType'"
 *        annotation="Stereotype Stereotype='atpType'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-TYPE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-TYPES'"
 * @generated
 */
public interface BehaviorConstraintType extends Context {
	/**
	 * Returns the value of the '<em><b>Part</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Part</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Part</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintType_Part()
	 * @model containment="true"
	 *        annotation="MetaData guid='{FAA463CB-D05F-4d82-A831-B312485FCC18}' id='69' EA\040name=''"
	 *        extendedMetaData="name='PART' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PARTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<BehaviorConstraintPrototype> getPart();

	/**
	 * Returns the value of the '<em><b>Interface Variable</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.BehaviorConstraintParameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interface Variable</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interface Variable</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintType_InterfaceVariable()
	 * @model annotation="MetaData guid='{7E39F550-A084-40e5-A87E-6FB620D2D2AB}' id='72' EA\040name=''"
	 *        extendedMetaData="name='INTERFACE-VARIABLE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INTERFACE-VARIABLE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<BehaviorConstraintParameter> getInterfaceVariable();

	/**
	 * Returns the value of the '<em><b>Shared Variable</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Shared Variable</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Shared Variable</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintType_SharedVariable()
	 * @model annotation="MetaData guid='{2425F198-3753-40a2-BD96-A1A97106C332}' id='81' EA\040name=''"
	 *        extendedMetaData="name='SHARED-VARIABLE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SHARED-VARIABLE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<BehaviorConstraintInternalBinding> getSharedVariable();

	/**
	 * Returns the value of the '<em><b>Attribute Quantification Constraint</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.AttributeQuantificationConstraint}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attribute Quantification Constraint</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attribute Quantification Constraint</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintType_AttributeQuantificationConstraint()
	 * @model containment="true"
	 *        annotation="MetaData guid='{5678AD2B-F22A-4165-8062-D562EA42E940}' id='73' EA\040name=''"
	 *        extendedMetaData="name='ATTRIBUTE-QUANTIFICATION-CONSTRAINT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ATTRIBUTE-QUANTIFICATION-CONSTRAINTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<AttributeQuantificationConstraint> getAttributeQuantificationConstraint();

	/**
	 * Returns the value of the '<em><b>Computation Constraint</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ComputationConstraint}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Computation Constraint</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Computation Constraint</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintType_ComputationConstraint()
	 * @model containment="true"
	 *        annotation="MetaData guid='{934730CF-09BA-4955-97A7-A90C14F01735}' id='71' EA\040name=''"
	 *        extendedMetaData="name='COMPUTATION-CONSTRAINT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='COMPUTATION-CONSTRAINTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<ComputationConstraint> getComputationConstraint();

	/**
	 * Returns the value of the '<em><b>Temporal Constraint</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.TemporalConstraint}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Temporal Constraint</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temporal Constraint</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintType_TemporalConstraint()
	 * @model containment="true"
	 *        annotation="MetaData guid='{9D621BC9-0BF1-46b1-8678-76FC4830A2CD}' id='70' EA\040name=''"
	 *        extendedMetaData="name='TEMPORAL-CONSTRAINT' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TEMPORAL-CONSTRAINTS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<TemporalConstraint> getTemporalConstraint();

} // BehaviorConstraintType
