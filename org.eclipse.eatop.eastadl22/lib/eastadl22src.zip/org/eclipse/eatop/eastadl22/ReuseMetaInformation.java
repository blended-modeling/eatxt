/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reuse Meta Information</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * ReuseMetaInformation represents the description information needed in the context of reuse. For example a specific entity is only a short-time solution that is not intended to be reused. Also a specific entity can only be reused for specific model ranges (that are not reflected in the product model). 
 * 
 * Semantics:
 * The ReuseMetaInformation represents information that explains if and how the respective entity can be reused.
 * 
 * 
 * Extension: Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.ReuseMetaInformation</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ReuseMetaInformation#getInformation <em>Information</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ReuseMetaInformation#getIsReusable <em>Is Reusable</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getReuseMetaInformation()
 * @model annotation="MetaData guid='{FA9D68F0-A8DD-4391-B526-4C5CFC3A1F01}' id='106' EA\040name='ReuseMetaInformation'"
 *        extendedMetaData="name='REUSE-META-INFORMATION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REUSE-META-INFORMATIONS'"
 * @generated
 */
public interface ReuseMetaInformation extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Information</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * The reuse information is stored in this attribute.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Information</em>' attribute.
	 * @see #isSetInformation()
	 * @see #unsetInformation()
	 * @see #setInformation(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getReuseMetaInformation_Information()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String" required="true"
	 *        annotation="MetaData guid='{4F1947D0-322C-4a60-8289-89DC25E04B53}' id='84' EA\040name='information'"
	 *        extendedMetaData="name='INFORMATION' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INFORMATIONS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getInformation();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ReuseMetaInformation#getInformation <em>Information</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Information</em>' attribute.
	 * @see #isSetInformation()
	 * @see #Information()
	 * @see #getInformation()
	 * @generated
	 */
	void setInformation(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.ReuseMetaInformation#getInformation <em>Information</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetInformation()
	 * @see #getInformation()
	 * @see #setInformation(String)
	 * @generated
	 */
	void unsetInformation();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.ReuseMetaInformation#getInformation <em>Information</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Information</em>' attribute is set.
	 * @see #Information()
	 * @see #getInformation()
	 * @see #setInformation(String)
	 * @generated
	 */
	boolean isSetInformation();

	/**
	 * Returns the value of the '<em><b>Is Reusable</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This Boolean attributes just says whether the owning VariableElement itself can essentially be reused or not. Specific information or constraints on reuse are in the information attribute.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Reusable</em>' attribute.
	 * @see #isSetIsReusable()
	 * @see #unsetIsReusable()
	 * @see #setIsReusable(Boolean)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getReuseMetaInformation_IsReusable()
	 * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Boolean" required="true"
	 *        annotation="MetaData guid='{B12BADDA-DE6A-46be-95DC-2D59805D5377}' id='85' EA\040name='isReusable'"
	 *        extendedMetaData="name='IS-REUSABLE' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-REUSABLES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Boolean getIsReusable();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ReuseMetaInformation#getIsReusable <em>Is Reusable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Reusable</em>' attribute.
	 * @see #isSetIsReusable()
	 * @see #IsReusable()
	 * @see #getIsReusable()
	 * @generated
	 */
	void setIsReusable(Boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.ReuseMetaInformation#getIsReusable <em>Is Reusable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsReusable()
	 * @see #getIsReusable()
	 * @see #setIsReusable(Boolean)
	 * @generated
	 */
	void unsetIsReusable();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.ReuseMetaInformation#getIsReusable <em>Is Reusable</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Reusable</em>' attribute is set.
	 * @see #IsReusable()
	 * @see #getIsReusable()
	 * @see #setIsReusable(Boolean)
	 * @generated
	 */
	boolean isSetIsReusable();

} // ReuseMetaInformation
