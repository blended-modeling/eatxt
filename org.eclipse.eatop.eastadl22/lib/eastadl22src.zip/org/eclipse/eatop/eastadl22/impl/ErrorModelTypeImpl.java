/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.ErrorBehavior;
import org.eclipse.eatop.eastadl22.ErrorModelPrototype;
import org.eclipse.eatop.eastadl22.ErrorModelType;
import org.eclipse.eatop.eastadl22.FailureOutPort;
import org.eclipse.eatop.eastadl22.FaultFailurePropagationLink;
import org.eclipse.eatop.eastadl22.FaultInPort;
import org.eclipse.eatop.eastadl22.FunctionType;
import org.eclipse.eatop.eastadl22.HardwareComponentType;
import org.eclipse.eatop.eastadl22.InternalFaultPrototype;
import org.eclipse.eatop.eastadl22.ProcessFaultPrototype;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Error Model Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ErrorModelTypeImpl#getErrorBehaviorDescription <em>Error Behavior Description</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ErrorModelTypeImpl#getExternalFault <em>External Fault</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ErrorModelTypeImpl#getPart <em>Part</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ErrorModelTypeImpl#getFaultFailureConnector <em>Fault Failure Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ErrorModelTypeImpl#getHwTarget <em>Hw Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ErrorModelTypeImpl#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ErrorModelTypeImpl#getFailure <em>Failure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ErrorModelTypeImpl#getInternalFault <em>Internal Fault</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ErrorModelTypeImpl#getProcessFault <em>Process Fault</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ErrorModelTypeImpl extends TraceableSpecificationImpl implements ErrorModelType {
	/**
	 * The cached value of the '{@link #getErrorBehaviorDescription() <em>Error Behavior Description</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getErrorBehaviorDescription()
	 * @generated
	 * @ordered
	 */
	protected EList<ErrorBehavior> errorBehaviorDescription;

	/**
	 * The cached value of the '{@link #getExternalFault() <em>External Fault</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExternalFault()
	 * @generated
	 * @ordered
	 */
	protected EList<FaultInPort> externalFault;

	/**
	 * The cached value of the '{@link #getPart() <em>Part</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPart()
	 * @generated
	 * @ordered
	 */
	protected EList<ErrorModelPrototype> part;

	/**
	 * The cached value of the '{@link #getFaultFailureConnector() <em>Fault Failure Connector</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFaultFailureConnector()
	 * @generated
	 * @ordered
	 */
	protected EList<FaultFailurePropagationLink> faultFailureConnector;

	/**
	 * The cached value of the '{@link #getHwTarget() <em>Hw Target</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHwTarget()
	 * @generated
	 * @ordered
	 */
	protected EList<HardwareComponentType> hwTarget;

	/**
	 * The cached value of the '{@link #getTarget() <em>Target</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget()
	 * @generated
	 * @ordered
	 */
	protected EList<FunctionType> target;

	/**
	 * The cached value of the '{@link #getFailure() <em>Failure</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFailure()
	 * @generated
	 * @ordered
	 */
	protected EList<FailureOutPort> failure;

	/**
	 * The cached value of the '{@link #getInternalFault() <em>Internal Fault</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInternalFault()
	 * @generated
	 * @ordered
	 */
	protected EList<InternalFaultPrototype> internalFault;

	/**
	 * The cached value of the '{@link #getProcessFault() <em>Process Fault</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProcessFault()
	 * @generated
	 * @ordered
	 */
	protected EList<ProcessFaultPrototype> processFault;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ErrorModelTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getErrorModelType();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ErrorBehavior> getErrorBehaviorDescription() {
		if (errorBehaviorDescription == null) {
			errorBehaviorDescription = new EObjectContainmentEList<ErrorBehavior>(ErrorBehavior.class, this, Eastadl22Package.ERROR_MODEL_TYPE__ERROR_BEHAVIOR_DESCRIPTION);
		}
		return errorBehaviorDescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FaultInPort> getExternalFault() {
		if (externalFault == null) {
			externalFault = new EObjectContainmentEList<FaultInPort>(FaultInPort.class, this, Eastadl22Package.ERROR_MODEL_TYPE__EXTERNAL_FAULT);
		}
		return externalFault;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ErrorModelPrototype> getPart() {
		if (part == null) {
			part = new EObjectContainmentEList<ErrorModelPrototype>(ErrorModelPrototype.class, this, Eastadl22Package.ERROR_MODEL_TYPE__PART);
		}
		return part;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FaultFailurePropagationLink> getFaultFailureConnector() {
		if (faultFailureConnector == null) {
			faultFailureConnector = new EObjectContainmentEList<FaultFailurePropagationLink>(FaultFailurePropagationLink.class, this, Eastadl22Package.ERROR_MODEL_TYPE__FAULT_FAILURE_CONNECTOR);
		}
		return faultFailureConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<HardwareComponentType> getHwTarget() {
		if (hwTarget == null) {
			hwTarget = new EObjectResolvingEList<HardwareComponentType>(HardwareComponentType.class, this, Eastadl22Package.ERROR_MODEL_TYPE__HW_TARGET);
		}
		return hwTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FunctionType> getTarget() {
		if (target == null) {
			target = new EObjectResolvingEList<FunctionType>(FunctionType.class, this, Eastadl22Package.ERROR_MODEL_TYPE__TARGET);
		}
		return target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FailureOutPort> getFailure() {
		if (failure == null) {
			failure = new EObjectContainmentEList<FailureOutPort>(FailureOutPort.class, this, Eastadl22Package.ERROR_MODEL_TYPE__FAILURE);
		}
		return failure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<InternalFaultPrototype> getInternalFault() {
		if (internalFault == null) {
			internalFault = new EObjectContainmentEList<InternalFaultPrototype>(InternalFaultPrototype.class, this, Eastadl22Package.ERROR_MODEL_TYPE__INTERNAL_FAULT);
		}
		return internalFault;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ProcessFaultPrototype> getProcessFault() {
		if (processFault == null) {
			processFault = new EObjectContainmentEList<ProcessFaultPrototype>(ProcessFaultPrototype.class, this, Eastadl22Package.ERROR_MODEL_TYPE__PROCESS_FAULT);
		}
		return processFault;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.ERROR_MODEL_TYPE__ERROR_BEHAVIOR_DESCRIPTION:
				return ((InternalEList<?>)getErrorBehaviorDescription()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.ERROR_MODEL_TYPE__EXTERNAL_FAULT:
				return ((InternalEList<?>)getExternalFault()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.ERROR_MODEL_TYPE__PART:
				return ((InternalEList<?>)getPart()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.ERROR_MODEL_TYPE__FAULT_FAILURE_CONNECTOR:
				return ((InternalEList<?>)getFaultFailureConnector()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.ERROR_MODEL_TYPE__FAILURE:
				return ((InternalEList<?>)getFailure()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.ERROR_MODEL_TYPE__INTERNAL_FAULT:
				return ((InternalEList<?>)getInternalFault()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.ERROR_MODEL_TYPE__PROCESS_FAULT:
				return ((InternalEList<?>)getProcessFault()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.ERROR_MODEL_TYPE__ERROR_BEHAVIOR_DESCRIPTION:
				return getErrorBehaviorDescription();
			case Eastadl22Package.ERROR_MODEL_TYPE__EXTERNAL_FAULT:
				return getExternalFault();
			case Eastadl22Package.ERROR_MODEL_TYPE__PART:
				return getPart();
			case Eastadl22Package.ERROR_MODEL_TYPE__FAULT_FAILURE_CONNECTOR:
				return getFaultFailureConnector();
			case Eastadl22Package.ERROR_MODEL_TYPE__HW_TARGET:
				return getHwTarget();
			case Eastadl22Package.ERROR_MODEL_TYPE__TARGET:
				return getTarget();
			case Eastadl22Package.ERROR_MODEL_TYPE__FAILURE:
				return getFailure();
			case Eastadl22Package.ERROR_MODEL_TYPE__INTERNAL_FAULT:
				return getInternalFault();
			case Eastadl22Package.ERROR_MODEL_TYPE__PROCESS_FAULT:
				return getProcessFault();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.ERROR_MODEL_TYPE__ERROR_BEHAVIOR_DESCRIPTION:
				getErrorBehaviorDescription().clear();
				getErrorBehaviorDescription().addAll((Collection<? extends ErrorBehavior>)newValue);
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__EXTERNAL_FAULT:
				getExternalFault().clear();
				getExternalFault().addAll((Collection<? extends FaultInPort>)newValue);
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__PART:
				getPart().clear();
				getPart().addAll((Collection<? extends ErrorModelPrototype>)newValue);
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__FAULT_FAILURE_CONNECTOR:
				getFaultFailureConnector().clear();
				getFaultFailureConnector().addAll((Collection<? extends FaultFailurePropagationLink>)newValue);
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__HW_TARGET:
				getHwTarget().clear();
				getHwTarget().addAll((Collection<? extends HardwareComponentType>)newValue);
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__TARGET:
				getTarget().clear();
				getTarget().addAll((Collection<? extends FunctionType>)newValue);
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__FAILURE:
				getFailure().clear();
				getFailure().addAll((Collection<? extends FailureOutPort>)newValue);
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__INTERNAL_FAULT:
				getInternalFault().clear();
				getInternalFault().addAll((Collection<? extends InternalFaultPrototype>)newValue);
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__PROCESS_FAULT:
				getProcessFault().clear();
				getProcessFault().addAll((Collection<? extends ProcessFaultPrototype>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.ERROR_MODEL_TYPE__ERROR_BEHAVIOR_DESCRIPTION:
				getErrorBehaviorDescription().clear();
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__EXTERNAL_FAULT:
				getExternalFault().clear();
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__PART:
				getPart().clear();
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__FAULT_FAILURE_CONNECTOR:
				getFaultFailureConnector().clear();
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__HW_TARGET:
				getHwTarget().clear();
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__TARGET:
				getTarget().clear();
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__FAILURE:
				getFailure().clear();
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__INTERNAL_FAULT:
				getInternalFault().clear();
				return;
			case Eastadl22Package.ERROR_MODEL_TYPE__PROCESS_FAULT:
				getProcessFault().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.ERROR_MODEL_TYPE__ERROR_BEHAVIOR_DESCRIPTION:
				return errorBehaviorDescription != null && !errorBehaviorDescription.isEmpty();
			case Eastadl22Package.ERROR_MODEL_TYPE__EXTERNAL_FAULT:
				return externalFault != null && !externalFault.isEmpty();
			case Eastadl22Package.ERROR_MODEL_TYPE__PART:
				return part != null && !part.isEmpty();
			case Eastadl22Package.ERROR_MODEL_TYPE__FAULT_FAILURE_CONNECTOR:
				return faultFailureConnector != null && !faultFailureConnector.isEmpty();
			case Eastadl22Package.ERROR_MODEL_TYPE__HW_TARGET:
				return hwTarget != null && !hwTarget.isEmpty();
			case Eastadl22Package.ERROR_MODEL_TYPE__TARGET:
				return target != null && !target.isEmpty();
			case Eastadl22Package.ERROR_MODEL_TYPE__FAILURE:
				return failure != null && !failure.isEmpty();
			case Eastadl22Package.ERROR_MODEL_TYPE__INTERNAL_FAULT:
				return internalFault != null && !internalFault.isEmpty();
			case Eastadl22Package.ERROR_MODEL_TYPE__PROCESS_FAULT:
				return processFault != null && !processFault.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ErrorModelTypeImpl
