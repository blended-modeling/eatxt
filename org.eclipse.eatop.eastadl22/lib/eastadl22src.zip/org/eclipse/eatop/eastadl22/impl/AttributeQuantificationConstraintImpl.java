/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Attribute;
import org.eclipse.eatop.eastadl22.AttributeQuantificationConstraint;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.Quantification;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attribute Quantification Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.AttributeQuantificationConstraintImpl#getAttribute <em>Attribute</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.AttributeQuantificationConstraintImpl#getQuantification <em>Quantification</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AttributeQuantificationConstraintImpl extends EAElementImpl implements AttributeQuantificationConstraint {
	/**
	 * The cached value of the '{@link #getAttribute() <em>Attribute</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttribute()
	 * @generated
	 * @ordered
	 */
	protected EList<Attribute> attribute;

	/**
	 * The cached value of the '{@link #getQuantification() <em>Quantification</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQuantification()
	 * @generated
	 * @ordered
	 */
	protected EList<Quantification> quantification;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttributeQuantificationConstraintImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getAttributeQuantificationConstraint();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Attribute> getAttribute() {
		if (attribute == null) {
			attribute = new EObjectContainmentEList<Attribute>(Attribute.class, this, Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__ATTRIBUTE);
		}
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Quantification> getQuantification() {
		if (quantification == null) {
			quantification = new EObjectContainmentEList<Quantification>(Quantification.class, this, Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__QUANTIFICATION);
		}
		return quantification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__ATTRIBUTE:
				return ((InternalEList<?>)getAttribute()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__QUANTIFICATION:
				return ((InternalEList<?>)getQuantification()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__ATTRIBUTE:
				return getAttribute();
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__QUANTIFICATION:
				return getQuantification();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__ATTRIBUTE:
				getAttribute().clear();
				getAttribute().addAll((Collection<? extends Attribute>)newValue);
				return;
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__QUANTIFICATION:
				getQuantification().clear();
				getQuantification().addAll((Collection<? extends Quantification>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__ATTRIBUTE:
				getAttribute().clear();
				return;
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__QUANTIFICATION:
				getQuantification().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__ATTRIBUTE:
				return attribute != null && !attribute.isEmpty();
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT__QUANTIFICATION:
				return quantification != null && !quantification.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //AttributeQuantificationConstraintImpl
