/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.BindingTimeKind;
import org.eclipse.eatop.eastadl22.EAValue;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.Feature;
import org.eclipse.eatop.eastadl22.FeatureTreeNode;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Feature</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FeatureImpl#getCardinality <em>Cardinality</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FeatureImpl#getActualBindingTime <em>Actual Binding Time</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FeatureImpl#getRequiredBindingTime <em>Required Binding Time</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FeatureImpl#getFeatureParameter <em>Feature Parameter</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FeatureImpl#getChildNode <em>Child Node</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FeatureImpl extends FeatureTreeNodeImpl implements Feature {
	/**
	 * The default value of the '{@link #getCardinality() <em>Cardinality</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardinality()
	 * @generated
	 * @ordered
	 */
	protected static final String CARDINALITY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCardinality() <em>Cardinality</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardinality()
	 * @generated
	 * @ordered
	 */
	protected String cardinality = CARDINALITY_EDEFAULT;

	/**
	 * This is true if the Cardinality attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean cardinalityESet;

	/**
	 * The default value of the '{@link #getActualBindingTime() <em>Actual Binding Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActualBindingTime()
	 * @generated
	 * @ordered
	 */
	protected static final BindingTimeKind ACTUAL_BINDING_TIME_EDEFAULT = BindingTimeKind.SYSTEM_DESIGN_TIME;

	/**
	 * The cached value of the '{@link #getActualBindingTime() <em>Actual Binding Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActualBindingTime()
	 * @generated
	 * @ordered
	 */
	protected BindingTimeKind actualBindingTime = ACTUAL_BINDING_TIME_EDEFAULT;

	/**
	 * This is true if the Actual Binding Time attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean actualBindingTimeESet;

	/**
	 * The default value of the '{@link #getRequiredBindingTime() <em>Required Binding Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequiredBindingTime()
	 * @generated
	 * @ordered
	 */
	protected static final BindingTimeKind REQUIRED_BINDING_TIME_EDEFAULT = BindingTimeKind.SYSTEM_DESIGN_TIME;

	/**
	 * The cached value of the '{@link #getRequiredBindingTime() <em>Required Binding Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequiredBindingTime()
	 * @generated
	 * @ordered
	 */
	protected BindingTimeKind requiredBindingTime = REQUIRED_BINDING_TIME_EDEFAULT;

	/**
	 * This is true if the Required Binding Time attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean requiredBindingTimeESet;

	/**
	 * The cached value of the '{@link #getFeatureParameter() <em>Feature Parameter</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFeatureParameter()
	 * @generated
	 * @ordered
	 */
	protected EAValue featureParameter;

	/**
	 * The cached value of the '{@link #getChildNode() <em>Child Node</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChildNode()
	 * @generated
	 * @ordered
	 */
	protected EList<FeatureTreeNode> childNode;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FeatureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getFeature();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCardinality() {
		return cardinality;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardinality(String newCardinality) {
		String oldCardinality = cardinality;
		cardinality = newCardinality;
		boolean oldCardinalityESet = cardinalityESet;
		cardinalityESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FEATURE__CARDINALITY, oldCardinality, cardinality, !oldCardinalityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetCardinality() {
		String oldCardinality = cardinality;
		boolean oldCardinalityESet = cardinalityESet;
		cardinality = CARDINALITY_EDEFAULT;
		cardinalityESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.FEATURE__CARDINALITY, oldCardinality, CARDINALITY_EDEFAULT, oldCardinalityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetCardinality() {
		return cardinalityESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BindingTimeKind getActualBindingTime() {
		return actualBindingTime;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActualBindingTime(BindingTimeKind newActualBindingTime) {
		BindingTimeKind oldActualBindingTime = actualBindingTime;
		actualBindingTime = newActualBindingTime == null ? ACTUAL_BINDING_TIME_EDEFAULT : newActualBindingTime;
		boolean oldActualBindingTimeESet = actualBindingTimeESet;
		actualBindingTimeESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FEATURE__ACTUAL_BINDING_TIME, oldActualBindingTime, actualBindingTime, !oldActualBindingTimeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetActualBindingTime() {
		BindingTimeKind oldActualBindingTime = actualBindingTime;
		boolean oldActualBindingTimeESet = actualBindingTimeESet;
		actualBindingTime = ACTUAL_BINDING_TIME_EDEFAULT;
		actualBindingTimeESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.FEATURE__ACTUAL_BINDING_TIME, oldActualBindingTime, ACTUAL_BINDING_TIME_EDEFAULT, oldActualBindingTimeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetActualBindingTime() {
		return actualBindingTimeESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BindingTimeKind getRequiredBindingTime() {
		return requiredBindingTime;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRequiredBindingTime(BindingTimeKind newRequiredBindingTime) {
		BindingTimeKind oldRequiredBindingTime = requiredBindingTime;
		requiredBindingTime = newRequiredBindingTime == null ? REQUIRED_BINDING_TIME_EDEFAULT : newRequiredBindingTime;
		boolean oldRequiredBindingTimeESet = requiredBindingTimeESet;
		requiredBindingTimeESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FEATURE__REQUIRED_BINDING_TIME, oldRequiredBindingTime, requiredBindingTime, !oldRequiredBindingTimeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetRequiredBindingTime() {
		BindingTimeKind oldRequiredBindingTime = requiredBindingTime;
		boolean oldRequiredBindingTimeESet = requiredBindingTimeESet;
		requiredBindingTime = REQUIRED_BINDING_TIME_EDEFAULT;
		requiredBindingTimeESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.FEATURE__REQUIRED_BINDING_TIME, oldRequiredBindingTime, REQUIRED_BINDING_TIME_EDEFAULT, oldRequiredBindingTimeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetRequiredBindingTime() {
		return requiredBindingTimeESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAValue getFeatureParameter() {
		if (featureParameter != null && featureParameter.eIsProxy()) {
			InternalEObject oldFeatureParameter = (InternalEObject)featureParameter;
			featureParameter = (EAValue)eResolveProxy(oldFeatureParameter);
			if (featureParameter != oldFeatureParameter) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.FEATURE__FEATURE_PARAMETER, oldFeatureParameter, featureParameter));
			}
		}
		return featureParameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAValue basicGetFeatureParameter() {
		return featureParameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFeatureParameter(EAValue newFeatureParameter) {
		EAValue oldFeatureParameter = featureParameter;
		featureParameter = newFeatureParameter;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FEATURE__FEATURE_PARAMETER, oldFeatureParameter, featureParameter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FeatureTreeNode> getChildNode() {
		if (childNode == null) {
			childNode = new EObjectContainmentEList<FeatureTreeNode>(FeatureTreeNode.class, this, Eastadl22Package.FEATURE__CHILD_NODE);
		}
		return childNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.FEATURE__CHILD_NODE:
				return ((InternalEList<?>)getChildNode()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.FEATURE__CARDINALITY:
				return getCardinality();
			case Eastadl22Package.FEATURE__ACTUAL_BINDING_TIME:
				return getActualBindingTime();
			case Eastadl22Package.FEATURE__REQUIRED_BINDING_TIME:
				return getRequiredBindingTime();
			case Eastadl22Package.FEATURE__FEATURE_PARAMETER:
				if (resolve) return getFeatureParameter();
				return basicGetFeatureParameter();
			case Eastadl22Package.FEATURE__CHILD_NODE:
				return getChildNode();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.FEATURE__CARDINALITY:
   			setCardinality((String)newValue);
				return;
			case Eastadl22Package.FEATURE__ACTUAL_BINDING_TIME:
   			setActualBindingTime((BindingTimeKind)newValue);
				return;
			case Eastadl22Package.FEATURE__REQUIRED_BINDING_TIME:
   			setRequiredBindingTime((BindingTimeKind)newValue);
				return;
			case Eastadl22Package.FEATURE__FEATURE_PARAMETER:
   			setFeatureParameter((EAValue)newValue);
				return;
			case Eastadl22Package.FEATURE__CHILD_NODE:
				getChildNode().clear();
				getChildNode().addAll((Collection<? extends FeatureTreeNode>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FEATURE__CARDINALITY:
				unsetCardinality();
				return;
			case Eastadl22Package.FEATURE__ACTUAL_BINDING_TIME:
				unsetActualBindingTime();
				return;
			case Eastadl22Package.FEATURE__REQUIRED_BINDING_TIME:
				unsetRequiredBindingTime();
				return;
			case Eastadl22Package.FEATURE__FEATURE_PARAMETER:
		    	setFeatureParameter((EAValue)null);
				return;
			case Eastadl22Package.FEATURE__CHILD_NODE:
				getChildNode().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FEATURE__CARDINALITY:
				return isSetCardinality();
			case Eastadl22Package.FEATURE__ACTUAL_BINDING_TIME:
				return isSetActualBindingTime();
			case Eastadl22Package.FEATURE__REQUIRED_BINDING_TIME:
				return isSetRequiredBindingTime();
			case Eastadl22Package.FEATURE__FEATURE_PARAMETER:
				return featureParameter != null;
			case Eastadl22Package.FEATURE__CHILD_NODE:
				return childNode != null && !childNode.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (cardinality: ");
		if (cardinalityESet) result.append(cardinality); else result.append("<unset>");
		result.append(", actualBindingTime: ");
		if (actualBindingTimeESet) result.append(actualBindingTime); else result.append("<unset>");
		result.append(", requiredBindingTime: ");
		if (requiredBindingTimeESet) result.append(requiredBindingTime); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //FeatureImpl
