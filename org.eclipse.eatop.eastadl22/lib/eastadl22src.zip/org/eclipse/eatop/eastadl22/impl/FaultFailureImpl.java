/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import org.eclipse.eatop.eastadl22.EAValue;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.FaultFailure;
import org.eclipse.eatop.eastadl22.FaultFailure_anomaly;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fault Failure</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FaultFailureImpl#getAnomaly <em>Anomaly</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FaultFailureImpl#getFaultFailureValue <em>Fault Failure Value</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FaultFailureImpl extends TraceableSpecificationImpl implements FaultFailure {
	/**
	 * The cached value of the '{@link #getAnomaly() <em>Anomaly</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnomaly()
	 * @generated
	 * @ordered
	 */
	protected FaultFailure_anomaly anomaly;

	/**
	 * The cached value of the '{@link #getFaultFailureValue() <em>Fault Failure Value</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFaultFailureValue()
	 * @generated
	 * @ordered
	 */
	protected EAValue faultFailureValue;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FaultFailureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getFaultFailure();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FaultFailure_anomaly getAnomaly() {
		return anomaly;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAnomaly(FaultFailure_anomaly newAnomaly, NotificationChain msgs) {
		FaultFailure_anomaly oldAnomaly = anomaly;
		anomaly = newAnomaly;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl22Package.FAULT_FAILURE__ANOMALY, oldAnomaly, newAnomaly);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAnomaly(FaultFailure_anomaly newAnomaly) {
		if (newAnomaly != anomaly) {
			NotificationChain msgs = null;
			if (anomaly != null)
				msgs = ((InternalEObject)anomaly).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl22Package.FAULT_FAILURE__ANOMALY, null, msgs);
			if (newAnomaly != null)
				msgs = ((InternalEObject)newAnomaly).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl22Package.FAULT_FAILURE__ANOMALY, null, msgs);
			msgs = basicSetAnomaly(newAnomaly, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FAULT_FAILURE__ANOMALY, newAnomaly, newAnomaly));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAValue getFaultFailureValue() {
		return faultFailureValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFaultFailureValue(EAValue newFaultFailureValue, NotificationChain msgs) {
		EAValue oldFaultFailureValue = faultFailureValue;
		faultFailureValue = newFaultFailureValue;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Eastadl22Package.FAULT_FAILURE__FAULT_FAILURE_VALUE, oldFaultFailureValue, newFaultFailureValue);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFaultFailureValue(EAValue newFaultFailureValue) {
		if (newFaultFailureValue != faultFailureValue) {
			NotificationChain msgs = null;
			if (faultFailureValue != null)
				msgs = ((InternalEObject)faultFailureValue).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - Eastadl22Package.FAULT_FAILURE__FAULT_FAILURE_VALUE, null, msgs);
			if (newFaultFailureValue != null)
				msgs = ((InternalEObject)newFaultFailureValue).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - Eastadl22Package.FAULT_FAILURE__FAULT_FAILURE_VALUE, null, msgs);
			msgs = basicSetFaultFailureValue(newFaultFailureValue, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FAULT_FAILURE__FAULT_FAILURE_VALUE, newFaultFailureValue, newFaultFailureValue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.FAULT_FAILURE__ANOMALY:
				return basicSetAnomaly(null, msgs);
			case Eastadl22Package.FAULT_FAILURE__FAULT_FAILURE_VALUE:
				return basicSetFaultFailureValue(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.FAULT_FAILURE__ANOMALY:
				return getAnomaly();
			case Eastadl22Package.FAULT_FAILURE__FAULT_FAILURE_VALUE:
				return getFaultFailureValue();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.FAULT_FAILURE__ANOMALY:
   			setAnomaly((FaultFailure_anomaly)newValue);
				return;
			case Eastadl22Package.FAULT_FAILURE__FAULT_FAILURE_VALUE:
   			setFaultFailureValue((EAValue)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FAULT_FAILURE__ANOMALY:
		    	setAnomaly((FaultFailure_anomaly)null);
				return;
			case Eastadl22Package.FAULT_FAILURE__FAULT_FAILURE_VALUE:
		    	setFaultFailureValue((EAValue)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FAULT_FAILURE__ANOMALY:
				return anomaly != null;
			case Eastadl22Package.FAULT_FAILURE__FAULT_FAILURE_VALUE:
				return faultFailureValue != null;
		}
		return super.eIsSet(featureID);
	}

} //FaultFailureImpl
