/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.FunctionPrototype;
import org.eclipse.eatop.eastadl22.NonConcurrentConstraint_exclusive;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eclipse.sphinx.emf.ecore.ExtendedEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Non Concurrent Constraint exclusive</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.NonConcurrentConstraint_exclusiveImpl#getNameWasNotSet_0 <em>Name Was Not Set 0</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.NonConcurrentConstraint_exclusiveImpl#getNameWasNotSet_1 <em>Name Was Not Set 1</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class NonConcurrentConstraint_exclusiveImpl extends ExtendedEObjectImpl implements NonConcurrentConstraint_exclusive {
	/**
	 * The cached value of the '{@link #getNameWasNotSet_0() <em>Name Was Not Set 0</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNameWasNotSet_0()
	 * @generated
	 * @ordered
	 */
	protected FunctionPrototype nameWasNotSet_0;

	/**
	 * The cached value of the '{@link #getNameWasNotSet_1() <em>Name Was Not Set 1</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNameWasNotSet_1()
	 * @generated
	 * @ordered
	 */
	protected EList<FunctionPrototype> nameWasNotSet_1;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NonConcurrentConstraint_exclusiveImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getNonConcurrentConstraint_exclusive();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionPrototype getNameWasNotSet_0() {
		if (nameWasNotSet_0 != null && nameWasNotSet_0.eIsProxy()) {
			InternalEObject oldNameWasNotSet_0 = (InternalEObject)nameWasNotSet_0;
			nameWasNotSet_0 = (FunctionPrototype)eResolveProxy(oldNameWasNotSet_0);
			if (nameWasNotSet_0 != oldNameWasNotSet_0) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_0, oldNameWasNotSet_0, nameWasNotSet_0));
			}
		}
		return nameWasNotSet_0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionPrototype basicGetNameWasNotSet_0() {
		return nameWasNotSet_0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNameWasNotSet_0(FunctionPrototype newNameWasNotSet_0) {
		FunctionPrototype oldNameWasNotSet_0 = nameWasNotSet_0;
		nameWasNotSet_0 = newNameWasNotSet_0;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_0, oldNameWasNotSet_0, nameWasNotSet_0));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FunctionPrototype> getNameWasNotSet_1() {
		if (nameWasNotSet_1 == null) {
			nameWasNotSet_1 = new EObjectResolvingEList<FunctionPrototype>(FunctionPrototype.class, this, Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_1);
		}
		return nameWasNotSet_1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_0:
				if (resolve) return getNameWasNotSet_0();
				return basicGetNameWasNotSet_0();
			case Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_1:
				return getNameWasNotSet_1();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_0:
   			setNameWasNotSet_0((FunctionPrototype)newValue);
				return;
			case Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_1:
				getNameWasNotSet_1().clear();
				getNameWasNotSet_1().addAll((Collection<? extends FunctionPrototype>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_0:
		    	setNameWasNotSet_0((FunctionPrototype)null);
				return;
			case Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_1:
				getNameWasNotSet_1().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_0:
				return nameWasNotSet_0 != null;
			case Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE__NAME_WAS_NOT_SET_1:
				return nameWasNotSet_1 != null && !nameWasNotSet_1.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //NonConcurrentConstraint_exclusiveImpl
