/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.ASILKind;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.HazardousEvent;
import org.eclipse.eatop.eastadl22.Mode;
import org.eclipse.eatop.eastadl22.Requirement;
import org.eclipse.eatop.eastadl22.SafetyGoal;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Safety Goal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.SafetyGoalImpl#getHazardClassification <em>Hazard Classification</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.SafetyGoalImpl#getDerivedFrom <em>Derived From</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.SafetyGoalImpl#getRequirement <em>Requirement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.SafetyGoalImpl#getSafeState <em>Safe State</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SafetyGoalImpl extends EAElementImpl implements SafetyGoal {
	/**
	 * The default value of the '{@link #getHazardClassification() <em>Hazard Classification</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHazardClassification()
	 * @generated
	 * @ordered
	 */
	protected static final ASILKind HAZARD_CLASSIFICATION_EDEFAULT = ASILKind.ASIL_A;

	/**
	 * The cached value of the '{@link #getHazardClassification() <em>Hazard Classification</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHazardClassification()
	 * @generated
	 * @ordered
	 */
	protected ASILKind hazardClassification = HAZARD_CLASSIFICATION_EDEFAULT;

	/**
	 * This is true if the Hazard Classification attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean hazardClassificationESet;

	/**
	 * The cached value of the '{@link #getDerivedFrom() <em>Derived From</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDerivedFrom()
	 * @generated
	 * @ordered
	 */
	protected EList<HazardousEvent> derivedFrom;

	/**
	 * The cached value of the '{@link #getRequirement() <em>Requirement</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequirement()
	 * @generated
	 * @ordered
	 */
	protected EList<Requirement> requirement;

	/**
	 * The cached value of the '{@link #getSafeState() <em>Safe State</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSafeState()
	 * @generated
	 * @ordered
	 */
	protected EList<Mode> safeState;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SafetyGoalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getSafetyGoal();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ASILKind getHazardClassification() {
		return hazardClassification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHazardClassification(ASILKind newHazardClassification) {
		ASILKind oldHazardClassification = hazardClassification;
		hazardClassification = newHazardClassification == null ? HAZARD_CLASSIFICATION_EDEFAULT : newHazardClassification;
		boolean oldHazardClassificationESet = hazardClassificationESet;
		hazardClassificationESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.SAFETY_GOAL__HAZARD_CLASSIFICATION, oldHazardClassification, hazardClassification, !oldHazardClassificationESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetHazardClassification() {
		ASILKind oldHazardClassification = hazardClassification;
		boolean oldHazardClassificationESet = hazardClassificationESet;
		hazardClassification = HAZARD_CLASSIFICATION_EDEFAULT;
		hazardClassificationESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.SAFETY_GOAL__HAZARD_CLASSIFICATION, oldHazardClassification, HAZARD_CLASSIFICATION_EDEFAULT, oldHazardClassificationESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetHazardClassification() {
		return hazardClassificationESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<HazardousEvent> getDerivedFrom() {
		if (derivedFrom == null) {
			derivedFrom = new EObjectResolvingEList<HazardousEvent>(HazardousEvent.class, this, Eastadl22Package.SAFETY_GOAL__DERIVED_FROM);
		}
		return derivedFrom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Requirement> getRequirement() {
		if (requirement == null) {
			requirement = new EObjectResolvingEList<Requirement>(Requirement.class, this, Eastadl22Package.SAFETY_GOAL__REQUIREMENT);
		}
		return requirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Mode> getSafeState() {
		if (safeState == null) {
			safeState = new EObjectResolvingEList<Mode>(Mode.class, this, Eastadl22Package.SAFETY_GOAL__SAFE_STATE);
		}
		return safeState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.SAFETY_GOAL__HAZARD_CLASSIFICATION:
				return getHazardClassification();
			case Eastadl22Package.SAFETY_GOAL__DERIVED_FROM:
				return getDerivedFrom();
			case Eastadl22Package.SAFETY_GOAL__REQUIREMENT:
				return getRequirement();
			case Eastadl22Package.SAFETY_GOAL__SAFE_STATE:
				return getSafeState();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.SAFETY_GOAL__HAZARD_CLASSIFICATION:
   			setHazardClassification((ASILKind)newValue);
				return;
			case Eastadl22Package.SAFETY_GOAL__DERIVED_FROM:
				getDerivedFrom().clear();
				getDerivedFrom().addAll((Collection<? extends HazardousEvent>)newValue);
				return;
			case Eastadl22Package.SAFETY_GOAL__REQUIREMENT:
				getRequirement().clear();
				getRequirement().addAll((Collection<? extends Requirement>)newValue);
				return;
			case Eastadl22Package.SAFETY_GOAL__SAFE_STATE:
				getSafeState().clear();
				getSafeState().addAll((Collection<? extends Mode>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.SAFETY_GOAL__HAZARD_CLASSIFICATION:
				unsetHazardClassification();
				return;
			case Eastadl22Package.SAFETY_GOAL__DERIVED_FROM:
				getDerivedFrom().clear();
				return;
			case Eastadl22Package.SAFETY_GOAL__REQUIREMENT:
				getRequirement().clear();
				return;
			case Eastadl22Package.SAFETY_GOAL__SAFE_STATE:
				getSafeState().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.SAFETY_GOAL__HAZARD_CLASSIFICATION:
				return isSetHazardClassification();
			case Eastadl22Package.SAFETY_GOAL__DERIVED_FROM:
				return derivedFrom != null && !derivedFrom.isEmpty();
			case Eastadl22Package.SAFETY_GOAL__REQUIREMENT:
				return requirement != null && !requirement.isEmpty();
			case Eastadl22Package.SAFETY_GOAL__SAFE_STATE:
				return safeState != null && !safeState.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (hazardClassification: ");
		if (hazardClassificationESet) result.append(hazardClassification); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //SafetyGoalImpl
