/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.ArchitecturalDescription;
import org.eclipse.eatop.eastadl22.ArchitecturalModel;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.Stakeholder;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Architectural Description</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ArchitecturalDescriptionImpl#getIdentifies <em>Identifies</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ArchitecturalDescriptionImpl#getAggregates <em>Aggregates</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ArchitecturalDescriptionImpl extends ConceptImpl implements ArchitecturalDescription {
	/**
	 * The cached value of the '{@link #getIdentifies() <em>Identifies</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdentifies()
	 * @generated
	 * @ordered
	 */
	protected EList<Stakeholder> identifies;

	/**
	 * The cached value of the '{@link #getAggregates() <em>Aggregates</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregates()
	 * @generated
	 * @ordered
	 */
	protected EList<ArchitecturalModel> aggregates;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArchitecturalDescriptionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getArchitecturalDescription();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Stakeholder> getIdentifies() {
		if (identifies == null) {
			identifies = new EObjectResolvingEList<Stakeholder>(Stakeholder.class, this, Eastadl22Package.ARCHITECTURAL_DESCRIPTION__IDENTIFIES);
		}
		return identifies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ArchitecturalModel> getAggregates() {
		if (aggregates == null) {
			aggregates = new EObjectContainmentEList<ArchitecturalModel>(ArchitecturalModel.class, this, Eastadl22Package.ARCHITECTURAL_DESCRIPTION__AGGREGATES);
		}
		return aggregates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION__AGGREGATES:
				return ((InternalEList<?>)getAggregates()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION__IDENTIFIES:
				return getIdentifies();
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION__AGGREGATES:
				return getAggregates();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION__IDENTIFIES:
				getIdentifies().clear();
				getIdentifies().addAll((Collection<? extends Stakeholder>)newValue);
				return;
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION__AGGREGATES:
				getAggregates().clear();
				getAggregates().addAll((Collection<? extends ArchitecturalModel>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION__IDENTIFIES:
				getIdentifies().clear();
				return;
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION__AGGREGATES:
				getAggregates().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION__IDENTIFIES:
				return identifies != null && !identifies.isEmpty();
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION__AGGREGATES:
				return aggregates != null && !aggregates.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ArchitecturalDescriptionImpl
