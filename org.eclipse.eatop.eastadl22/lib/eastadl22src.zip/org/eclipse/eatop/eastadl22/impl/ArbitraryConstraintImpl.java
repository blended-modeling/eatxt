/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.ArbitraryConstraint;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.Event;
import org.eclipse.eatop.eastadl22.TimingExpression;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arbitrary Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ArbitraryConstraintImpl#getMinimum <em>Minimum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ArbitraryConstraintImpl#getMaximum <em>Maximum</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ArbitraryConstraintImpl#getEvent <em>Event</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ArbitraryConstraintImpl extends TimingConstraintImpl implements ArbitraryConstraint {
	/**
	 * The cached value of the '{@link #getMinimum() <em>Minimum</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMinimum()
	 * @generated
	 * @ordered
	 */
	protected EList<TimingExpression> minimum;

	/**
	 * The cached value of the '{@link #getMaximum() <em>Maximum</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaximum()
	 * @generated
	 * @ordered
	 */
	protected EList<TimingExpression> maximum;

	/**
	 * The cached value of the '{@link #getEvent() <em>Event</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEvent()
	 * @generated
	 * @ordered
	 */
	protected Event event;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArbitraryConstraintImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getArbitraryConstraint();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TimingExpression> getMinimum() {
		if (minimum == null) {
			minimum = new EObjectContainmentEList<TimingExpression>(TimingExpression.class, this, Eastadl22Package.ARBITRARY_CONSTRAINT__MINIMUM);
		}
		return minimum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TimingExpression> getMaximum() {
		if (maximum == null) {
			maximum = new EObjectContainmentEList<TimingExpression>(TimingExpression.class, this, Eastadl22Package.ARBITRARY_CONSTRAINT__MAXIMUM);
		}
		return maximum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Event getEvent() {
		if (event != null && event.eIsProxy()) {
			InternalEObject oldEvent = (InternalEObject)event;
			event = (Event)eResolveProxy(oldEvent);
			if (event != oldEvent) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.ARBITRARY_CONSTRAINT__EVENT, oldEvent, event));
			}
		}
		return event;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Event basicGetEvent() {
		return event;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEvent(Event newEvent) {
		Event oldEvent = event;
		event = newEvent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.ARBITRARY_CONSTRAINT__EVENT, oldEvent, event));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MINIMUM:
				return ((InternalEList<?>)getMinimum()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MAXIMUM:
				return ((InternalEList<?>)getMaximum()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MINIMUM:
				return getMinimum();
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MAXIMUM:
				return getMaximum();
			case Eastadl22Package.ARBITRARY_CONSTRAINT__EVENT:
				if (resolve) return getEvent();
				return basicGetEvent();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MINIMUM:
				getMinimum().clear();
				getMinimum().addAll((Collection<? extends TimingExpression>)newValue);
				return;
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MAXIMUM:
				getMaximum().clear();
				getMaximum().addAll((Collection<? extends TimingExpression>)newValue);
				return;
			case Eastadl22Package.ARBITRARY_CONSTRAINT__EVENT:
   			setEvent((Event)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MINIMUM:
				getMinimum().clear();
				return;
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MAXIMUM:
				getMaximum().clear();
				return;
			case Eastadl22Package.ARBITRARY_CONSTRAINT__EVENT:
		    	setEvent((Event)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MINIMUM:
				return minimum != null && !minimum.isEmpty();
			case Eastadl22Package.ARBITRARY_CONSTRAINT__MAXIMUM:
				return maximum != null && !maximum.isEmpty();
			case Eastadl22Package.ARBITRARY_CONSTRAINT__EVENT:
				return event != null;
		}
		return super.eIsSet(featureID);
	}

} //ArbitraryConstraintImpl
