/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.FunctionPort;
import org.eclipse.eatop.eastadl22.LogicalEvent;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Logical Event</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.LogicalEventImpl#getIsExternVisible <em>Is Extern Visible</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.LogicalEventImpl#getVisibleThroughFunctionPort <em>Visible Through Function Port</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class LogicalEventImpl extends QuantificationImpl implements LogicalEvent {
	/**
	 * The default value of the '{@link #getIsExternVisible() <em>Is Extern Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsExternVisible()
	 * @generated
	 * @ordered
	 */
	protected static final Boolean IS_EXTERN_VISIBLE_EDEFAULT = Boolean.FALSE;

	/**
	 * The cached value of the '{@link #getIsExternVisible() <em>Is Extern Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsExternVisible()
	 * @generated
	 * @ordered
	 */
	protected Boolean isExternVisible = IS_EXTERN_VISIBLE_EDEFAULT;

	/**
	 * This is true if the Is Extern Visible attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean isExternVisibleESet;

	/**
	 * The cached value of the '{@link #getVisibleThroughFunctionPort() <em>Visible Through Function Port</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVisibleThroughFunctionPort()
	 * @generated
	 * @ordered
	 */
	protected EList<FunctionPort> visibleThroughFunctionPort;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LogicalEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getLogicalEvent();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsExternVisible() {
		return isExternVisible;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsExternVisible(Boolean newIsExternVisible) {
		Boolean oldIsExternVisible = isExternVisible;
		isExternVisible = newIsExternVisible;
		boolean oldIsExternVisibleESet = isExternVisibleESet;
		isExternVisibleESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.LOGICAL_EVENT__IS_EXTERN_VISIBLE, oldIsExternVisible, isExternVisible, !oldIsExternVisibleESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsExternVisible() {
		Boolean oldIsExternVisible = isExternVisible;
		boolean oldIsExternVisibleESet = isExternVisibleESet;
		isExternVisible = IS_EXTERN_VISIBLE_EDEFAULT;
		isExternVisibleESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.LOGICAL_EVENT__IS_EXTERN_VISIBLE, oldIsExternVisible, IS_EXTERN_VISIBLE_EDEFAULT, oldIsExternVisibleESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsExternVisible() {
		return isExternVisibleESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FunctionPort> getVisibleThroughFunctionPort() {
		if (visibleThroughFunctionPort == null) {
			visibleThroughFunctionPort = new EObjectResolvingEList<FunctionPort>(FunctionPort.class, this, Eastadl22Package.LOGICAL_EVENT__VISIBLE_THROUGH_FUNCTION_PORT);
		}
		return visibleThroughFunctionPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.LOGICAL_EVENT__IS_EXTERN_VISIBLE:
				return getIsExternVisible();
			case Eastadl22Package.LOGICAL_EVENT__VISIBLE_THROUGH_FUNCTION_PORT:
				return getVisibleThroughFunctionPort();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.LOGICAL_EVENT__IS_EXTERN_VISIBLE:
   			setIsExternVisible((Boolean)newValue);
				return;
			case Eastadl22Package.LOGICAL_EVENT__VISIBLE_THROUGH_FUNCTION_PORT:
				getVisibleThroughFunctionPort().clear();
				getVisibleThroughFunctionPort().addAll((Collection<? extends FunctionPort>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.LOGICAL_EVENT__IS_EXTERN_VISIBLE:
				unsetIsExternVisible();
				return;
			case Eastadl22Package.LOGICAL_EVENT__VISIBLE_THROUGH_FUNCTION_PORT:
				getVisibleThroughFunctionPort().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.LOGICAL_EVENT__IS_EXTERN_VISIBLE:
				return isSetIsExternVisible();
			case Eastadl22Package.LOGICAL_EVENT__VISIBLE_THROUGH_FUNCTION_PORT:
				return visibleThroughFunctionPort != null && !visibleThroughFunctionPort.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (isExternVisible: ");
		if (isExternVisibleESet) result.append(isExternVisible); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //LogicalEventImpl
