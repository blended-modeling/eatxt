/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.ASILKind;
import org.eclipse.eatop.eastadl22.ControllabilityClassKind;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.ExposureClassKind;
import org.eclipse.eatop.eastadl22.Hazard;
import org.eclipse.eatop.eastadl22.HazardousEvent;
import org.eclipse.eatop.eastadl22.Mode;
import org.eclipse.eatop.eastadl22.RequirementsRelationship;
import org.eclipse.eatop.eastadl22.SeverityClassKind;
import org.eclipse.eatop.eastadl22.Situation;
import org.eclipse.eatop.eastadl22.UseCase;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Hazardous Event</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getClassificationAssumptions <em>Classification Assumptions</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getControllability <em>Controllability</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getExposure <em>Exposure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getHazardClassification <em>Hazard Classification</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getSeverity <em>Severity</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getHazard <em>Hazard</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getUseCase <em>Use Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getEnvironment <em>Environment</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getTraffic <em>Traffic</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getExternalMeasures <em>External Measures</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.HazardousEventImpl#getOperatingMode <em>Operating Mode</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class HazardousEventImpl extends TraceableSpecificationImpl implements HazardousEvent {
	/**
	 * The default value of the '{@link #getClassificationAssumptions() <em>Classification Assumptions</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClassificationAssumptions()
	 * @generated
	 * @ordered
	 */
	protected static final String CLASSIFICATION_ASSUMPTIONS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getClassificationAssumptions() <em>Classification Assumptions</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClassificationAssumptions()
	 * @generated
	 * @ordered
	 */
	protected String classificationAssumptions = CLASSIFICATION_ASSUMPTIONS_EDEFAULT;

	/**
	 * This is true if the Classification Assumptions attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean classificationAssumptionsESet;

	/**
	 * The default value of the '{@link #getControllability() <em>Controllability</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControllability()
	 * @generated
	 * @ordered
	 */
	protected static final ControllabilityClassKind CONTROLLABILITY_EDEFAULT = ControllabilityClassKind.C0;

	/**
	 * The cached value of the '{@link #getControllability() <em>Controllability</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControllability()
	 * @generated
	 * @ordered
	 */
	protected ControllabilityClassKind controllability = CONTROLLABILITY_EDEFAULT;

	/**
	 * This is true if the Controllability attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean controllabilityESet;

	/**
	 * The default value of the '{@link #getExposure() <em>Exposure</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExposure()
	 * @generated
	 * @ordered
	 */
	protected static final ExposureClassKind EXPOSURE_EDEFAULT = ExposureClassKind.E1;

	/**
	 * The cached value of the '{@link #getExposure() <em>Exposure</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExposure()
	 * @generated
	 * @ordered
	 */
	protected ExposureClassKind exposure = EXPOSURE_EDEFAULT;

	/**
	 * This is true if the Exposure attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean exposureESet;

	/**
	 * The default value of the '{@link #getHazardClassification() <em>Hazard Classification</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHazardClassification()
	 * @generated
	 * @ordered
	 */
	protected static final ASILKind HAZARD_CLASSIFICATION_EDEFAULT = ASILKind.ASIL_A;

	/**
	 * The cached value of the '{@link #getHazardClassification() <em>Hazard Classification</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHazardClassification()
	 * @generated
	 * @ordered
	 */
	protected ASILKind hazardClassification = HAZARD_CLASSIFICATION_EDEFAULT;

	/**
	 * This is true if the Hazard Classification attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean hazardClassificationESet;

	/**
	 * The default value of the '{@link #getSeverity() <em>Severity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSeverity()
	 * @generated
	 * @ordered
	 */
	protected static final SeverityClassKind SEVERITY_EDEFAULT = SeverityClassKind.S0;

	/**
	 * The cached value of the '{@link #getSeverity() <em>Severity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSeverity()
	 * @generated
	 * @ordered
	 */
	protected SeverityClassKind severity = SEVERITY_EDEFAULT;

	/**
	 * This is true if the Severity attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean severityESet;

	/**
	 * The cached value of the '{@link #getHazard() <em>Hazard</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHazard()
	 * @generated
	 * @ordered
	 */
	protected EList<Hazard> hazard;

	/**
	 * The cached value of the '{@link #getUseCase() <em>Use Case</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUseCase()
	 * @generated
	 * @ordered
	 */
	protected EList<UseCase> useCase;

	/**
	 * The cached value of the '{@link #getEnvironment() <em>Environment</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnvironment()
	 * @generated
	 * @ordered
	 */
	protected EList<Situation> environment;

	/**
	 * The cached value of the '{@link #getTraffic() <em>Traffic</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTraffic()
	 * @generated
	 * @ordered
	 */
	protected EList<Situation> traffic;

	/**
	 * The cached value of the '{@link #getExternalMeasures() <em>External Measures</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExternalMeasures()
	 * @generated
	 * @ordered
	 */
	protected EList<RequirementsRelationship> externalMeasures;

	/**
	 * The cached value of the '{@link #getOperatingMode() <em>Operating Mode</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperatingMode()
	 * @generated
	 * @ordered
	 */
	protected EList<Mode> operatingMode;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HazardousEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getHazardousEvent();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getClassificationAssumptions() {
		return classificationAssumptions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setClassificationAssumptions(String newClassificationAssumptions) {
		String oldClassificationAssumptions = classificationAssumptions;
		classificationAssumptions = newClassificationAssumptions;
		boolean oldClassificationAssumptionsESet = classificationAssumptionsESet;
		classificationAssumptionsESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.HAZARDOUS_EVENT__CLASSIFICATION_ASSUMPTIONS, oldClassificationAssumptions, classificationAssumptions, !oldClassificationAssumptionsESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetClassificationAssumptions() {
		String oldClassificationAssumptions = classificationAssumptions;
		boolean oldClassificationAssumptionsESet = classificationAssumptionsESet;
		classificationAssumptions = CLASSIFICATION_ASSUMPTIONS_EDEFAULT;
		classificationAssumptionsESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.HAZARDOUS_EVENT__CLASSIFICATION_ASSUMPTIONS, oldClassificationAssumptions, CLASSIFICATION_ASSUMPTIONS_EDEFAULT, oldClassificationAssumptionsESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetClassificationAssumptions() {
		return classificationAssumptionsESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ControllabilityClassKind getControllability() {
		return controllability;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setControllability(ControllabilityClassKind newControllability) {
		ControllabilityClassKind oldControllability = controllability;
		controllability = newControllability == null ? CONTROLLABILITY_EDEFAULT : newControllability;
		boolean oldControllabilityESet = controllabilityESet;
		controllabilityESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.HAZARDOUS_EVENT__CONTROLLABILITY, oldControllability, controllability, !oldControllabilityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetControllability() {
		ControllabilityClassKind oldControllability = controllability;
		boolean oldControllabilityESet = controllabilityESet;
		controllability = CONTROLLABILITY_EDEFAULT;
		controllabilityESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.HAZARDOUS_EVENT__CONTROLLABILITY, oldControllability, CONTROLLABILITY_EDEFAULT, oldControllabilityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetControllability() {
		return controllabilityESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExposureClassKind getExposure() {
		return exposure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExposure(ExposureClassKind newExposure) {
		ExposureClassKind oldExposure = exposure;
		exposure = newExposure == null ? EXPOSURE_EDEFAULT : newExposure;
		boolean oldExposureESet = exposureESet;
		exposureESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.HAZARDOUS_EVENT__EXPOSURE, oldExposure, exposure, !oldExposureESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetExposure() {
		ExposureClassKind oldExposure = exposure;
		boolean oldExposureESet = exposureESet;
		exposure = EXPOSURE_EDEFAULT;
		exposureESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.HAZARDOUS_EVENT__EXPOSURE, oldExposure, EXPOSURE_EDEFAULT, oldExposureESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetExposure() {
		return exposureESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ASILKind getHazardClassification() {
		return hazardClassification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHazardClassification(ASILKind newHazardClassification) {
		ASILKind oldHazardClassification = hazardClassification;
		hazardClassification = newHazardClassification == null ? HAZARD_CLASSIFICATION_EDEFAULT : newHazardClassification;
		boolean oldHazardClassificationESet = hazardClassificationESet;
		hazardClassificationESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.HAZARDOUS_EVENT__HAZARD_CLASSIFICATION, oldHazardClassification, hazardClassification, !oldHazardClassificationESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetHazardClassification() {
		ASILKind oldHazardClassification = hazardClassification;
		boolean oldHazardClassificationESet = hazardClassificationESet;
		hazardClassification = HAZARD_CLASSIFICATION_EDEFAULT;
		hazardClassificationESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.HAZARDOUS_EVENT__HAZARD_CLASSIFICATION, oldHazardClassification, HAZARD_CLASSIFICATION_EDEFAULT, oldHazardClassificationESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetHazardClassification() {
		return hazardClassificationESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SeverityClassKind getSeverity() {
		return severity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSeverity(SeverityClassKind newSeverity) {
		SeverityClassKind oldSeverity = severity;
		severity = newSeverity == null ? SEVERITY_EDEFAULT : newSeverity;
		boolean oldSeverityESet = severityESet;
		severityESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.HAZARDOUS_EVENT__SEVERITY, oldSeverity, severity, !oldSeverityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetSeverity() {
		SeverityClassKind oldSeverity = severity;
		boolean oldSeverityESet = severityESet;
		severity = SEVERITY_EDEFAULT;
		severityESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.HAZARDOUS_EVENT__SEVERITY, oldSeverity, SEVERITY_EDEFAULT, oldSeverityESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetSeverity() {
		return severityESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Hazard> getHazard() {
		if (hazard == null) {
			hazard = new EObjectResolvingEList<Hazard>(Hazard.class, this, Eastadl22Package.HAZARDOUS_EVENT__HAZARD);
		}
		return hazard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<UseCase> getUseCase() {
		if (useCase == null) {
			useCase = new EObjectResolvingEList<UseCase>(UseCase.class, this, Eastadl22Package.HAZARDOUS_EVENT__USE_CASE);
		}
		return useCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Situation> getEnvironment() {
		if (environment == null) {
			environment = new EObjectResolvingEList<Situation>(Situation.class, this, Eastadl22Package.HAZARDOUS_EVENT__ENVIRONMENT);
		}
		return environment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Situation> getTraffic() {
		if (traffic == null) {
			traffic = new EObjectResolvingEList<Situation>(Situation.class, this, Eastadl22Package.HAZARDOUS_EVENT__TRAFFIC);
		}
		return traffic;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RequirementsRelationship> getExternalMeasures() {
		if (externalMeasures == null) {
			externalMeasures = new EObjectResolvingEList<RequirementsRelationship>(RequirementsRelationship.class, this, Eastadl22Package.HAZARDOUS_EVENT__EXTERNAL_MEASURES);
		}
		return externalMeasures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Mode> getOperatingMode() {
		if (operatingMode == null) {
			operatingMode = new EObjectResolvingEList<Mode>(Mode.class, this, Eastadl22Package.HAZARDOUS_EVENT__OPERATING_MODE);
		}
		return operatingMode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.HAZARDOUS_EVENT__CLASSIFICATION_ASSUMPTIONS:
				return getClassificationAssumptions();
			case Eastadl22Package.HAZARDOUS_EVENT__CONTROLLABILITY:
				return getControllability();
			case Eastadl22Package.HAZARDOUS_EVENT__EXPOSURE:
				return getExposure();
			case Eastadl22Package.HAZARDOUS_EVENT__HAZARD_CLASSIFICATION:
				return getHazardClassification();
			case Eastadl22Package.HAZARDOUS_EVENT__SEVERITY:
				return getSeverity();
			case Eastadl22Package.HAZARDOUS_EVENT__HAZARD:
				return getHazard();
			case Eastadl22Package.HAZARDOUS_EVENT__USE_CASE:
				return getUseCase();
			case Eastadl22Package.HAZARDOUS_EVENT__ENVIRONMENT:
				return getEnvironment();
			case Eastadl22Package.HAZARDOUS_EVENT__TRAFFIC:
				return getTraffic();
			case Eastadl22Package.HAZARDOUS_EVENT__EXTERNAL_MEASURES:
				return getExternalMeasures();
			case Eastadl22Package.HAZARDOUS_EVENT__OPERATING_MODE:
				return getOperatingMode();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.HAZARDOUS_EVENT__CLASSIFICATION_ASSUMPTIONS:
   			setClassificationAssumptions((String)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__CONTROLLABILITY:
   			setControllability((ControllabilityClassKind)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__EXPOSURE:
   			setExposure((ExposureClassKind)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__HAZARD_CLASSIFICATION:
   			setHazardClassification((ASILKind)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__SEVERITY:
   			setSeverity((SeverityClassKind)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__HAZARD:
				getHazard().clear();
				getHazard().addAll((Collection<? extends Hazard>)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__USE_CASE:
				getUseCase().clear();
				getUseCase().addAll((Collection<? extends UseCase>)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__ENVIRONMENT:
				getEnvironment().clear();
				getEnvironment().addAll((Collection<? extends Situation>)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__TRAFFIC:
				getTraffic().clear();
				getTraffic().addAll((Collection<? extends Situation>)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__EXTERNAL_MEASURES:
				getExternalMeasures().clear();
				getExternalMeasures().addAll((Collection<? extends RequirementsRelationship>)newValue);
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__OPERATING_MODE:
				getOperatingMode().clear();
				getOperatingMode().addAll((Collection<? extends Mode>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.HAZARDOUS_EVENT__CLASSIFICATION_ASSUMPTIONS:
				unsetClassificationAssumptions();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__CONTROLLABILITY:
				unsetControllability();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__EXPOSURE:
				unsetExposure();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__HAZARD_CLASSIFICATION:
				unsetHazardClassification();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__SEVERITY:
				unsetSeverity();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__HAZARD:
				getHazard().clear();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__USE_CASE:
				getUseCase().clear();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__ENVIRONMENT:
				getEnvironment().clear();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__TRAFFIC:
				getTraffic().clear();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__EXTERNAL_MEASURES:
				getExternalMeasures().clear();
				return;
			case Eastadl22Package.HAZARDOUS_EVENT__OPERATING_MODE:
				getOperatingMode().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.HAZARDOUS_EVENT__CLASSIFICATION_ASSUMPTIONS:
				return isSetClassificationAssumptions();
			case Eastadl22Package.HAZARDOUS_EVENT__CONTROLLABILITY:
				return isSetControllability();
			case Eastadl22Package.HAZARDOUS_EVENT__EXPOSURE:
				return isSetExposure();
			case Eastadl22Package.HAZARDOUS_EVENT__HAZARD_CLASSIFICATION:
				return isSetHazardClassification();
			case Eastadl22Package.HAZARDOUS_EVENT__SEVERITY:
				return isSetSeverity();
			case Eastadl22Package.HAZARDOUS_EVENT__HAZARD:
				return hazard != null && !hazard.isEmpty();
			case Eastadl22Package.HAZARDOUS_EVENT__USE_CASE:
				return useCase != null && !useCase.isEmpty();
			case Eastadl22Package.HAZARDOUS_EVENT__ENVIRONMENT:
				return environment != null && !environment.isEmpty();
			case Eastadl22Package.HAZARDOUS_EVENT__TRAFFIC:
				return traffic != null && !traffic.isEmpty();
			case Eastadl22Package.HAZARDOUS_EVENT__EXTERNAL_MEASURES:
				return externalMeasures != null && !externalMeasures.isEmpty();
			case Eastadl22Package.HAZARDOUS_EVENT__OPERATING_MODE:
				return operatingMode != null && !operatingMode.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (classificationAssumptions: ");
		if (classificationAssumptionsESet) result.append(classificationAssumptions); else result.append("<unset>");
		result.append(", controllability: ");
		if (controllabilityESet) result.append(controllability); else result.append("<unset>");
		result.append(", exposure: ");
		if (exposureESet) result.append(exposure); else result.append("<unset>");
		result.append(", hazardClassification: ");
		if (hazardClassificationESet) result.append(hazardClassification); else result.append("<unset>");
		result.append(", severity: ");
		if (severityESet) result.append(severity); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //HazardousEventImpl
