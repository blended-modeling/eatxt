/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding;
import org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype;
import org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype_errorModelTarget;
import org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype_functionTarget;
import org.eclipse.eatop.eastadl22.BehaviorConstraintPrototype_hardwareComponentTarget;
import org.eclipse.eatop.eastadl22.BehaviorConstraintType;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.VehicleFeature;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Behavior Constraint Prototype</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintPrototypeImpl#getType <em>Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintPrototypeImpl#getInstantiationVariable <em>Instantiation Variable</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintPrototypeImpl#getTargetedVehicleFeatureElement <em>Targeted Vehicle Feature Element</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintPrototypeImpl#getErrorModelTarget <em>Error Model Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintPrototypeImpl#getFunctionTarget <em>Function Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintPrototypeImpl#getHardwareComponentTarget <em>Hardware Component Target</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BehaviorConstraintPrototypeImpl extends TraceableSpecificationImpl implements BehaviorConstraintPrototype {
	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected BehaviorConstraintType type;

	/**
	 * The cached value of the '{@link #getInstantiationVariable() <em>Instantiation Variable</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInstantiationVariable()
	 * @generated
	 * @ordered
	 */
	protected EList<BehaviorConstraintInternalBinding> instantiationVariable;

	/**
	 * The cached value of the '{@link #getTargetedVehicleFeatureElement() <em>Targeted Vehicle Feature Element</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTargetedVehicleFeatureElement()
	 * @generated
	 * @ordered
	 */
	protected EList<VehicleFeature> targetedVehicleFeatureElement;

	/**
	 * The cached value of the '{@link #getErrorModelTarget() <em>Error Model Target</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getErrorModelTarget()
	 * @generated
	 * @ordered
	 */
	protected EList<BehaviorConstraintPrototype_errorModelTarget> errorModelTarget;

	/**
	 * The cached value of the '{@link #getFunctionTarget() <em>Function Target</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionTarget()
	 * @generated
	 * @ordered
	 */
	protected EList<BehaviorConstraintPrototype_functionTarget> functionTarget;

	/**
	 * The cached value of the '{@link #getHardwareComponentTarget() <em>Hardware Component Target</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHardwareComponentTarget()
	 * @generated
	 * @ordered
	 */
	protected EList<BehaviorConstraintPrototype_hardwareComponentTarget> hardwareComponentTarget;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BehaviorConstraintPrototypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getBehaviorConstraintPrototype();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BehaviorConstraintType getType() {
		if (type != null && type.eIsProxy()) {
			InternalEObject oldType = (InternalEObject)type;
			type = (BehaviorConstraintType)eResolveProxy(oldType);
			if (type != oldType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TYPE, oldType, type));
			}
		}
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BehaviorConstraintType basicGetType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(BehaviorConstraintType newType) {
		BehaviorConstraintType oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<BehaviorConstraintInternalBinding> getInstantiationVariable() {
		if (instantiationVariable == null) {
			instantiationVariable = new EObjectResolvingEList<BehaviorConstraintInternalBinding>(BehaviorConstraintInternalBinding.class, this, Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__INSTANTIATION_VARIABLE);
		}
		return instantiationVariable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<VehicleFeature> getTargetedVehicleFeatureElement() {
		if (targetedVehicleFeatureElement == null) {
			targetedVehicleFeatureElement = new EObjectResolvingEList<VehicleFeature>(VehicleFeature.class, this, Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TARGETED_VEHICLE_FEATURE_ELEMENT);
		}
		return targetedVehicleFeatureElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<BehaviorConstraintPrototype_errorModelTarget> getErrorModelTarget() {
		if (errorModelTarget == null) {
			errorModelTarget = new EObjectContainmentEList<BehaviorConstraintPrototype_errorModelTarget>(BehaviorConstraintPrototype_errorModelTarget.class, this, Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__ERROR_MODEL_TARGET);
		}
		return errorModelTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<BehaviorConstraintPrototype_functionTarget> getFunctionTarget() {
		if (functionTarget == null) {
			functionTarget = new EObjectContainmentEList<BehaviorConstraintPrototype_functionTarget>(BehaviorConstraintPrototype_functionTarget.class, this, Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__FUNCTION_TARGET);
		}
		return functionTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<BehaviorConstraintPrototype_hardwareComponentTarget> getHardwareComponentTarget() {
		if (hardwareComponentTarget == null) {
			hardwareComponentTarget = new EObjectContainmentEList<BehaviorConstraintPrototype_hardwareComponentTarget>(BehaviorConstraintPrototype_hardwareComponentTarget.class, this, Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__HARDWARE_COMPONENT_TARGET);
		}
		return hardwareComponentTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__ERROR_MODEL_TARGET:
				return ((InternalEList<?>)getErrorModelTarget()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__FUNCTION_TARGET:
				return ((InternalEList<?>)getFunctionTarget()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__HARDWARE_COMPONENT_TARGET:
				return ((InternalEList<?>)getHardwareComponentTarget()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TYPE:
				if (resolve) return getType();
				return basicGetType();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__INSTANTIATION_VARIABLE:
				return getInstantiationVariable();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TARGETED_VEHICLE_FEATURE_ELEMENT:
				return getTargetedVehicleFeatureElement();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__ERROR_MODEL_TARGET:
				return getErrorModelTarget();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__FUNCTION_TARGET:
				return getFunctionTarget();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__HARDWARE_COMPONENT_TARGET:
				return getHardwareComponentTarget();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TYPE:
   			setType((BehaviorConstraintType)newValue);
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__INSTANTIATION_VARIABLE:
				getInstantiationVariable().clear();
				getInstantiationVariable().addAll((Collection<? extends BehaviorConstraintInternalBinding>)newValue);
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TARGETED_VEHICLE_FEATURE_ELEMENT:
				getTargetedVehicleFeatureElement().clear();
				getTargetedVehicleFeatureElement().addAll((Collection<? extends VehicleFeature>)newValue);
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__ERROR_MODEL_TARGET:
				getErrorModelTarget().clear();
				getErrorModelTarget().addAll((Collection<? extends BehaviorConstraintPrototype_errorModelTarget>)newValue);
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__FUNCTION_TARGET:
				getFunctionTarget().clear();
				getFunctionTarget().addAll((Collection<? extends BehaviorConstraintPrototype_functionTarget>)newValue);
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__HARDWARE_COMPONENT_TARGET:
				getHardwareComponentTarget().clear();
				getHardwareComponentTarget().addAll((Collection<? extends BehaviorConstraintPrototype_hardwareComponentTarget>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TYPE:
		    	setType((BehaviorConstraintType)null);
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__INSTANTIATION_VARIABLE:
				getInstantiationVariable().clear();
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TARGETED_VEHICLE_FEATURE_ELEMENT:
				getTargetedVehicleFeatureElement().clear();
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__ERROR_MODEL_TARGET:
				getErrorModelTarget().clear();
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__FUNCTION_TARGET:
				getFunctionTarget().clear();
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__HARDWARE_COMPONENT_TARGET:
				getHardwareComponentTarget().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TYPE:
				return type != null;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__INSTANTIATION_VARIABLE:
				return instantiationVariable != null && !instantiationVariable.isEmpty();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__TARGETED_VEHICLE_FEATURE_ELEMENT:
				return targetedVehicleFeatureElement != null && !targetedVehicleFeatureElement.isEmpty();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__ERROR_MODEL_TARGET:
				return errorModelTarget != null && !errorModelTarget.isEmpty();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__FUNCTION_TARGET:
				return functionTarget != null && !functionTarget.isEmpty();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE__HARDWARE_COMPONENT_TARGET:
				return hardwareComponentTarget != null && !hardwareComponentTarget.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //BehaviorConstraintPrototypeImpl
