/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.FeatureFlaw;
import org.eclipse.eatop.eastadl22.Item;
import org.eclipse.eatop.eastadl22.Requirement;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Feature Flaw</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FeatureFlawImpl#getItem <em>Item</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FeatureFlawImpl#getNonFulfilledRequirement <em>Non Fulfilled Requirement</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FeatureFlawImpl extends TraceableSpecificationImpl implements FeatureFlaw {
	/**
	 * The cached value of the '{@link #getItem() <em>Item</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getItem()
	 * @generated
	 * @ordered
	 */
	protected EList<Item> item;

	/**
	 * The cached value of the '{@link #getNonFulfilledRequirement() <em>Non Fulfilled Requirement</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNonFulfilledRequirement()
	 * @generated
	 * @ordered
	 */
	protected EList<Requirement> nonFulfilledRequirement;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FeatureFlawImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getFeatureFlaw();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Item> getItem() {
		if (item == null) {
			item = new EObjectResolvingEList<Item>(Item.class, this, Eastadl22Package.FEATURE_FLAW__ITEM);
		}
		return item;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Requirement> getNonFulfilledRequirement() {
		if (nonFulfilledRequirement == null) {
			nonFulfilledRequirement = new EObjectResolvingEList<Requirement>(Requirement.class, this, Eastadl22Package.FEATURE_FLAW__NON_FULFILLED_REQUIREMENT);
		}
		return nonFulfilledRequirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.FEATURE_FLAW__ITEM:
				return getItem();
			case Eastadl22Package.FEATURE_FLAW__NON_FULFILLED_REQUIREMENT:
				return getNonFulfilledRequirement();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.FEATURE_FLAW__ITEM:
				getItem().clear();
				getItem().addAll((Collection<? extends Item>)newValue);
				return;
			case Eastadl22Package.FEATURE_FLAW__NON_FULFILLED_REQUIREMENT:
				getNonFulfilledRequirement().clear();
				getNonFulfilledRequirement().addAll((Collection<? extends Requirement>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FEATURE_FLAW__ITEM:
				getItem().clear();
				return;
			case Eastadl22Package.FEATURE_FLAW__NON_FULFILLED_REQUIREMENT:
				getNonFulfilledRequirement().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FEATURE_FLAW__ITEM:
				return item != null && !item.isEmpty();
			case Eastadl22Package.FEATURE_FLAW__NON_FULFILLED_REQUIREMENT:
				return nonFulfilledRequirement != null && !nonFulfilledRequirement.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //FeatureFlawImpl
