/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.BehaviorConstraintBindingEvent;
import org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding;
import org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector;
import org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughHardwareConnector;
import org.eclipse.eatop.eastadl22.ClampConnector;
import org.eclipse.eatop.eastadl22.Eastadl22Package;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Behavior Constraint Binding Event</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintBindingEventImpl#getBindingThroughHardwareConnector <em>Binding Through Hardware Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintBindingEventImpl#getBindingThroughFunctionConnector <em>Binding Through Function Connector</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintBindingEventImpl#getBindingThroughClampConnector <em>Binding Through Clamp Connector</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BehaviorConstraintBindingEventImpl extends TransitionEventImpl implements BehaviorConstraintBindingEvent {
	/**
	 * The cached value of the '{@link #getBindingThroughHardwareConnector() <em>Binding Through Hardware Connector</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBindingThroughHardwareConnector()
	 * @generated
	 * @ordered
	 */
	protected EList<BehaviorConstraintInternalBinding_bindingThroughHardwareConnector> bindingThroughHardwareConnector;

	/**
	 * The cached value of the '{@link #getBindingThroughFunctionConnector() <em>Binding Through Function Connector</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBindingThroughFunctionConnector()
	 * @generated
	 * @ordered
	 */
	protected EList<BehaviorConstraintInternalBinding_bindingThroughFunctionConnector> bindingThroughFunctionConnector;

	/**
	 * The cached value of the '{@link #getBindingThroughClampConnector() <em>Binding Through Clamp Connector</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBindingThroughClampConnector()
	 * @generated
	 * @ordered
	 */
	protected EList<ClampConnector> bindingThroughClampConnector;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BehaviorConstraintBindingEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getBehaviorConstraintBindingEvent();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<BehaviorConstraintInternalBinding_bindingThroughHardwareConnector> getBindingThroughHardwareConnector() {
		if (bindingThroughHardwareConnector == null) {
			bindingThroughHardwareConnector = new EObjectContainmentEList<BehaviorConstraintInternalBinding_bindingThroughHardwareConnector>(BehaviorConstraintInternalBinding_bindingThroughHardwareConnector.class, this, Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_HARDWARE_CONNECTOR);
		}
		return bindingThroughHardwareConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<BehaviorConstraintInternalBinding_bindingThroughFunctionConnector> getBindingThroughFunctionConnector() {
		if (bindingThroughFunctionConnector == null) {
			bindingThroughFunctionConnector = new EObjectContainmentEList<BehaviorConstraintInternalBinding_bindingThroughFunctionConnector>(BehaviorConstraintInternalBinding_bindingThroughFunctionConnector.class, this, Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_FUNCTION_CONNECTOR);
		}
		return bindingThroughFunctionConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ClampConnector> getBindingThroughClampConnector() {
		if (bindingThroughClampConnector == null) {
			bindingThroughClampConnector = new EObjectResolvingEList<ClampConnector>(ClampConnector.class, this, Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_CLAMP_CONNECTOR);
		}
		return bindingThroughClampConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_HARDWARE_CONNECTOR:
				return ((InternalEList<?>)getBindingThroughHardwareConnector()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_FUNCTION_CONNECTOR:
				return ((InternalEList<?>)getBindingThroughFunctionConnector()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_HARDWARE_CONNECTOR:
				return getBindingThroughHardwareConnector();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_FUNCTION_CONNECTOR:
				return getBindingThroughFunctionConnector();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_CLAMP_CONNECTOR:
				return getBindingThroughClampConnector();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_HARDWARE_CONNECTOR:
				getBindingThroughHardwareConnector().clear();
				getBindingThroughHardwareConnector().addAll((Collection<? extends BehaviorConstraintInternalBinding_bindingThroughHardwareConnector>)newValue);
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_FUNCTION_CONNECTOR:
				getBindingThroughFunctionConnector().clear();
				getBindingThroughFunctionConnector().addAll((Collection<? extends BehaviorConstraintInternalBinding_bindingThroughFunctionConnector>)newValue);
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_CLAMP_CONNECTOR:
				getBindingThroughClampConnector().clear();
				getBindingThroughClampConnector().addAll((Collection<? extends ClampConnector>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_HARDWARE_CONNECTOR:
				getBindingThroughHardwareConnector().clear();
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_FUNCTION_CONNECTOR:
				getBindingThroughFunctionConnector().clear();
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_CLAMP_CONNECTOR:
				getBindingThroughClampConnector().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_HARDWARE_CONNECTOR:
				return bindingThroughHardwareConnector != null && !bindingThroughHardwareConnector.isEmpty();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_FUNCTION_CONNECTOR:
				return bindingThroughFunctionConnector != null && !bindingThroughFunctionConnector.isEmpty();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_CLAMP_CONNECTOR:
				return bindingThroughClampConnector != null && !bindingThroughClampConnector.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == BehaviorConstraintInternalBinding.class) {
			switch (derivedFeatureID) {
				case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_HARDWARE_CONNECTOR: return Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING__BINDING_THROUGH_HARDWARE_CONNECTOR;
				case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_FUNCTION_CONNECTOR: return Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING__BINDING_THROUGH_FUNCTION_CONNECTOR;
				case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_CLAMP_CONNECTOR: return Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING__BINDING_THROUGH_CLAMP_CONNECTOR;
				default: return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == BehaviorConstraintInternalBinding.class) {
			switch (baseFeatureID) {
				case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING__BINDING_THROUGH_HARDWARE_CONNECTOR: return Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_HARDWARE_CONNECTOR;
				case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING__BINDING_THROUGH_FUNCTION_CONNECTOR: return Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_FUNCTION_CONNECTOR;
				case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING__BINDING_THROUGH_CLAMP_CONNECTOR: return Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT__BINDING_THROUGH_CLAMP_CONNECTOR;
				default: return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

} //BehaviorConstraintBindingEventImpl
