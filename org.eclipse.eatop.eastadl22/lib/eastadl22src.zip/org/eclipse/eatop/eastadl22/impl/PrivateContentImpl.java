/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.Identifiable;
import org.eclipse.eatop.eastadl22.PrivateContent;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Private Content</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.PrivateContentImpl#getPrivateElement <em>Private Element</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class PrivateContentImpl extends EAElementImpl implements PrivateContent {
	/**
	 * The cached value of the '{@link #getPrivateElement() <em>Private Element</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivateElement()
	 * @generated
	 * @ordered
	 */
	protected Identifiable privateElement;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PrivateContentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getPrivateContent();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Identifiable getPrivateElement() {
		if (privateElement != null && privateElement.eIsProxy()) {
			InternalEObject oldPrivateElement = (InternalEObject)privateElement;
			privateElement = (Identifiable)eResolveProxy(oldPrivateElement);
			if (privateElement != oldPrivateElement) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.PRIVATE_CONTENT__PRIVATE_ELEMENT, oldPrivateElement, privateElement));
			}
		}
		return privateElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Identifiable basicGetPrivateElement() {
		return privateElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrivateElement(Identifiable newPrivateElement) {
		Identifiable oldPrivateElement = privateElement;
		privateElement = newPrivateElement;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.PRIVATE_CONTENT__PRIVATE_ELEMENT, oldPrivateElement, privateElement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.PRIVATE_CONTENT__PRIVATE_ELEMENT:
				if (resolve) return getPrivateElement();
				return basicGetPrivateElement();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.PRIVATE_CONTENT__PRIVATE_ELEMENT:
   			setPrivateElement((Identifiable)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.PRIVATE_CONTENT__PRIVATE_ELEMENT:
		    	setPrivateElement((Identifiable)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.PRIVATE_CONTENT__PRIVATE_ELEMENT:
				return privateElement != null;
		}
		return super.eIsSet(featureID);
	}

} //PrivateContentImpl
