/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.Requirement;
import org.eclipse.eatop.eastadl22.RequirementsHierarchy;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Requirements Hierarchy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.RequirementsHierarchyImpl#getChildHierarchy <em>Child Hierarchy</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.RequirementsHierarchyImpl#getContainedRequirement <em>Contained Requirement</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RequirementsHierarchyImpl extends TraceableSpecificationImpl implements RequirementsHierarchy {
	/**
	 * The cached value of the '{@link #getChildHierarchy() <em>Child Hierarchy</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChildHierarchy()
	 * @generated
	 * @ordered
	 */
	protected EList<RequirementsHierarchy> childHierarchy;

	/**
	 * The cached value of the '{@link #getContainedRequirement() <em>Contained Requirement</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContainedRequirement()
	 * @generated
	 * @ordered
	 */
	protected EList<Requirement> containedRequirement;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RequirementsHierarchyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getRequirementsHierarchy();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RequirementsHierarchy> getChildHierarchy() {
		if (childHierarchy == null) {
			childHierarchy = new EObjectContainmentEList<RequirementsHierarchy>(RequirementsHierarchy.class, this, Eastadl22Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY);
		}
		return childHierarchy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Requirement> getContainedRequirement() {
		if (containedRequirement == null) {
			containedRequirement = new EObjectResolvingEList<Requirement>(Requirement.class, this, Eastadl22Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT);
		}
		return containedRequirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
				return ((InternalEList<?>)getChildHierarchy()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
				return getChildHierarchy();
			case Eastadl22Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT:
				return getContainedRequirement();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
				getChildHierarchy().clear();
				getChildHierarchy().addAll((Collection<? extends RequirementsHierarchy>)newValue);
				return;
			case Eastadl22Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT:
				getContainedRequirement().clear();
				getContainedRequirement().addAll((Collection<? extends Requirement>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
				getChildHierarchy().clear();
				return;
			case Eastadl22Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT:
				getContainedRequirement().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_HIERARCHY__CHILD_HIERARCHY:
				return childHierarchy != null && !childHierarchy.isEmpty();
			case Eastadl22Package.REQUIREMENTS_HIERARCHY__CONTAINED_REQUIREMENT:
				return containedRequirement != null && !containedRequirement.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //RequirementsHierarchyImpl
