/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Anomaly;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.ErrorModelPrototype;
import org.eclipse.eatop.eastadl22.FaultFailure_anomaly;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eclipse.sphinx.emf.ecore.ExtendedEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fault Failure anomaly</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FaultFailure_anomalyImpl#getErrorModelPrototype <em>Error Model Prototype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FaultFailure_anomalyImpl#getAnomaly <em>Anomaly</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FaultFailure_anomalyImpl extends ExtendedEObjectImpl implements FaultFailure_anomaly {
	/**
	 * The cached value of the '{@link #getErrorModelPrototype() <em>Error Model Prototype</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getErrorModelPrototype()
	 * @generated
	 * @ordered
	 */
	protected EList<ErrorModelPrototype> errorModelPrototype;

	/**
	 * The cached value of the '{@link #getAnomaly() <em>Anomaly</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnomaly()
	 * @generated
	 * @ordered
	 */
	protected Anomaly anomaly;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FaultFailure_anomalyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getFaultFailure_anomaly();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ErrorModelPrototype> getErrorModelPrototype() {
		if (errorModelPrototype == null) {
			errorModelPrototype = new EObjectResolvingEList<ErrorModelPrototype>(ErrorModelPrototype.class, this, Eastadl22Package.FAULT_FAILURE_ANOMALY__ERROR_MODEL_PROTOTYPE);
		}
		return errorModelPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Anomaly getAnomaly() {
		if (anomaly != null && anomaly.eIsProxy()) {
			InternalEObject oldAnomaly = (InternalEObject)anomaly;
			anomaly = (Anomaly)eResolveProxy(oldAnomaly);
			if (anomaly != oldAnomaly) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.FAULT_FAILURE_ANOMALY__ANOMALY, oldAnomaly, anomaly));
			}
		}
		return anomaly;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Anomaly basicGetAnomaly() {
		return anomaly;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAnomaly(Anomaly newAnomaly) {
		Anomaly oldAnomaly = anomaly;
		anomaly = newAnomaly;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FAULT_FAILURE_ANOMALY__ANOMALY, oldAnomaly, anomaly));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.FAULT_FAILURE_ANOMALY__ERROR_MODEL_PROTOTYPE:
				return getErrorModelPrototype();
			case Eastadl22Package.FAULT_FAILURE_ANOMALY__ANOMALY:
				if (resolve) return getAnomaly();
				return basicGetAnomaly();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.FAULT_FAILURE_ANOMALY__ERROR_MODEL_PROTOTYPE:
				getErrorModelPrototype().clear();
				getErrorModelPrototype().addAll((Collection<? extends ErrorModelPrototype>)newValue);
				return;
			case Eastadl22Package.FAULT_FAILURE_ANOMALY__ANOMALY:
   			setAnomaly((Anomaly)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FAULT_FAILURE_ANOMALY__ERROR_MODEL_PROTOTYPE:
				getErrorModelPrototype().clear();
				return;
			case Eastadl22Package.FAULT_FAILURE_ANOMALY__ANOMALY:
		    	setAnomaly((Anomaly)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FAULT_FAILURE_ANOMALY__ERROR_MODEL_PROTOTYPE:
				return errorModelPrototype != null && !errorModelPrototype.isEmpty();
			case Eastadl22Package.FAULT_FAILURE_ANOMALY__ANOMALY:
				return anomaly != null;
		}
		return super.eIsSet(featureID);
	}

} //FaultFailure_anomalyImpl
