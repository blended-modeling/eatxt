/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.EventFunction_function;
import org.eclipse.eatop.eastadl22.FunctionPrototype;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eclipse.sphinx.emf.ecore.ExtendedEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Function function</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.EventFunction_functionImpl#getFunctionPrototype_context <em>Function Prototype context</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.EventFunction_functionImpl#getFunctionPrototype_target <em>Function Prototype target</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EventFunction_functionImpl extends ExtendedEObjectImpl implements EventFunction_function {
	/**
	 * The cached value of the '{@link #getFunctionPrototype_context() <em>Function Prototype context</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionPrototype_context()
	 * @generated
	 * @ordered
	 */
	protected EList<FunctionPrototype> functionPrototype_context;

	/**
	 * The cached value of the '{@link #getFunctionPrototype_target() <em>Function Prototype target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionPrototype_target()
	 * @generated
	 * @ordered
	 */
	protected FunctionPrototype functionPrototype_target;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventFunction_functionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getEventFunction_function();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FunctionPrototype> getFunctionPrototype_context() {
		if (functionPrototype_context == null) {
			functionPrototype_context = new EObjectResolvingEList<FunctionPrototype>(FunctionPrototype.class, this, Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_CONTEXT);
		}
		return functionPrototype_context;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionPrototype getFunctionPrototype_target() {
		if (functionPrototype_target != null && functionPrototype_target.eIsProxy()) {
			InternalEObject oldFunctionPrototype_target = (InternalEObject)functionPrototype_target;
			functionPrototype_target = (FunctionPrototype)eResolveProxy(oldFunctionPrototype_target);
			if (functionPrototype_target != oldFunctionPrototype_target) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_TARGET, oldFunctionPrototype_target, functionPrototype_target));
			}
		}
		return functionPrototype_target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionPrototype basicGetFunctionPrototype_target() {
		return functionPrototype_target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFunctionPrototype_target(FunctionPrototype newFunctionPrototype_target) {
		FunctionPrototype oldFunctionPrototype_target = functionPrototype_target;
		functionPrototype_target = newFunctionPrototype_target;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_TARGET, oldFunctionPrototype_target, functionPrototype_target));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_CONTEXT:
				return getFunctionPrototype_context();
			case Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_TARGET:
				if (resolve) return getFunctionPrototype_target();
				return basicGetFunctionPrototype_target();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_CONTEXT:
				getFunctionPrototype_context().clear();
				getFunctionPrototype_context().addAll((Collection<? extends FunctionPrototype>)newValue);
				return;
			case Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_TARGET:
   			setFunctionPrototype_target((FunctionPrototype)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_CONTEXT:
				getFunctionPrototype_context().clear();
				return;
			case Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_TARGET:
		    	setFunctionPrototype_target((FunctionPrototype)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_CONTEXT:
				return functionPrototype_context != null && !functionPrototype_context.isEmpty();
			case Eastadl22Package.EVENT_FUNCTION_FUNCTION__FUNCTION_PROTOTYPE_TARGET:
				return functionPrototype_target != null;
		}
		return super.eIsSet(featureID);
	}

} //EventFunction_functionImpl
