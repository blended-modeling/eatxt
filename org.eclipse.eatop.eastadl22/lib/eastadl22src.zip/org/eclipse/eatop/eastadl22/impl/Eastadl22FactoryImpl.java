/**
 */
package org.eclipse.eatop.eastadl22.impl;

import org.eclipse.eatop.eastadl22.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Eastadl22FactoryImpl extends EFactoryImpl implements Eastadl22Factory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Eastadl22Factory init() {
		try {
			Eastadl22Factory theEastadl22Factory = (Eastadl22Factory)EPackage.Registry.INSTANCE.getEFactory(Eastadl22Package.eNS_URI);
			if (theEastadl22Factory != null) {
				return theEastadl22Factory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Eastadl22FactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Eastadl22FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case Eastadl22Package.VEHICLE_LEVEL: return createVehicleLevel();
			case Eastadl22Package.SYSTEM_MODEL: return createSystemModel();
			case Eastadl22Package.ANALYSIS_LEVEL: return createAnalysisLevel();
			case Eastadl22Package.DESIGN_LEVEL: return createDesignLevel();
			case Eastadl22Package.IMPLEMENTATION_LEVEL: return createImplementationLevel();
			case Eastadl22Package.FEATURE: return createFeature();
			case Eastadl22Package.FEATURE_CONSTRAINT: return createFeatureConstraint();
			case Eastadl22Package.FEATURE_GROUP: return createFeatureGroup();
			case Eastadl22Package.FEATURE_LINK: return createFeatureLink();
			case Eastadl22Package.FEATURE_MODEL: return createFeatureModel();
			case Eastadl22Package.DEVIATION_ATTRIBUTE_SET: return createDeviationAttributeSet();
			case Eastadl22Package.VEHICLE_FEATURE: return createVehicleFeature();
			case Eastadl22Package.ALLOCATION: return createAllocation();
			case Eastadl22Package.ANALYSIS_FUNCTION_PROTOTYPE: return createAnalysisFunctionPrototype();
			case Eastadl22Package.ANALYSIS_FUNCTION_TYPE: return createAnalysisFunctionType();
			case Eastadl22Package.BASIC_SOFTWARE_FUNCTION_TYPE: return createBasicSoftwareFunctionType();
			case Eastadl22Package.DESIGN_FUNCTION_PROTOTYPE: return createDesignFunctionPrototype();
			case Eastadl22Package.DESIGN_FUNCTION_TYPE: return createDesignFunctionType();
			case Eastadl22Package.FUNCTIONAL_DEVICE: return createFunctionalDevice();
			case Eastadl22Package.FUNCTION_ALLOCATION: return createFunctionAllocation();
			case Eastadl22Package.FUNCTION_CLIENT_SERVER_INTERFACE: return createFunctionClientServerInterface();
			case Eastadl22Package.FUNCTION_CLIENT_SERVER_PORT: return createFunctionClientServerPort();
			case Eastadl22Package.FUNCTION_CONNECTOR: return createFunctionConnector();
			case Eastadl22Package.FUNCTION_FLOW_PORT: return createFunctionFlowPort();
			case Eastadl22Package.FUNCTION_POWER_PORT: return createFunctionPowerPort();
			case Eastadl22Package.HARDWARE_FUNCTION_TYPE: return createHardwareFunctionType();
			case Eastadl22Package.LOCAL_DEVICE_MANAGER: return createLocalDeviceManager();
			case Eastadl22Package.OPERATION: return createOperation();
			case Eastadl22Package.PORT_GROUP: return createPortGroup();
			case Eastadl22Package.FUNCTION_ALLOCATION_ALLOCATED_ELEMENT: return createFunctionAllocation_allocatedElement();
			case Eastadl22Package.FUNCTION_ALLOCATION_TARGET: return createFunctionAllocation_target();
			case Eastadl22Package.FUNCTION_CONNECTOR_PORT: return createFunctionConnector_port();
			case Eastadl22Package.ACTUATOR: return createActuator();
			case Eastadl22Package.COMMUNICATION_HARDWARE_PIN: return createCommunicationHardwarePin();
			case Eastadl22Package.ELECTRICAL_COMPONENT: return createElectricalComponent();
			case Eastadl22Package.HARDWARE_COMPONENT_PROTOTYPE: return createHardwareComponentPrototype();
			case Eastadl22Package.HARDWARE_COMPONENT_TYPE: return createHardwareComponentType();
			case Eastadl22Package.HARDWARE_CONNECTOR: return createHardwareConnector();
			case Eastadl22Package.HARDWARE_PORT: return createHardwarePort();
			case Eastadl22Package.HARDWARE_PORT_CONNECTOR: return createHardwarePortConnector();
			case Eastadl22Package.IO_HARDWARE_PIN: return createIOHardwarePin();
			case Eastadl22Package.LOGICAL_PORT_CONNECTOR: return createLogicalPortConnector();
			case Eastadl22Package.NODE: return createNode();
			case Eastadl22Package.POWER_HARDWARE_PIN: return createPowerHardwarePin();
			case Eastadl22Package.SENSOR: return createSensor();
			case Eastadl22Package.HARDWARE_CONNECTOR_PORT: return createHardwareConnector_port();
			case Eastadl22Package.HARDWARE_PORT_CONNECTOR_PORT: return createHardwarePortConnector_port();
			case Eastadl22Package.CLAMP_CONNECTOR: return createClampConnector();
			case Eastadl22Package.ENVIRONMENT: return createEnvironment();
			case Eastadl22Package.CLAMP_CONNECTOR_PORT: return createClampConnector_port();
			case Eastadl22Package.BEHAVIOR: return createBehavior();
			case Eastadl22Package.MODE: return createMode();
			case Eastadl22Package.MODE_GROUP: return createModeGroup();
			case Eastadl22Package.FUNCTION_BEHAVIOR: return createFunctionBehavior();
			case Eastadl22Package.FUNCTION_TRIGGER: return createFunctionTrigger();
			case Eastadl22Package.CONFIGURABLE_CONTAINER: return createConfigurableContainer();
			case Eastadl22Package.CONFIGURATION_DECISION: return createConfigurationDecision();
			case Eastadl22Package.CONFIGURATION_DECISION_FOLDER: return createConfigurationDecisionFolder();
			case Eastadl22Package.CONTAINER_CONFIGURATION: return createContainerConfiguration();
			case Eastadl22Package.FEATURE_CONFIGURATION: return createFeatureConfiguration();
			case Eastadl22Package.INTERNAL_BINDING: return createInternalBinding();
			case Eastadl22Package.PRIVATE_CONTENT: return createPrivateContent();
			case Eastadl22Package.REUSE_META_INFORMATION: return createReuseMetaInformation();
			case Eastadl22Package.SELECTION_CRITERION: return createSelectionCriterion();
			case Eastadl22Package.VARIABILITY: return createVariability();
			case Eastadl22Package.VARIABLE_ELEMENT: return createVariableElement();
			case Eastadl22Package.VARIATION_GROUP: return createVariationGroup();
			case Eastadl22Package.VEHICLE_LEVEL_BINDING: return createVehicleLevelBinding();
			case Eastadl22Package.DERIVE_REQUIREMENT: return createDeriveRequirement();
			case Eastadl22Package.SITUATION: return createSituation();
			case Eastadl22Package.REQUIREMENTS_MODEL: return createRequirementsModel();
			case Eastadl22Package.REQUIREMENT: return createRequirement();
			case Eastadl22Package.REQUIREMENTS_HIERARCHY: return createRequirementsHierarchy();
			case Eastadl22Package.REFINE: return createRefine();
			case Eastadl22Package.SATISFY: return createSatisfy();
			case Eastadl22Package.REQUIREMENTS_LINK: return createRequirementsLink();
			case Eastadl22Package.REQUIREMENTS_RELATIONSHIP_GROUP: return createRequirementsRelationshipGroup();
			case Eastadl22Package.QUALITY_REQUIREMENT: return createQualityRequirement();
			case Eastadl22Package.REFINE_REFINED_BY: return createRefine_refinedBy();
			case Eastadl22Package.SATISFY_SATISFIED_BY: return createSatisfy_satisfiedBy();
			case Eastadl22Package.ACTOR: return createActor();
			case Eastadl22Package.EXTEND: return createExtend();
			case Eastadl22Package.EXTENSION_POINT: return createExtensionPoint();
			case Eastadl22Package.INCLUDE: return createInclude();
			case Eastadl22Package.INTERACT: return createInteract();
			case Eastadl22Package.USE_CASE: return createUseCase();
			case Eastadl22Package.VERIFICATION_VALIDATION: return createVerificationValidation();
			case Eastadl22Package.VERIFY: return createVerify();
			case Eastadl22Package.VV_ACTUAL_OUTCOME: return createVVActualOutcome();
			case Eastadl22Package.VV_CASE: return createVVCase();
			case Eastadl22Package.VV_INTENDED_OUTCOME: return createVVIntendedOutcome();
			case Eastadl22Package.VV_LOG: return createVVLog();
			case Eastadl22Package.VV_PROCEDURE: return createVVProcedure();
			case Eastadl22Package.VV_STIMULI: return createVVStimuli();
			case Eastadl22Package.VV_TARGET: return createVVTarget();
			case Eastadl22Package.VV_CASE_VV_SUBJECT: return createVVCase_vvSubject();
			case Eastadl22Package.VV_TARGET_ELEMENT: return createVVTarget_element();
			case Eastadl22Package.EVENT_CHAIN: return createEventChain();
			case Eastadl22Package.NON_CONCURRENCE_CONSTRAINT: return createNonConcurrenceConstraint();
			case Eastadl22Package.NON_PREEMPTIVE_CONSTRAINT: return createNonPreemptiveConstraint();
			case Eastadl22Package.PRECEDENCE_CONSTRAINT: return createPrecedenceConstraint();
			case Eastadl22Package.TIMING: return createTiming();
			case Eastadl22Package.TIMING_EXPRESSION: return createTimingExpression();
			case Eastadl22Package.AUTOSAR_EVENT: return createAUTOSAREvent();
			case Eastadl22Package.EVENT_FAULT_FAILURE: return createEventFaultFailure();
			case Eastadl22Package.EVENT_FEATURE_FLAW: return createEventFeatureFlaw();
			case Eastadl22Package.EVENT_FUNCTION: return createEventFunction();
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT: return createEventFunctionClientServerPort();
			case Eastadl22Package.EVENT_FUNCTION_FLOW_PORT: return createEventFunctionFlowPort();
			case Eastadl22Package.EXTERNAL_EVENT: return createExternalEvent();
			case Eastadl22Package.MODE_EVENT: return createModeEvent();
			case Eastadl22Package.EVENT_FUNCTION_FUNCTION: return createEventFunction_function();
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT: return createEventFunctionClientServerPort_port();
			case Eastadl22Package.EVENT_FUNCTION_FLOW_PORT_PORT: return createEventFunctionFlowPort_port();
			case Eastadl22Package.AGE_CONSTRAINT: return createAgeConstraint();
			case Eastadl22Package.ARBITRARY_CONSTRAINT: return createArbitraryConstraint();
			case Eastadl22Package.BURST_CONSTRAINT: return createBurstConstraint();
			case Eastadl22Package.COMPARISON_CONSTRAINT: return createComparisonConstraint();
			case Eastadl22Package.DELAY_CONSTRAINT: return createDelayConstraint();
			case Eastadl22Package.EXECUTION_TIME_CONSTRAINT: return createExecutionTimeConstraint();
			case Eastadl22Package.INPUT_SYNCHRONIZATION_CONSTRAINT: return createInputSynchronizationConstraint();
			case Eastadl22Package.ORDER_CONSTRAINT: return createOrderConstraint();
			case Eastadl22Package.OUTPUT_SYNCHRONIZATION_CONSTRAINT: return createOutputSynchronizationConstraint();
			case Eastadl22Package.PATTERN_CONSTRAINT: return createPatternConstraint();
			case Eastadl22Package.PERIODIC_CONSTRAINT: return createPeriodicConstraint();
			case Eastadl22Package.REACTION_CONSTRAINT: return createReactionConstraint();
			case Eastadl22Package.REPETITION_CONSTRAINT: return createRepetitionConstraint();
			case Eastadl22Package.SPORADIC_CONSTRAINT: return createSporadicConstraint();
			case Eastadl22Package.STRONG_DELAY_CONSTRAINT: return createStrongDelayConstraint();
			case Eastadl22Package.STRONG_SYNCHRONIZATION_CONSTRAINT: return createStrongSynchronizationConstraint();
			case Eastadl22Package.SYNCHRONIZATION_CONSTRAINT: return createSynchronizationConstraint();
			case Eastadl22Package.NON_CONCURRENT_CONSTRAINT_EXCLUSIVE: return createNonConcurrentConstraint_exclusive();
			case Eastadl22Package.DEPENDABILITY: return createDependability();
			case Eastadl22Package.FEATURE_FLAW: return createFeatureFlaw();
			case Eastadl22Package.HAZARD: return createHazard();
			case Eastadl22Package.HAZARDOUS_EVENT: return createHazardousEvent();
			case Eastadl22Package.ITEM: return createItem();
			case Eastadl22Package.FAULT_FAILURE: return createFaultFailure();
			case Eastadl22Package.QUANTITATIVE_SAFETY_CONSTRAINT: return createQuantitativeSafetyConstraint();
			case Eastadl22Package.SAFETY_CONSTRAINT: return createSafetyConstraint();
			case Eastadl22Package.FAULT_FAILURE_ANOMALY: return createFaultFailure_anomaly();
			case Eastadl22Package.ERROR_BEHAVIOR: return createErrorBehavior();
			case Eastadl22Package.ERROR_MODEL_PROTOTYPE: return createErrorModelPrototype();
			case Eastadl22Package.ERROR_MODEL_TYPE: return createErrorModelType();
			case Eastadl22Package.FAILURE_OUT_PORT: return createFailureOutPort();
			case Eastadl22Package.FAULT_FAILURE_PROPAGATION_LINK: return createFaultFailurePropagationLink();
			case Eastadl22Package.FAULT_IN_PORT: return createFaultInPort();
			case Eastadl22Package.INTERNAL_FAULT_PROTOTYPE: return createInternalFaultPrototype();
			case Eastadl22Package.PROCESS_FAULT_PROTOTYPE: return createProcessFaultPrototype();
			case Eastadl22Package.ERROR_MODEL_PROTOTYPE_FUNCTION_TARGET: return createErrorModelPrototype_functionTarget();
			case Eastadl22Package.ERROR_MODEL_PROTOTYPE_HW_TARGET: return createErrorModelPrototype_hwTarget();
			case Eastadl22Package.FAULT_FAILURE_PORT_FUNCTION_TARGET: return createFaultFailurePort_functionTarget();
			case Eastadl22Package.FAULT_FAILURE_PORT_HW_TARGET: return createFaultFailurePort_hwTarget();
			case Eastadl22Package.FAULT_FAILURE_PROPAGATION_LINK_FROM_PORT: return createFaultFailurePropagationLink_fromPort();
			case Eastadl22Package.FAULT_FAILURE_PROPAGATION_LINK_TO_PORT: return createFaultFailurePropagationLink_toPort();
			case Eastadl22Package.FUNCTIONAL_SAFETY_CONCEPT: return createFunctionalSafetyConcept();
			case Eastadl22Package.SAFETY_GOAL: return createSafetyGoal();
			case Eastadl22Package.TECHNICAL_SAFETY_CONCEPT: return createTechnicalSafetyConcept();
			case Eastadl22Package.CLAIM: return createClaim();
			case Eastadl22Package.GROUND: return createGround();
			case Eastadl22Package.SAFETY_CASE: return createSafetyCase();
			case Eastadl22Package.WARRANT: return createWarrant();
			case Eastadl22Package.GENERIC_CONSTRAINT: return createGenericConstraint();
			case Eastadl22Package.GENERIC_CONSTRAINT_SET: return createGenericConstraintSet();
			case Eastadl22Package.TAKE_RATE_CONSTRAINT: return createTakeRateConstraint();
			case Eastadl22Package.COMMENT: return createComment();
			case Eastadl22Package.EA_PACKAGE: return createEAPackage();
			case Eastadl22Package.EAXML: return createEAXML();
			case Eastadl22Package.RATIONALE: return createRationale();
			case Eastadl22Package.REALIZATION: return createRealization();
			case Eastadl22Package.REALIZATION_REALIZED: return createRealization_realized();
			case Eastadl22Package.REALIZATION_REALIZED_BY: return createRealization_realizedBy();
			case Eastadl22Package.ARRAY_DATATYPE: return createArrayDatatype();
			case Eastadl22Package.COMPOSITE_DATATYPE: return createCompositeDatatype();
			case Eastadl22Package.EA_BOOLEAN: return createEABoolean();
			case Eastadl22Package.EA_DATATYPE_PROTOTYPE: return createEADatatypePrototype();
			case Eastadl22Package.EA_NUMERICAL: return createEANumerical();
			case Eastadl22Package.EA_STRING: return createEAString();
			case Eastadl22Package.ENUMERATION: return createEnumeration();
			case Eastadl22Package.ENUMERATION_LITERAL: return createEnumerationLiteral();
			case Eastadl22Package.QUANTITY: return createQuantity();
			case Eastadl22Package.RANGEABLE_VALUE_TYPE: return createRangeableValueType();
			case Eastadl22Package.UNIT: return createUnit();
			case Eastadl22Package.EA_ARRAY_VALUE: return createEAArrayValue();
			case Eastadl22Package.EA_BOOLEAN_VALUE: return createEABooleanValue();
			case Eastadl22Package.EA_COMPOSITE_VALUE: return createEACompositeValue();
			case Eastadl22Package.EA_ENUMERATION_VALUE: return createEAEnumerationValue();
			case Eastadl22Package.EA_EXPRESSION: return createEAExpression();
			case Eastadl22Package.EA_NUMERICAL_VALUE: return createEANumericalValue();
			case Eastadl22Package.EA_STRING_VALUE: return createEAStringValue();
			case Eastadl22Package.USER_ATTRIBUTE_DEFINITION: return createUserAttributeDefinition();
			case Eastadl22Package.USER_ATTRIBUTED_ELEMENT: return createUserAttributedElement();
			case Eastadl22Package.USER_ELEMENT_TYPE: return createUserElementType();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_ATTRIBUTE: return createBehaviorConstraintBindingAttribute();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_BINDING_EVENT: return createBehaviorConstraintBindingEvent();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE: return createBehaviorConstraintPrototype();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_TARGET_BINDING: return createBehaviorConstraintTargetBinding();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_TYPE: return createBehaviorConstraintType();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR: return createBehaviorConstraintInternalBinding_bindingThroughFunctionConnector();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_HARDWARE_CONNECTOR: return createBehaviorConstraintInternalBinding_bindingThroughHardwareConnector();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_ERROR_MODEL_TARGET: return createBehaviorConstraintPrototype_errorModelTarget();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_FUNCTION_TARGET: return createBehaviorConstraintPrototype_functionTarget();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_PROTOTYPE_HARDWARE_COMPONENT_TARGET: return createBehaviorConstraintPrototype_hardwareComponentTarget();
			case Eastadl22Package.ATTRIBUTE: return createAttribute();
			case Eastadl22Package.ATTRIBUTE_QUANTIFICATION_CONSTRAINT: return createAttributeQuantificationConstraint();
			case Eastadl22Package.BEHAVIOR_ATTRIBUTE_BINDING: return createBehaviorAttributeBinding();
			case Eastadl22Package.LOGICAL_EVENT: return createLogicalEvent();
			case Eastadl22Package.QUANTIFICATION: return createQuantification();
			case Eastadl22Package.COMPUTATION_CONSTRAINT: return createComputationConstraint();
			case Eastadl22Package.LOGICAL_PATH: return createLogicalPath();
			case Eastadl22Package.LOGICAL_TRANSFORMATION: return createLogicalTransformation();
			case Eastadl22Package.TRANSFORMATION_OCCURRENCE: return createTransformationOccurrence();
			case Eastadl22Package.LOGICAL_TIME_CONDITION: return createLogicalTimeCondition();
			case Eastadl22Package.STATE: return createState();
			case Eastadl22Package.STATE_EVENT: return createStateEvent();
			case Eastadl22Package.SYNCHRONOUS_TRANSITION: return createSynchronousTransition();
			case Eastadl22Package.TEMPORAL_CONSTRAINT: return createTemporalConstraint();
			case Eastadl22Package.TRANSITION: return createTransition();
			case Eastadl22Package.TRANSITION_EVENT: return createTransitionEvent();
			case Eastadl22Package.ARCHITECTURAL_DESCRIPTION: return createArchitecturalDescription();
			case Eastadl22Package.ARCHITECTURAL_MODEL: return createArchitecturalModel();
			case Eastadl22Package.ARCHITECTURE: return createArchitecture();
			case Eastadl22Package.MISSION: return createMission();
			case Eastadl22Package.VEHICLE_SYSTEM: return createVehicleSystem();
			case Eastadl22Package.STAKEHOLDER: return createStakeholder();
			case Eastadl22Package.STAKEHOLDER_NEED: return createStakeholderNeed();
			case Eastadl22Package.BUSINESS_OPPORTUNITY: return createBusinessOpportunity();
			case Eastadl22Package.PROBLEM_STATEMENT: return createProblemStatement();
			case Eastadl22Package.PRODUCT_POSITIONING: return createProductPositioning();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case Eastadl22Package.BINDING_TIME_KIND:
				return createBindingTimeKindFromString(eDataType, initialValue);
			case Eastadl22Package.VARIABILITY_DEPENDENCY_KIND:
				return createVariabilityDependencyKindFromString(eDataType, initialValue);
			case Eastadl22Package.DEVIATION_PERMISSION_KIND:
				return createDeviationPermissionKindFromString(eDataType, initialValue);
			case Eastadl22Package.CLIENT_SERVER_KIND:
				return createClientServerKindFromString(eDataType, initialValue);
			case Eastadl22Package.EA_DIRECTION_KIND:
				return createEADirectionKindFromString(eDataType, initialValue);
			case Eastadl22Package.HARDWARE_BUS_KIND:
				return createHardwareBusKindFromString(eDataType, initialValue);
			case Eastadl22Package.IO_HARDWARE_PIN_KIND:
				return createIOHardwarePinKindFromString(eDataType, initialValue);
			case Eastadl22Package.FUNCTION_BEHAVIOR_KIND:
				return createFunctionBehaviorKindFromString(eDataType, initialValue);
			case Eastadl22Package.TRIGGER_POLICY_KIND:
				return createTriggerPolicyKindFromString(eDataType, initialValue);
			case Eastadl22Package.QUALITY_REQUIREMENT_KIND:
				return createQualityRequirementKindFromString(eDataType, initialValue);
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_KIND:
				return createEventFunctionClientServerPortKindFromString(eDataType, initialValue);
			case Eastadl22Package.EVENT_FUNCTION_KIND:
				return createEventFunctionKindFromString(eDataType, initialValue);
			case Eastadl22Package.COMPARISON_KIND:
				return createComparisonKindFromString(eDataType, initialValue);
			case Eastadl22Package.CONTROLLABILITY_CLASS_KIND:
				return createControllabilityClassKindFromString(eDataType, initialValue);
			case Eastadl22Package.DEVELOPMENT_CATEGORY_KIND:
				return createDevelopmentCategoryKindFromString(eDataType, initialValue);
			case Eastadl22Package.EXPOSURE_CLASS_KIND:
				return createExposureClassKindFromString(eDataType, initialValue);
			case Eastadl22Package.SEVERITY_CLASS_KIND:
				return createSeverityClassKindFromString(eDataType, initialValue);
			case Eastadl22Package.ASIL_KIND:
				return createASILKindFromString(eDataType, initialValue);
			case Eastadl22Package.ERROR_BEHAVIOR_KIND:
				return createErrorBehaviorKindFromString(eDataType, initialValue);
			case Eastadl22Package.LIFECYCLE_STAGE_KIND:
				return createLifecycleStageKindFromString(eDataType, initialValue);
			case Eastadl22Package.GENERIC_CONSTRAINT_KIND:
				return createGenericConstraintKindFromString(eDataType, initialValue);
			case Eastadl22Package.BOOLEAN:
				return createBooleanFromString(eDataType, initialValue);
			case Eastadl22Package.FLOAT:
				return createFloatFromString(eDataType, initialValue);
			case Eastadl22Package.IDENTIFIER:
				return createIdentifierFromString(eDataType, initialValue);
			case Eastadl22Package.INTEGER:
				return createIntegerFromString(eDataType, initialValue);
			case Eastadl22Package.NUMERICAL:
				return createNumericalFromString(eDataType, initialValue);
			case Eastadl22Package.REF:
				return createRefFromString(eDataType, initialValue);
			case Eastadl22Package.STRING:
				return createStringFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case Eastadl22Package.BINDING_TIME_KIND:
				return convertBindingTimeKindToString(eDataType, instanceValue);
			case Eastadl22Package.VARIABILITY_DEPENDENCY_KIND:
				return convertVariabilityDependencyKindToString(eDataType, instanceValue);
			case Eastadl22Package.DEVIATION_PERMISSION_KIND:
				return convertDeviationPermissionKindToString(eDataType, instanceValue);
			case Eastadl22Package.CLIENT_SERVER_KIND:
				return convertClientServerKindToString(eDataType, instanceValue);
			case Eastadl22Package.EA_DIRECTION_KIND:
				return convertEADirectionKindToString(eDataType, instanceValue);
			case Eastadl22Package.HARDWARE_BUS_KIND:
				return convertHardwareBusKindToString(eDataType, instanceValue);
			case Eastadl22Package.IO_HARDWARE_PIN_KIND:
				return convertIOHardwarePinKindToString(eDataType, instanceValue);
			case Eastadl22Package.FUNCTION_BEHAVIOR_KIND:
				return convertFunctionBehaviorKindToString(eDataType, instanceValue);
			case Eastadl22Package.TRIGGER_POLICY_KIND:
				return convertTriggerPolicyKindToString(eDataType, instanceValue);
			case Eastadl22Package.QUALITY_REQUIREMENT_KIND:
				return convertQualityRequirementKindToString(eDataType, instanceValue);
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_KIND:
				return convertEventFunctionClientServerPortKindToString(eDataType, instanceValue);
			case Eastadl22Package.EVENT_FUNCTION_KIND:
				return convertEventFunctionKindToString(eDataType, instanceValue);
			case Eastadl22Package.COMPARISON_KIND:
				return convertComparisonKindToString(eDataType, instanceValue);
			case Eastadl22Package.CONTROLLABILITY_CLASS_KIND:
				return convertControllabilityClassKindToString(eDataType, instanceValue);
			case Eastadl22Package.DEVELOPMENT_CATEGORY_KIND:
				return convertDevelopmentCategoryKindToString(eDataType, instanceValue);
			case Eastadl22Package.EXPOSURE_CLASS_KIND:
				return convertExposureClassKindToString(eDataType, instanceValue);
			case Eastadl22Package.SEVERITY_CLASS_KIND:
				return convertSeverityClassKindToString(eDataType, instanceValue);
			case Eastadl22Package.ASIL_KIND:
				return convertASILKindToString(eDataType, instanceValue);
			case Eastadl22Package.ERROR_BEHAVIOR_KIND:
				return convertErrorBehaviorKindToString(eDataType, instanceValue);
			case Eastadl22Package.LIFECYCLE_STAGE_KIND:
				return convertLifecycleStageKindToString(eDataType, instanceValue);
			case Eastadl22Package.GENERIC_CONSTRAINT_KIND:
				return convertGenericConstraintKindToString(eDataType, instanceValue);
			case Eastadl22Package.BOOLEAN:
				return convertBooleanToString(eDataType, instanceValue);
			case Eastadl22Package.FLOAT:
				return convertFloatToString(eDataType, instanceValue);
			case Eastadl22Package.IDENTIFIER:
				return convertIdentifierToString(eDataType, instanceValue);
			case Eastadl22Package.INTEGER:
				return convertIntegerToString(eDataType, instanceValue);
			case Eastadl22Package.NUMERICAL:
				return convertNumericalToString(eDataType, instanceValue);
			case Eastadl22Package.REF:
				return convertRefToString(eDataType, instanceValue);
			case Eastadl22Package.STRING:
				return convertStringToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VehicleLevel createVehicleLevel() {
		VehicleLevelImpl vehicleLevel = new VehicleLevelImpl();
		return vehicleLevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SystemModel createSystemModel() {
		SystemModelImpl systemModel = new SystemModelImpl();
		return systemModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AnalysisLevel createAnalysisLevel() {
		AnalysisLevelImpl analysisLevel = new AnalysisLevelImpl();
		return analysisLevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DesignLevel createDesignLevel() {
		DesignLevelImpl designLevel = new DesignLevelImpl();
		return designLevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ImplementationLevel createImplementationLevel() {
		ImplementationLevelImpl implementationLevel = new ImplementationLevelImpl();
		return implementationLevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Feature createFeature() {
		FeatureImpl feature = new FeatureImpl();
		return feature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FeatureConstraint createFeatureConstraint() {
		FeatureConstraintImpl featureConstraint = new FeatureConstraintImpl();
		return featureConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FeatureGroup createFeatureGroup() {
		FeatureGroupImpl featureGroup = new FeatureGroupImpl();
		return featureGroup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FeatureLink createFeatureLink() {
		FeatureLinkImpl featureLink = new FeatureLinkImpl();
		return featureLink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FeatureModel createFeatureModel() {
		FeatureModelImpl featureModel = new FeatureModelImpl();
		return featureModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DeviationAttributeSet createDeviationAttributeSet() {
		DeviationAttributeSetImpl deviationAttributeSet = new DeviationAttributeSetImpl();
		return deviationAttributeSet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VehicleFeature createVehicleFeature() {
		VehicleFeatureImpl vehicleFeature = new VehicleFeatureImpl();
		return vehicleFeature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Allocation createAllocation() {
		AllocationImpl allocation = new AllocationImpl();
		return allocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AnalysisFunctionPrototype createAnalysisFunctionPrototype() {
		AnalysisFunctionPrototypeImpl analysisFunctionPrototype = new AnalysisFunctionPrototypeImpl();
		return analysisFunctionPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AnalysisFunctionType createAnalysisFunctionType() {
		AnalysisFunctionTypeImpl analysisFunctionType = new AnalysisFunctionTypeImpl();
		return analysisFunctionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BasicSoftwareFunctionType createBasicSoftwareFunctionType() {
		BasicSoftwareFunctionTypeImpl basicSoftwareFunctionType = new BasicSoftwareFunctionTypeImpl();
		return basicSoftwareFunctionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DesignFunctionPrototype createDesignFunctionPrototype() {
		DesignFunctionPrototypeImpl designFunctionPrototype = new DesignFunctionPrototypeImpl();
		return designFunctionPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DesignFunctionType createDesignFunctionType() {
		DesignFunctionTypeImpl designFunctionType = new DesignFunctionTypeImpl();
		return designFunctionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionalDevice createFunctionalDevice() {
		FunctionalDeviceImpl functionalDevice = new FunctionalDeviceImpl();
		return functionalDevice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionAllocation createFunctionAllocation() {
		FunctionAllocationImpl functionAllocation = new FunctionAllocationImpl();
		return functionAllocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionClientServerInterface createFunctionClientServerInterface() {
		FunctionClientServerInterfaceImpl functionClientServerInterface = new FunctionClientServerInterfaceImpl();
		return functionClientServerInterface;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionClientServerPort createFunctionClientServerPort() {
		FunctionClientServerPortImpl functionClientServerPort = new FunctionClientServerPortImpl();
		return functionClientServerPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionConnector createFunctionConnector() {
		FunctionConnectorImpl functionConnector = new FunctionConnectorImpl();
		return functionConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionFlowPort createFunctionFlowPort() {
		FunctionFlowPortImpl functionFlowPort = new FunctionFlowPortImpl();
		return functionFlowPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionPowerPort createFunctionPowerPort() {
		FunctionPowerPortImpl functionPowerPort = new FunctionPowerPortImpl();
		return functionPowerPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HardwareFunctionType createHardwareFunctionType() {
		HardwareFunctionTypeImpl hardwareFunctionType = new HardwareFunctionTypeImpl();
		return hardwareFunctionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LocalDeviceManager createLocalDeviceManager() {
		LocalDeviceManagerImpl localDeviceManager = new LocalDeviceManagerImpl();
		return localDeviceManager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Operation createOperation() {
		OperationImpl operation = new OperationImpl();
		return operation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortGroup createPortGroup() {
		PortGroupImpl portGroup = new PortGroupImpl();
		return portGroup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionAllocation_allocatedElement createFunctionAllocation_allocatedElement() {
		FunctionAllocation_allocatedElementImpl functionAllocation_allocatedElement = new FunctionAllocation_allocatedElementImpl();
		return functionAllocation_allocatedElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionAllocation_target createFunctionAllocation_target() {
		FunctionAllocation_targetImpl functionAllocation_target = new FunctionAllocation_targetImpl();
		return functionAllocation_target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionConnector_port createFunctionConnector_port() {
		FunctionConnector_portImpl functionConnector_port = new FunctionConnector_portImpl();
		return functionConnector_port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Actuator createActuator() {
		ActuatorImpl actuator = new ActuatorImpl();
		return actuator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CommunicationHardwarePin createCommunicationHardwarePin() {
		CommunicationHardwarePinImpl communicationHardwarePin = new CommunicationHardwarePinImpl();
		return communicationHardwarePin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ElectricalComponent createElectricalComponent() {
		ElectricalComponentImpl electricalComponent = new ElectricalComponentImpl();
		return electricalComponent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HardwareComponentPrototype createHardwareComponentPrototype() {
		HardwareComponentPrototypeImpl hardwareComponentPrototype = new HardwareComponentPrototypeImpl();
		return hardwareComponentPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HardwareComponentType createHardwareComponentType() {
		HardwareComponentTypeImpl hardwareComponentType = new HardwareComponentTypeImpl();
		return hardwareComponentType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HardwareConnector createHardwareConnector() {
		HardwareConnectorImpl hardwareConnector = new HardwareConnectorImpl();
		return hardwareConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HardwarePort createHardwarePort() {
		HardwarePortImpl hardwarePort = new HardwarePortImpl();
		return hardwarePort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HardwarePortConnector createHardwarePortConnector() {
		HardwarePortConnectorImpl hardwarePortConnector = new HardwarePortConnectorImpl();
		return hardwarePortConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public IOHardwarePin createIOHardwarePin() {
		IOHardwarePinImpl ioHardwarePin = new IOHardwarePinImpl();
		return ioHardwarePin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LogicalPortConnector createLogicalPortConnector() {
		LogicalPortConnectorImpl logicalPortConnector = new LogicalPortConnectorImpl();
		return logicalPortConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Node createNode() {
		NodeImpl node = new NodeImpl();
		return node;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PowerHardwarePin createPowerHardwarePin() {
		PowerHardwarePinImpl powerHardwarePin = new PowerHardwarePinImpl();
		return powerHardwarePin;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Sensor createSensor() {
		SensorImpl sensor = new SensorImpl();
		return sensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HardwareConnector_port createHardwareConnector_port() {
		HardwareConnector_portImpl hardwareConnector_port = new HardwareConnector_portImpl();
		return hardwareConnector_port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HardwarePortConnector_port createHardwarePortConnector_port() {
		HardwarePortConnector_portImpl hardwarePortConnector_port = new HardwarePortConnector_portImpl();
		return hardwarePortConnector_port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ClampConnector createClampConnector() {
		ClampConnectorImpl clampConnector = new ClampConnectorImpl();
		return clampConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Environment createEnvironment() {
		EnvironmentImpl environment = new EnvironmentImpl();
		return environment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ClampConnector_port createClampConnector_port() {
		ClampConnector_portImpl clampConnector_port = new ClampConnector_portImpl();
		return clampConnector_port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Behavior createBehavior() {
		BehaviorImpl behavior = new BehaviorImpl();
		return behavior;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Mode createMode() {
		ModeImpl mode = new ModeImpl();
		return mode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ModeGroup createModeGroup() {
		ModeGroupImpl modeGroup = new ModeGroupImpl();
		return modeGroup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionBehavior createFunctionBehavior() {
		FunctionBehaviorImpl functionBehavior = new FunctionBehaviorImpl();
		return functionBehavior;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionTrigger createFunctionTrigger() {
		FunctionTriggerImpl functionTrigger = new FunctionTriggerImpl();
		return functionTrigger;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConfigurableContainer createConfigurableContainer() {
		ConfigurableContainerImpl configurableContainer = new ConfigurableContainerImpl();
		return configurableContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConfigurationDecision createConfigurationDecision() {
		ConfigurationDecisionImpl configurationDecision = new ConfigurationDecisionImpl();
		return configurationDecision;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConfigurationDecisionFolder createConfigurationDecisionFolder() {
		ConfigurationDecisionFolderImpl configurationDecisionFolder = new ConfigurationDecisionFolderImpl();
		return configurationDecisionFolder;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ContainerConfiguration createContainerConfiguration() {
		ContainerConfigurationImpl containerConfiguration = new ContainerConfigurationImpl();
		return containerConfiguration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FeatureConfiguration createFeatureConfiguration() {
		FeatureConfigurationImpl featureConfiguration = new FeatureConfigurationImpl();
		return featureConfiguration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InternalBinding createInternalBinding() {
		InternalBindingImpl internalBinding = new InternalBindingImpl();
		return internalBinding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PrivateContent createPrivateContent() {
		PrivateContentImpl privateContent = new PrivateContentImpl();
		return privateContent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ReuseMetaInformation createReuseMetaInformation() {
		ReuseMetaInformationImpl reuseMetaInformation = new ReuseMetaInformationImpl();
		return reuseMetaInformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SelectionCriterion createSelectionCriterion() {
		SelectionCriterionImpl selectionCriterion = new SelectionCriterionImpl();
		return selectionCriterion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Variability createVariability() {
		VariabilityImpl variability = new VariabilityImpl();
		return variability;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VariableElement createVariableElement() {
		VariableElementImpl variableElement = new VariableElementImpl();
		return variableElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VariationGroup createVariationGroup() {
		VariationGroupImpl variationGroup = new VariationGroupImpl();
		return variationGroup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VehicleLevelBinding createVehicleLevelBinding() {
		VehicleLevelBindingImpl vehicleLevelBinding = new VehicleLevelBindingImpl();
		return vehicleLevelBinding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DeriveRequirement createDeriveRequirement() {
		DeriveRequirementImpl deriveRequirement = new DeriveRequirementImpl();
		return deriveRequirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Situation createSituation() {
		SituationImpl situation = new SituationImpl();
		return situation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RequirementsModel createRequirementsModel() {
		RequirementsModelImpl requirementsModel = new RequirementsModelImpl();
		return requirementsModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Requirement createRequirement() {
		RequirementImpl requirement = new RequirementImpl();
		return requirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RequirementsHierarchy createRequirementsHierarchy() {
		RequirementsHierarchyImpl requirementsHierarchy = new RequirementsHierarchyImpl();
		return requirementsHierarchy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Refine createRefine() {
		RefineImpl refine = new RefineImpl();
		return refine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Satisfy createSatisfy() {
		SatisfyImpl satisfy = new SatisfyImpl();
		return satisfy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RequirementsLink createRequirementsLink() {
		RequirementsLinkImpl requirementsLink = new RequirementsLinkImpl();
		return requirementsLink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RequirementsRelationshipGroup createRequirementsRelationshipGroup() {
		RequirementsRelationshipGroupImpl requirementsRelationshipGroup = new RequirementsRelationshipGroupImpl();
		return requirementsRelationshipGroup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public QualityRequirement createQualityRequirement() {
		QualityRequirementImpl qualityRequirement = new QualityRequirementImpl();
		return qualityRequirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Refine_refinedBy createRefine_refinedBy() {
		Refine_refinedByImpl refine_refinedBy = new Refine_refinedByImpl();
		return refine_refinedBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Satisfy_satisfiedBy createSatisfy_satisfiedBy() {
		Satisfy_satisfiedByImpl satisfy_satisfiedBy = new Satisfy_satisfiedByImpl();
		return satisfy_satisfiedBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Actor createActor() {
		ActorImpl actor = new ActorImpl();
		return actor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Extend createExtend() {
		ExtendImpl extend = new ExtendImpl();
		return extend;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExtensionPoint createExtensionPoint() {
		ExtensionPointImpl extensionPoint = new ExtensionPointImpl();
		return extensionPoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Include createInclude() {
		IncludeImpl include = new IncludeImpl();
		return include;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Interact createInteract() {
		InteractImpl interact = new InteractImpl();
		return interact;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UseCase createUseCase() {
		UseCaseImpl useCase = new UseCaseImpl();
		return useCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VerificationValidation createVerificationValidation() {
		VerificationValidationImpl verificationValidation = new VerificationValidationImpl();
		return verificationValidation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Verify createVerify() {
		VerifyImpl verify = new VerifyImpl();
		return verify;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VVActualOutcome createVVActualOutcome() {
		VVActualOutcomeImpl vvActualOutcome = new VVActualOutcomeImpl();
		return vvActualOutcome;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VVCase createVVCase() {
		VVCaseImpl vvCase = new VVCaseImpl();
		return vvCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VVIntendedOutcome createVVIntendedOutcome() {
		VVIntendedOutcomeImpl vvIntendedOutcome = new VVIntendedOutcomeImpl();
		return vvIntendedOutcome;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VVLog createVVLog() {
		VVLogImpl vvLog = new VVLogImpl();
		return vvLog;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VVProcedure createVVProcedure() {
		VVProcedureImpl vvProcedure = new VVProcedureImpl();
		return vvProcedure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VVStimuli createVVStimuli() {
		VVStimuliImpl vvStimuli = new VVStimuliImpl();
		return vvStimuli;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VVTarget createVVTarget() {
		VVTargetImpl vvTarget = new VVTargetImpl();
		return vvTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VVCase_vvSubject createVVCase_vvSubject() {
		VVCase_vvSubjectImpl vvCase_vvSubject = new VVCase_vvSubjectImpl();
		return vvCase_vvSubject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VVTarget_element createVVTarget_element() {
		VVTarget_elementImpl vvTarget_element = new VVTarget_elementImpl();
		return vvTarget_element;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventChain createEventChain() {
		EventChainImpl eventChain = new EventChainImpl();
		return eventChain;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NonConcurrenceConstraint createNonConcurrenceConstraint() {
		NonConcurrenceConstraintImpl nonConcurrenceConstraint = new NonConcurrenceConstraintImpl();
		return nonConcurrenceConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NonPreemptiveConstraint createNonPreemptiveConstraint() {
		NonPreemptiveConstraintImpl nonPreemptiveConstraint = new NonPreemptiveConstraintImpl();
		return nonPreemptiveConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PrecedenceConstraint createPrecedenceConstraint() {
		PrecedenceConstraintImpl precedenceConstraint = new PrecedenceConstraintImpl();
		return precedenceConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Timing createTiming() {
		TimingImpl timing = new TimingImpl();
		return timing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TimingExpression createTimingExpression() {
		TimingExpressionImpl timingExpression = new TimingExpressionImpl();
		return timingExpression;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AUTOSAREvent createAUTOSAREvent() {
		AUTOSAREventImpl autosarEvent = new AUTOSAREventImpl();
		return autosarEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventFaultFailure createEventFaultFailure() {
		EventFaultFailureImpl eventFaultFailure = new EventFaultFailureImpl();
		return eventFaultFailure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventFeatureFlaw createEventFeatureFlaw() {
		EventFeatureFlawImpl eventFeatureFlaw = new EventFeatureFlawImpl();
		return eventFeatureFlaw;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventFunction createEventFunction() {
		EventFunctionImpl eventFunction = new EventFunctionImpl();
		return eventFunction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventFunctionClientServerPort createEventFunctionClientServerPort() {
		EventFunctionClientServerPortImpl eventFunctionClientServerPort = new EventFunctionClientServerPortImpl();
		return eventFunctionClientServerPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventFunctionFlowPort createEventFunctionFlowPort() {
		EventFunctionFlowPortImpl eventFunctionFlowPort = new EventFunctionFlowPortImpl();
		return eventFunctionFlowPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExternalEvent createExternalEvent() {
		ExternalEventImpl externalEvent = new ExternalEventImpl();
		return externalEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ModeEvent createModeEvent() {
		ModeEventImpl modeEvent = new ModeEventImpl();
		return modeEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventFunction_function createEventFunction_function() {
		EventFunction_functionImpl eventFunction_function = new EventFunction_functionImpl();
		return eventFunction_function;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventFunctionClientServerPort_port createEventFunctionClientServerPort_port() {
		EventFunctionClientServerPort_portImpl eventFunctionClientServerPort_port = new EventFunctionClientServerPort_portImpl();
		return eventFunctionClientServerPort_port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EventFunctionFlowPort_port createEventFunctionFlowPort_port() {
		EventFunctionFlowPort_portImpl eventFunctionFlowPort_port = new EventFunctionFlowPort_portImpl();
		return eventFunctionFlowPort_port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AgeConstraint createAgeConstraint() {
		AgeConstraintImpl ageConstraint = new AgeConstraintImpl();
		return ageConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ArbitraryConstraint createArbitraryConstraint() {
		ArbitraryConstraintImpl arbitraryConstraint = new ArbitraryConstraintImpl();
		return arbitraryConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BurstConstraint createBurstConstraint() {
		BurstConstraintImpl burstConstraint = new BurstConstraintImpl();
		return burstConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ComparisonConstraint createComparisonConstraint() {
		ComparisonConstraintImpl comparisonConstraint = new ComparisonConstraintImpl();
		return comparisonConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DelayConstraint createDelayConstraint() {
		DelayConstraintImpl delayConstraint = new DelayConstraintImpl();
		return delayConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExecutionTimeConstraint createExecutionTimeConstraint() {
		ExecutionTimeConstraintImpl executionTimeConstraint = new ExecutionTimeConstraintImpl();
		return executionTimeConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InputSynchronizationConstraint createInputSynchronizationConstraint() {
		InputSynchronizationConstraintImpl inputSynchronizationConstraint = new InputSynchronizationConstraintImpl();
		return inputSynchronizationConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public OrderConstraint createOrderConstraint() {
		OrderConstraintImpl orderConstraint = new OrderConstraintImpl();
		return orderConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public OutputSynchronizationConstraint createOutputSynchronizationConstraint() {
		OutputSynchronizationConstraintImpl outputSynchronizationConstraint = new OutputSynchronizationConstraintImpl();
		return outputSynchronizationConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PatternConstraint createPatternConstraint() {
		PatternConstraintImpl patternConstraint = new PatternConstraintImpl();
		return patternConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PeriodicConstraint createPeriodicConstraint() {
		PeriodicConstraintImpl periodicConstraint = new PeriodicConstraintImpl();
		return periodicConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ReactionConstraint createReactionConstraint() {
		ReactionConstraintImpl reactionConstraint = new ReactionConstraintImpl();
		return reactionConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RepetitionConstraint createRepetitionConstraint() {
		RepetitionConstraintImpl repetitionConstraint = new RepetitionConstraintImpl();
		return repetitionConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SporadicConstraint createSporadicConstraint() {
		SporadicConstraintImpl sporadicConstraint = new SporadicConstraintImpl();
		return sporadicConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StrongDelayConstraint createStrongDelayConstraint() {
		StrongDelayConstraintImpl strongDelayConstraint = new StrongDelayConstraintImpl();
		return strongDelayConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StrongSynchronizationConstraint createStrongSynchronizationConstraint() {
		StrongSynchronizationConstraintImpl strongSynchronizationConstraint = new StrongSynchronizationConstraintImpl();
		return strongSynchronizationConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SynchronizationConstraint createSynchronizationConstraint() {
		SynchronizationConstraintImpl synchronizationConstraint = new SynchronizationConstraintImpl();
		return synchronizationConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NonConcurrentConstraint_exclusive createNonConcurrentConstraint_exclusive() {
		NonConcurrentConstraint_exclusiveImpl nonConcurrentConstraint_exclusive = new NonConcurrentConstraint_exclusiveImpl();
		return nonConcurrentConstraint_exclusive;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Dependability createDependability() {
		DependabilityImpl dependability = new DependabilityImpl();
		return dependability;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FeatureFlaw createFeatureFlaw() {
		FeatureFlawImpl featureFlaw = new FeatureFlawImpl();
		return featureFlaw;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Hazard createHazard() {
		HazardImpl hazard = new HazardImpl();
		return hazard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HazardousEvent createHazardousEvent() {
		HazardousEventImpl hazardousEvent = new HazardousEventImpl();
		return hazardousEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Item createItem() {
		ItemImpl item = new ItemImpl();
		return item;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FaultFailure createFaultFailure() {
		FaultFailureImpl faultFailure = new FaultFailureImpl();
		return faultFailure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public QuantitativeSafetyConstraint createQuantitativeSafetyConstraint() {
		QuantitativeSafetyConstraintImpl quantitativeSafetyConstraint = new QuantitativeSafetyConstraintImpl();
		return quantitativeSafetyConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SafetyConstraint createSafetyConstraint() {
		SafetyConstraintImpl safetyConstraint = new SafetyConstraintImpl();
		return safetyConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FaultFailure_anomaly createFaultFailure_anomaly() {
		FaultFailure_anomalyImpl faultFailure_anomaly = new FaultFailure_anomalyImpl();
		return faultFailure_anomaly;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ErrorBehavior createErrorBehavior() {
		ErrorBehaviorImpl errorBehavior = new ErrorBehaviorImpl();
		return errorBehavior;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ErrorModelPrototype createErrorModelPrototype() {
		ErrorModelPrototypeImpl errorModelPrototype = new ErrorModelPrototypeImpl();
		return errorModelPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ErrorModelType createErrorModelType() {
		ErrorModelTypeImpl errorModelType = new ErrorModelTypeImpl();
		return errorModelType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FailureOutPort createFailureOutPort() {
		FailureOutPortImpl failureOutPort = new FailureOutPortImpl();
		return failureOutPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FaultFailurePropagationLink createFaultFailurePropagationLink() {
		FaultFailurePropagationLinkImpl faultFailurePropagationLink = new FaultFailurePropagationLinkImpl();
		return faultFailurePropagationLink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FaultInPort createFaultInPort() {
		FaultInPortImpl faultInPort = new FaultInPortImpl();
		return faultInPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InternalFaultPrototype createInternalFaultPrototype() {
		InternalFaultPrototypeImpl internalFaultPrototype = new InternalFaultPrototypeImpl();
		return internalFaultPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ProcessFaultPrototype createProcessFaultPrototype() {
		ProcessFaultPrototypeImpl processFaultPrototype = new ProcessFaultPrototypeImpl();
		return processFaultPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ErrorModelPrototype_functionTarget createErrorModelPrototype_functionTarget() {
		ErrorModelPrototype_functionTargetImpl errorModelPrototype_functionTarget = new ErrorModelPrototype_functionTargetImpl();
		return errorModelPrototype_functionTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ErrorModelPrototype_hwTarget createErrorModelPrototype_hwTarget() {
		ErrorModelPrototype_hwTargetImpl errorModelPrototype_hwTarget = new ErrorModelPrototype_hwTargetImpl();
		return errorModelPrototype_hwTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FaultFailurePort_functionTarget createFaultFailurePort_functionTarget() {
		FaultFailurePort_functionTargetImpl faultFailurePort_functionTarget = new FaultFailurePort_functionTargetImpl();
		return faultFailurePort_functionTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FaultFailurePort_hwTarget createFaultFailurePort_hwTarget() {
		FaultFailurePort_hwTargetImpl faultFailurePort_hwTarget = new FaultFailurePort_hwTargetImpl();
		return faultFailurePort_hwTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FaultFailurePropagationLink_fromPort createFaultFailurePropagationLink_fromPort() {
		FaultFailurePropagationLink_fromPortImpl faultFailurePropagationLink_fromPort = new FaultFailurePropagationLink_fromPortImpl();
		return faultFailurePropagationLink_fromPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FaultFailurePropagationLink_toPort createFaultFailurePropagationLink_toPort() {
		FaultFailurePropagationLink_toPortImpl faultFailurePropagationLink_toPort = new FaultFailurePropagationLink_toPortImpl();
		return faultFailurePropagationLink_toPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FunctionalSafetyConcept createFunctionalSafetyConcept() {
		FunctionalSafetyConceptImpl functionalSafetyConcept = new FunctionalSafetyConceptImpl();
		return functionalSafetyConcept;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SafetyGoal createSafetyGoal() {
		SafetyGoalImpl safetyGoal = new SafetyGoalImpl();
		return safetyGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TechnicalSafetyConcept createTechnicalSafetyConcept() {
		TechnicalSafetyConceptImpl technicalSafetyConcept = new TechnicalSafetyConceptImpl();
		return technicalSafetyConcept;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Claim createClaim() {
		ClaimImpl claim = new ClaimImpl();
		return claim;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Ground createGround() {
		GroundImpl ground = new GroundImpl();
		return ground;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SafetyCase createSafetyCase() {
		SafetyCaseImpl safetyCase = new SafetyCaseImpl();
		return safetyCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Warrant createWarrant() {
		WarrantImpl warrant = new WarrantImpl();
		return warrant;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GenericConstraint createGenericConstraint() {
		GenericConstraintImpl genericConstraint = new GenericConstraintImpl();
		return genericConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GenericConstraintSet createGenericConstraintSet() {
		GenericConstraintSetImpl genericConstraintSet = new GenericConstraintSetImpl();
		return genericConstraintSet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TakeRateConstraint createTakeRateConstraint() {
		TakeRateConstraintImpl takeRateConstraint = new TakeRateConstraintImpl();
		return takeRateConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Comment createComment() {
		CommentImpl comment = new CommentImpl();
		return comment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAPackage createEAPackage() {
		EAPackageImpl eaPackage = new EAPackageImpl();
		return eaPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAXML createEAXML() {
		EAXMLImpl eaxml = new EAXMLImpl();
		return eaxml;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Rationale createRationale() {
		RationaleImpl rationale = new RationaleImpl();
		return rationale;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Realization createRealization() {
		RealizationImpl realization = new RealizationImpl();
		return realization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Realization_realized createRealization_realized() {
		Realization_realizedImpl realization_realized = new Realization_realizedImpl();
		return realization_realized;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Realization_realizedBy createRealization_realizedBy() {
		Realization_realizedByImpl realization_realizedBy = new Realization_realizedByImpl();
		return realization_realizedBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ArrayDatatype createArrayDatatype() {
		ArrayDatatypeImpl arrayDatatype = new ArrayDatatypeImpl();
		return arrayDatatype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CompositeDatatype createCompositeDatatype() {
		CompositeDatatypeImpl compositeDatatype = new CompositeDatatypeImpl();
		return compositeDatatype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EABoolean createEABoolean() {
		EABooleanImpl eaBoolean = new EABooleanImpl();
		return eaBoolean;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EADatatypePrototype createEADatatypePrototype() {
		EADatatypePrototypeImpl eaDatatypePrototype = new EADatatypePrototypeImpl();
		return eaDatatypePrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EANumerical createEANumerical() {
		EANumericalImpl eaNumerical = new EANumericalImpl();
		return eaNumerical;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAString createEAString() {
		EAStringImpl eaString = new EAStringImpl();
		return eaString;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Enumeration createEnumeration() {
		EnumerationImpl enumeration = new EnumerationImpl();
		return enumeration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EnumerationLiteral createEnumerationLiteral() {
		EnumerationLiteralImpl enumerationLiteral = new EnumerationLiteralImpl();
		return enumerationLiteral;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Quantity createQuantity() {
		QuantityImpl quantity = new QuantityImpl();
		return quantity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RangeableValueType createRangeableValueType() {
		RangeableValueTypeImpl rangeableValueType = new RangeableValueTypeImpl();
		return rangeableValueType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Unit createUnit() {
		UnitImpl unit = new UnitImpl();
		return unit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAArrayValue createEAArrayValue() {
		EAArrayValueImpl eaArrayValue = new EAArrayValueImpl();
		return eaArrayValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EABooleanValue createEABooleanValue() {
		EABooleanValueImpl eaBooleanValue = new EABooleanValueImpl();
		return eaBooleanValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EACompositeValue createEACompositeValue() {
		EACompositeValueImpl eaCompositeValue = new EACompositeValueImpl();
		return eaCompositeValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAEnumerationValue createEAEnumerationValue() {
		EAEnumerationValueImpl eaEnumerationValue = new EAEnumerationValueImpl();
		return eaEnumerationValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAExpression createEAExpression() {
		EAExpressionImpl eaExpression = new EAExpressionImpl();
		return eaExpression;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EANumericalValue createEANumericalValue() {
		EANumericalValueImpl eaNumericalValue = new EANumericalValueImpl();
		return eaNumericalValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAStringValue createEAStringValue() {
		EAStringValueImpl eaStringValue = new EAStringValueImpl();
		return eaStringValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UserAttributeDefinition createUserAttributeDefinition() {
		UserAttributeDefinitionImpl userAttributeDefinition = new UserAttributeDefinitionImpl();
		return userAttributeDefinition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UserAttributedElement createUserAttributedElement() {
		UserAttributedElementImpl userAttributedElement = new UserAttributedElementImpl();
		return userAttributedElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UserElementType createUserElementType() {
		UserElementTypeImpl userElementType = new UserElementTypeImpl();
		return userElementType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintBindingAttribute createBehaviorConstraintBindingAttribute() {
		BehaviorConstraintBindingAttributeImpl behaviorConstraintBindingAttribute = new BehaviorConstraintBindingAttributeImpl();
		return behaviorConstraintBindingAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintBindingEvent createBehaviorConstraintBindingEvent() {
		BehaviorConstraintBindingEventImpl behaviorConstraintBindingEvent = new BehaviorConstraintBindingEventImpl();
		return behaviorConstraintBindingEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintPrototype createBehaviorConstraintPrototype() {
		BehaviorConstraintPrototypeImpl behaviorConstraintPrototype = new BehaviorConstraintPrototypeImpl();
		return behaviorConstraintPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintTargetBinding createBehaviorConstraintTargetBinding() {
		BehaviorConstraintTargetBindingImpl behaviorConstraintTargetBinding = new BehaviorConstraintTargetBindingImpl();
		return behaviorConstraintTargetBinding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintType createBehaviorConstraintType() {
		BehaviorConstraintTypeImpl behaviorConstraintType = new BehaviorConstraintTypeImpl();
		return behaviorConstraintType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintInternalBinding_bindingThroughFunctionConnector createBehaviorConstraintInternalBinding_bindingThroughFunctionConnector() {
		BehaviorConstraintInternalBinding_bindingThroughFunctionConnectorImpl behaviorConstraintInternalBinding_bindingThroughFunctionConnector = new BehaviorConstraintInternalBinding_bindingThroughFunctionConnectorImpl();
		return behaviorConstraintInternalBinding_bindingThroughFunctionConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintInternalBinding_bindingThroughHardwareConnector createBehaviorConstraintInternalBinding_bindingThroughHardwareConnector() {
		BehaviorConstraintInternalBinding_bindingThroughHardwareConnectorImpl behaviorConstraintInternalBinding_bindingThroughHardwareConnector = new BehaviorConstraintInternalBinding_bindingThroughHardwareConnectorImpl();
		return behaviorConstraintInternalBinding_bindingThroughHardwareConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintPrototype_errorModelTarget createBehaviorConstraintPrototype_errorModelTarget() {
		BehaviorConstraintPrototype_errorModelTargetImpl behaviorConstraintPrototype_errorModelTarget = new BehaviorConstraintPrototype_errorModelTargetImpl();
		return behaviorConstraintPrototype_errorModelTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintPrototype_functionTarget createBehaviorConstraintPrototype_functionTarget() {
		BehaviorConstraintPrototype_functionTargetImpl behaviorConstraintPrototype_functionTarget = new BehaviorConstraintPrototype_functionTargetImpl();
		return behaviorConstraintPrototype_functionTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorConstraintPrototype_hardwareComponentTarget createBehaviorConstraintPrototype_hardwareComponentTarget() {
		BehaviorConstraintPrototype_hardwareComponentTargetImpl behaviorConstraintPrototype_hardwareComponentTarget = new BehaviorConstraintPrototype_hardwareComponentTargetImpl();
		return behaviorConstraintPrototype_hardwareComponentTarget;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Attribute createAttribute() {
		AttributeImpl attribute = new AttributeImpl();
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttributeQuantificationConstraint createAttributeQuantificationConstraint() {
		AttributeQuantificationConstraintImpl attributeQuantificationConstraint = new AttributeQuantificationConstraintImpl();
		return attributeQuantificationConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BehaviorAttributeBinding createBehaviorAttributeBinding() {
		BehaviorAttributeBindingImpl behaviorAttributeBinding = new BehaviorAttributeBindingImpl();
		return behaviorAttributeBinding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LogicalEvent createLogicalEvent() {
		LogicalEventImpl logicalEvent = new LogicalEventImpl();
		return logicalEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Quantification createQuantification() {
		QuantificationImpl quantification = new QuantificationImpl();
		return quantification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ComputationConstraint createComputationConstraint() {
		ComputationConstraintImpl computationConstraint = new ComputationConstraintImpl();
		return computationConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LogicalPath createLogicalPath() {
		LogicalPathImpl logicalPath = new LogicalPathImpl();
		return logicalPath;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LogicalTransformation createLogicalTransformation() {
		LogicalTransformationImpl logicalTransformation = new LogicalTransformationImpl();
		return logicalTransformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TransformationOccurrence createTransformationOccurrence() {
		TransformationOccurrenceImpl transformationOccurrence = new TransformationOccurrenceImpl();
		return transformationOccurrence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LogicalTimeCondition createLogicalTimeCondition() {
		LogicalTimeConditionImpl logicalTimeCondition = new LogicalTimeConditionImpl();
		return logicalTimeCondition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public State createState() {
		StateImpl state = new StateImpl();
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StateEvent createStateEvent() {
		StateEventImpl stateEvent = new StateEventImpl();
		return stateEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SynchronousTransition createSynchronousTransition() {
		SynchronousTransitionImpl synchronousTransition = new SynchronousTransitionImpl();
		return synchronousTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TemporalConstraint createTemporalConstraint() {
		TemporalConstraintImpl temporalConstraint = new TemporalConstraintImpl();
		return temporalConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Transition createTransition() {
		TransitionImpl transition = new TransitionImpl();
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TransitionEvent createTransitionEvent() {
		TransitionEventImpl transitionEvent = new TransitionEventImpl();
		return transitionEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ArchitecturalDescription createArchitecturalDescription() {
		ArchitecturalDescriptionImpl architecturalDescription = new ArchitecturalDescriptionImpl();
		return architecturalDescription;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ArchitecturalModel createArchitecturalModel() {
		ArchitecturalModelImpl architecturalModel = new ArchitecturalModelImpl();
		return architecturalModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Architecture createArchitecture() {
		ArchitectureImpl architecture = new ArchitectureImpl();
		return architecture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Mission createMission() {
		MissionImpl mission = new MissionImpl();
		return mission;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VehicleSystem createVehicleSystem() {
		VehicleSystemImpl vehicleSystem = new VehicleSystemImpl();
		return vehicleSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Stakeholder createStakeholder() {
		StakeholderImpl stakeholder = new StakeholderImpl();
		return stakeholder;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public StakeholderNeed createStakeholderNeed() {
		StakeholderNeedImpl stakeholderNeed = new StakeholderNeedImpl();
		return stakeholderNeed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BusinessOpportunity createBusinessOpportunity() {
		BusinessOpportunityImpl businessOpportunity = new BusinessOpportunityImpl();
		return businessOpportunity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ProblemStatement createProblemStatement() {
		ProblemStatementImpl problemStatement = new ProblemStatementImpl();
		return problemStatement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ProductPositioning createProductPositioning() {
		ProductPositioningImpl productPositioning = new ProductPositioningImpl();
		return productPositioning;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BindingTimeKind createBindingTimeKindFromString(EDataType eDataType, String initialValue) {
		BindingTimeKind result = BindingTimeKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertBindingTimeKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VariabilityDependencyKind createVariabilityDependencyKindFromString(EDataType eDataType, String initialValue) {
		VariabilityDependencyKind result = VariabilityDependencyKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertVariabilityDependencyKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeviationPermissionKind createDeviationPermissionKindFromString(EDataType eDataType, String initialValue) {
		DeviationPermissionKind result = DeviationPermissionKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDeviationPermissionKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClientServerKind createClientServerKindFromString(EDataType eDataType, String initialValue) {
		ClientServerKind result = ClientServerKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertClientServerKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EADirectionKind createEADirectionKindFromString(EDataType eDataType, String initialValue) {
		EADirectionKind result = EADirectionKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEADirectionKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HardwareBusKind createHardwareBusKindFromString(EDataType eDataType, String initialValue) {
		HardwareBusKind result = HardwareBusKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertHardwareBusKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IOHardwarePinKind createIOHardwarePinKindFromString(EDataType eDataType, String initialValue) {
		IOHardwarePinKind result = IOHardwarePinKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertIOHardwarePinKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionBehaviorKind createFunctionBehaviorKindFromString(EDataType eDataType, String initialValue) {
		FunctionBehaviorKind result = FunctionBehaviorKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertFunctionBehaviorKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TriggerPolicyKind createTriggerPolicyKindFromString(EDataType eDataType, String initialValue) {
		TriggerPolicyKind result = TriggerPolicyKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTriggerPolicyKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public QualityRequirementKind createQualityRequirementKindFromString(EDataType eDataType, String initialValue) {
		QualityRequirementKind result = QualityRequirementKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertQualityRequirementKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EventFunctionClientServerPortKind createEventFunctionClientServerPortKindFromString(EDataType eDataType, String initialValue) {
		EventFunctionClientServerPortKind result = EventFunctionClientServerPortKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEventFunctionClientServerPortKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EventFunctionKind createEventFunctionKindFromString(EDataType eDataType, String initialValue) {
		EventFunctionKind result = EventFunctionKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEventFunctionKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ComparisonKind createComparisonKindFromString(EDataType eDataType, String initialValue) {
		ComparisonKind result = ComparisonKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertComparisonKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ControllabilityClassKind createControllabilityClassKindFromString(EDataType eDataType, String initialValue) {
		ControllabilityClassKind result = ControllabilityClassKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertControllabilityClassKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DevelopmentCategoryKind createDevelopmentCategoryKindFromString(EDataType eDataType, String initialValue) {
		DevelopmentCategoryKind result = DevelopmentCategoryKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDevelopmentCategoryKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExposureClassKind createExposureClassKindFromString(EDataType eDataType, String initialValue) {
		ExposureClassKind result = ExposureClassKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertExposureClassKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SeverityClassKind createSeverityClassKindFromString(EDataType eDataType, String initialValue) {
		SeverityClassKind result = SeverityClassKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSeverityClassKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ASILKind createASILKindFromString(EDataType eDataType, String initialValue) {
		ASILKind result = ASILKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertASILKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ErrorBehaviorKind createErrorBehaviorKindFromString(EDataType eDataType, String initialValue) {
		ErrorBehaviorKind result = ErrorBehaviorKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertErrorBehaviorKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LifecycleStageKind createLifecycleStageKindFromString(EDataType eDataType, String initialValue) {
		LifecycleStageKind result = LifecycleStageKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLifecycleStageKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GenericConstraintKind createGenericConstraintKindFromString(EDataType eDataType, String initialValue) {
		GenericConstraintKind result = GenericConstraintKind.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertGenericConstraintKindToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean createBooleanFromString(EDataType eDataType, String initialValue) {
		return (Boolean)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertBooleanToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Double createFloatFromString(EDataType eDataType, String initialValue) {
		return (Double)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertFloatToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createIdentifierFromString(EDataType eDataType, String initialValue) {
		return (String)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertIdentifierToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Integer createIntegerFromString(EDataType eDataType, String initialValue) {
		return (Integer)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertIntegerToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createNumericalFromString(EDataType eDataType, String initialValue) {
		return (String)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertNumericalToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createRefFromString(EDataType eDataType, String initialValue) {
		return (String)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertRefToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createStringFromString(EDataType eDataType, String initialValue) {
		return (String)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertStringToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Eastadl22Package getEastadl22Package() {
		return (Eastadl22Package)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Eastadl22Package getPackage() {
		return Eastadl22Package.eINSTANCE;
	}

} //Eastadl22FactoryImpl
