/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.BehaviorConstraintInternalBinding_bindingThroughFunctionConnector;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.FunctionConnector;
import org.eclipse.eatop.eastadl22.FunctionPrototype;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eclipse.sphinx.emf.ecore.ExtendedEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Behavior Constraint Internal Binding binding Through Function Connector</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintInternalBinding_bindingThroughFunctionConnectorImpl#getFunctionPrototype <em>Function Prototype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.BehaviorConstraintInternalBinding_bindingThroughFunctionConnectorImpl#getFunctionConnector <em>Function Connector</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BehaviorConstraintInternalBinding_bindingThroughFunctionConnectorImpl extends ExtendedEObjectImpl implements BehaviorConstraintInternalBinding_bindingThroughFunctionConnector {
	/**
	 * The cached value of the '{@link #getFunctionPrototype() <em>Function Prototype</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionPrototype()
	 * @generated
	 * @ordered
	 */
	protected EList<FunctionPrototype> functionPrototype;

	/**
	 * The cached value of the '{@link #getFunctionConnector() <em>Function Connector</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionConnector()
	 * @generated
	 * @ordered
	 */
	protected FunctionConnector functionConnector;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BehaviorConstraintInternalBinding_bindingThroughFunctionConnectorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getBehaviorConstraintInternalBinding_bindingThroughFunctionConnector();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FunctionPrototype> getFunctionPrototype() {
		if (functionPrototype == null) {
			functionPrototype = new EObjectResolvingEList<FunctionPrototype>(FunctionPrototype.class, this, Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_PROTOTYPE);
		}
		return functionPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionConnector getFunctionConnector() {
		if (functionConnector != null && functionConnector.eIsProxy()) {
			InternalEObject oldFunctionConnector = (InternalEObject)functionConnector;
			functionConnector = (FunctionConnector)eResolveProxy(oldFunctionConnector);
			if (functionConnector != oldFunctionConnector) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_CONNECTOR, oldFunctionConnector, functionConnector));
			}
		}
		return functionConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionConnector basicGetFunctionConnector() {
		return functionConnector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFunctionConnector(FunctionConnector newFunctionConnector) {
		FunctionConnector oldFunctionConnector = functionConnector;
		functionConnector = newFunctionConnector;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_CONNECTOR, oldFunctionConnector, functionConnector));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_PROTOTYPE:
				return getFunctionPrototype();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_CONNECTOR:
				if (resolve) return getFunctionConnector();
				return basicGetFunctionConnector();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_PROTOTYPE:
				getFunctionPrototype().clear();
				getFunctionPrototype().addAll((Collection<? extends FunctionPrototype>)newValue);
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_CONNECTOR:
   			setFunctionConnector((FunctionConnector)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_PROTOTYPE:
				getFunctionPrototype().clear();
				return;
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_CONNECTOR:
		    	setFunctionConnector((FunctionConnector)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_PROTOTYPE:
				return functionPrototype != null && !functionPrototype.isEmpty();
			case Eastadl22Package.BEHAVIOR_CONSTRAINT_INTERNAL_BINDING_BINDING_THROUGH_FUNCTION_CONNECTOR__FUNCTION_CONNECTOR:
				return functionConnector != null;
		}
		return super.eIsSet(featureID);
	}

} //BehaviorConstraintInternalBinding_bindingThroughFunctionConnectorImpl
