/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.EventFunctionClientServerPort_port;
import org.eclipse.eatop.eastadl22.FunctionClientServerPort;
import org.eclipse.eatop.eastadl22.FunctionPrototype;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.eclipse.sphinx.emf.ecore.ExtendedEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Function Client Server Port port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.EventFunctionClientServerPort_portImpl#getFunctionClientServerPort <em>Function Client Server Port</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.EventFunctionClientServerPort_portImpl#getFunctionPrototype <em>Function Prototype</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EventFunctionClientServerPort_portImpl extends ExtendedEObjectImpl implements EventFunctionClientServerPort_port {
	/**
	 * The cached value of the '{@link #getFunctionClientServerPort() <em>Function Client Server Port</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionClientServerPort()
	 * @generated
	 * @ordered
	 */
	protected FunctionClientServerPort functionClientServerPort;

	/**
	 * The cached value of the '{@link #getFunctionPrototype() <em>Function Prototype</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionPrototype()
	 * @generated
	 * @ordered
	 */
	protected EList<FunctionPrototype> functionPrototype;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventFunctionClientServerPort_portImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getEventFunctionClientServerPort_port();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionClientServerPort getFunctionClientServerPort() {
		if (functionClientServerPort != null && functionClientServerPort.eIsProxy()) {
			InternalEObject oldFunctionClientServerPort = (InternalEObject)functionClientServerPort;
			functionClientServerPort = (FunctionClientServerPort)eResolveProxy(oldFunctionClientServerPort);
			if (functionClientServerPort != oldFunctionClientServerPort) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_CLIENT_SERVER_PORT, oldFunctionClientServerPort, functionClientServerPort));
			}
		}
		return functionClientServerPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionClientServerPort basicGetFunctionClientServerPort() {
		return functionClientServerPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFunctionClientServerPort(FunctionClientServerPort newFunctionClientServerPort) {
		FunctionClientServerPort oldFunctionClientServerPort = functionClientServerPort;
		functionClientServerPort = newFunctionClientServerPort;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_CLIENT_SERVER_PORT, oldFunctionClientServerPort, functionClientServerPort));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FunctionPrototype> getFunctionPrototype() {
		if (functionPrototype == null) {
			functionPrototype = new EObjectResolvingEList<FunctionPrototype>(FunctionPrototype.class, this, Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_PROTOTYPE);
		}
		return functionPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_CLIENT_SERVER_PORT:
				if (resolve) return getFunctionClientServerPort();
				return basicGetFunctionClientServerPort();
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_PROTOTYPE:
				return getFunctionPrototype();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_CLIENT_SERVER_PORT:
   			setFunctionClientServerPort((FunctionClientServerPort)newValue);
				return;
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_PROTOTYPE:
				getFunctionPrototype().clear();
				getFunctionPrototype().addAll((Collection<? extends FunctionPrototype>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_CLIENT_SERVER_PORT:
		    	setFunctionClientServerPort((FunctionClientServerPort)null);
				return;
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_PROTOTYPE:
				getFunctionPrototype().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_CLIENT_SERVER_PORT:
				return functionClientServerPort != null;
			case Eastadl22Package.EVENT_FUNCTION_CLIENT_SERVER_PORT_PORT__FUNCTION_PROTOTYPE:
				return functionPrototype != null && !functionPrototype.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //EventFunctionClientServerPort_portImpl
