/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Dependability;
import org.eclipse.eatop.eastadl22.EADatatype;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.ErrorModelType;
import org.eclipse.eatop.eastadl22.FaultFailure;
import org.eclipse.eatop.eastadl22.FeatureFlaw;
import org.eclipse.eatop.eastadl22.FunctionalSafetyConcept;
import org.eclipse.eatop.eastadl22.Hazard;
import org.eclipse.eatop.eastadl22.HazardousEvent;
import org.eclipse.eatop.eastadl22.Item;
import org.eclipse.eatop.eastadl22.QuantitativeSafetyConstraint;
import org.eclipse.eatop.eastadl22.SafetyCase;
import org.eclipse.eatop.eastadl22.SafetyConstraint;
import org.eclipse.eatop.eastadl22.SafetyGoal;
import org.eclipse.eatop.eastadl22.TechnicalSafetyConcept;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dependability</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getHazardousEvent <em>Hazardous Event</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getSafetyConstraint <em>Safety Constraint</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getSafetyGoal <em>Safety Goal</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getItem <em>Item</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getFeatureFlaw <em>Feature Flaw</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getErrorModelType <em>Error Model Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getFaultFailure <em>Fault Failure</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getFunctionalSafetyConcept <em>Functional Safety Concept</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getHazard <em>Hazard</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getQuantitativeSafetyConstraint <em>Quantitative Safety Constraint</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getSafetyCase <em>Safety Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getEaDatatype <em>Ea Datatype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.DependabilityImpl#getTechnicalSafetyConcept <em>Technical Safety Concept</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class DependabilityImpl extends ContextImpl implements Dependability {
	/**
	 * The cached value of the '{@link #getHazardousEvent() <em>Hazardous Event</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHazardousEvent()
	 * @generated
	 * @ordered
	 */
	protected EList<HazardousEvent> hazardousEvent;

	/**
	 * The cached value of the '{@link #getSafetyConstraint() <em>Safety Constraint</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSafetyConstraint()
	 * @generated
	 * @ordered
	 */
	protected EList<SafetyConstraint> safetyConstraint;

	/**
	 * The cached value of the '{@link #getSafetyGoal() <em>Safety Goal</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSafetyGoal()
	 * @generated
	 * @ordered
	 */
	protected EList<SafetyGoal> safetyGoal;

	/**
	 * The cached value of the '{@link #getItem() <em>Item</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getItem()
	 * @generated
	 * @ordered
	 */
	protected EList<Item> item;

	/**
	 * The cached value of the '{@link #getFeatureFlaw() <em>Feature Flaw</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFeatureFlaw()
	 * @generated
	 * @ordered
	 */
	protected EList<FeatureFlaw> featureFlaw;

	/**
	 * The cached value of the '{@link #getErrorModelType() <em>Error Model Type</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getErrorModelType()
	 * @generated
	 * @ordered
	 */
	protected EList<ErrorModelType> errorModelType;

	/**
	 * The cached value of the '{@link #getFaultFailure() <em>Fault Failure</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFaultFailure()
	 * @generated
	 * @ordered
	 */
	protected EList<FaultFailure> faultFailure;

	/**
	 * The cached value of the '{@link #getFunctionalSafetyConcept() <em>Functional Safety Concept</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionalSafetyConcept()
	 * @generated
	 * @ordered
	 */
	protected EList<FunctionalSafetyConcept> functionalSafetyConcept;

	/**
	 * The cached value of the '{@link #getHazard() <em>Hazard</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHazard()
	 * @generated
	 * @ordered
	 */
	protected EList<Hazard> hazard;

	/**
	 * The cached value of the '{@link #getQuantitativeSafetyConstraint() <em>Quantitative Safety Constraint</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQuantitativeSafetyConstraint()
	 * @generated
	 * @ordered
	 */
	protected EList<QuantitativeSafetyConstraint> quantitativeSafetyConstraint;

	/**
	 * The cached value of the '{@link #getSafetyCase() <em>Safety Case</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSafetyCase()
	 * @generated
	 * @ordered
	 */
	protected EList<SafetyCase> safetyCase;

	/**
	 * The cached value of the '{@link #getEaDatatype() <em>Ea Datatype</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEaDatatype()
	 * @generated
	 * @ordered
	 */
	protected EList<EADatatype> eaDatatype;

	/**
	 * The cached value of the '{@link #getTechnicalSafetyConcept() <em>Technical Safety Concept</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTechnicalSafetyConcept()
	 * @generated
	 * @ordered
	 */
	protected EList<TechnicalSafetyConcept> technicalSafetyConcept;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DependabilityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getDependability();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<HazardousEvent> getHazardousEvent() {
		if (hazardousEvent == null) {
			hazardousEvent = new EObjectContainmentEList<HazardousEvent>(HazardousEvent.class, this, Eastadl22Package.DEPENDABILITY__HAZARDOUS_EVENT);
		}
		return hazardousEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SafetyConstraint> getSafetyConstraint() {
		if (safetyConstraint == null) {
			safetyConstraint = new EObjectContainmentEList<SafetyConstraint>(SafetyConstraint.class, this, Eastadl22Package.DEPENDABILITY__SAFETY_CONSTRAINT);
		}
		return safetyConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SafetyGoal> getSafetyGoal() {
		if (safetyGoal == null) {
			safetyGoal = new EObjectContainmentEList<SafetyGoal>(SafetyGoal.class, this, Eastadl22Package.DEPENDABILITY__SAFETY_GOAL);
		}
		return safetyGoal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Item> getItem() {
		if (item == null) {
			item = new EObjectContainmentEList<Item>(Item.class, this, Eastadl22Package.DEPENDABILITY__ITEM);
		}
		return item;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FeatureFlaw> getFeatureFlaw() {
		if (featureFlaw == null) {
			featureFlaw = new EObjectContainmentEList<FeatureFlaw>(FeatureFlaw.class, this, Eastadl22Package.DEPENDABILITY__FEATURE_FLAW);
		}
		return featureFlaw;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ErrorModelType> getErrorModelType() {
		if (errorModelType == null) {
			errorModelType = new EObjectContainmentEList<ErrorModelType>(ErrorModelType.class, this, Eastadl22Package.DEPENDABILITY__ERROR_MODEL_TYPE);
		}
		return errorModelType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FaultFailure> getFaultFailure() {
		if (faultFailure == null) {
			faultFailure = new EObjectContainmentEList<FaultFailure>(FaultFailure.class, this, Eastadl22Package.DEPENDABILITY__FAULT_FAILURE);
		}
		return faultFailure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FunctionalSafetyConcept> getFunctionalSafetyConcept() {
		if (functionalSafetyConcept == null) {
			functionalSafetyConcept = new EObjectContainmentEList<FunctionalSafetyConcept>(FunctionalSafetyConcept.class, this, Eastadl22Package.DEPENDABILITY__FUNCTIONAL_SAFETY_CONCEPT);
		}
		return functionalSafetyConcept;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Hazard> getHazard() {
		if (hazard == null) {
			hazard = new EObjectContainmentEList<Hazard>(Hazard.class, this, Eastadl22Package.DEPENDABILITY__HAZARD);
		}
		return hazard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<QuantitativeSafetyConstraint> getQuantitativeSafetyConstraint() {
		if (quantitativeSafetyConstraint == null) {
			quantitativeSafetyConstraint = new EObjectContainmentEList<QuantitativeSafetyConstraint>(QuantitativeSafetyConstraint.class, this, Eastadl22Package.DEPENDABILITY__QUANTITATIVE_SAFETY_CONSTRAINT);
		}
		return quantitativeSafetyConstraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SafetyCase> getSafetyCase() {
		if (safetyCase == null) {
			safetyCase = new EObjectContainmentEList<SafetyCase>(SafetyCase.class, this, Eastadl22Package.DEPENDABILITY__SAFETY_CASE);
		}
		return safetyCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EADatatype> getEaDatatype() {
		if (eaDatatype == null) {
			eaDatatype = new EObjectContainmentEList<EADatatype>(EADatatype.class, this, Eastadl22Package.DEPENDABILITY__EA_DATATYPE);
		}
		return eaDatatype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TechnicalSafetyConcept> getTechnicalSafetyConcept() {
		if (technicalSafetyConcept == null) {
			technicalSafetyConcept = new EObjectContainmentEList<TechnicalSafetyConcept>(TechnicalSafetyConcept.class, this, Eastadl22Package.DEPENDABILITY__TECHNICAL_SAFETY_CONCEPT);
		}
		return technicalSafetyConcept;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.DEPENDABILITY__HAZARDOUS_EVENT:
				return ((InternalEList<?>)getHazardousEvent()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__SAFETY_CONSTRAINT:
				return ((InternalEList<?>)getSafetyConstraint()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__SAFETY_GOAL:
				return ((InternalEList<?>)getSafetyGoal()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__ITEM:
				return ((InternalEList<?>)getItem()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__FEATURE_FLAW:
				return ((InternalEList<?>)getFeatureFlaw()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__ERROR_MODEL_TYPE:
				return ((InternalEList<?>)getErrorModelType()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__FAULT_FAILURE:
				return ((InternalEList<?>)getFaultFailure()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__FUNCTIONAL_SAFETY_CONCEPT:
				return ((InternalEList<?>)getFunctionalSafetyConcept()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__HAZARD:
				return ((InternalEList<?>)getHazard()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__QUANTITATIVE_SAFETY_CONSTRAINT:
				return ((InternalEList<?>)getQuantitativeSafetyConstraint()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__SAFETY_CASE:
				return ((InternalEList<?>)getSafetyCase()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__EA_DATATYPE:
				return ((InternalEList<?>)getEaDatatype()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.DEPENDABILITY__TECHNICAL_SAFETY_CONCEPT:
				return ((InternalEList<?>)getTechnicalSafetyConcept()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.DEPENDABILITY__HAZARDOUS_EVENT:
				return getHazardousEvent();
			case Eastadl22Package.DEPENDABILITY__SAFETY_CONSTRAINT:
				return getSafetyConstraint();
			case Eastadl22Package.DEPENDABILITY__SAFETY_GOAL:
				return getSafetyGoal();
			case Eastadl22Package.DEPENDABILITY__ITEM:
				return getItem();
			case Eastadl22Package.DEPENDABILITY__FEATURE_FLAW:
				return getFeatureFlaw();
			case Eastadl22Package.DEPENDABILITY__ERROR_MODEL_TYPE:
				return getErrorModelType();
			case Eastadl22Package.DEPENDABILITY__FAULT_FAILURE:
				return getFaultFailure();
			case Eastadl22Package.DEPENDABILITY__FUNCTIONAL_SAFETY_CONCEPT:
				return getFunctionalSafetyConcept();
			case Eastadl22Package.DEPENDABILITY__HAZARD:
				return getHazard();
			case Eastadl22Package.DEPENDABILITY__QUANTITATIVE_SAFETY_CONSTRAINT:
				return getQuantitativeSafetyConstraint();
			case Eastadl22Package.DEPENDABILITY__SAFETY_CASE:
				return getSafetyCase();
			case Eastadl22Package.DEPENDABILITY__EA_DATATYPE:
				return getEaDatatype();
			case Eastadl22Package.DEPENDABILITY__TECHNICAL_SAFETY_CONCEPT:
				return getTechnicalSafetyConcept();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.DEPENDABILITY__HAZARDOUS_EVENT:
				getHazardousEvent().clear();
				getHazardousEvent().addAll((Collection<? extends HazardousEvent>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__SAFETY_CONSTRAINT:
				getSafetyConstraint().clear();
				getSafetyConstraint().addAll((Collection<? extends SafetyConstraint>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__SAFETY_GOAL:
				getSafetyGoal().clear();
				getSafetyGoal().addAll((Collection<? extends SafetyGoal>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__ITEM:
				getItem().clear();
				getItem().addAll((Collection<? extends Item>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__FEATURE_FLAW:
				getFeatureFlaw().clear();
				getFeatureFlaw().addAll((Collection<? extends FeatureFlaw>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__ERROR_MODEL_TYPE:
				getErrorModelType().clear();
				getErrorModelType().addAll((Collection<? extends ErrorModelType>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__FAULT_FAILURE:
				getFaultFailure().clear();
				getFaultFailure().addAll((Collection<? extends FaultFailure>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__FUNCTIONAL_SAFETY_CONCEPT:
				getFunctionalSafetyConcept().clear();
				getFunctionalSafetyConcept().addAll((Collection<? extends FunctionalSafetyConcept>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__HAZARD:
				getHazard().clear();
				getHazard().addAll((Collection<? extends Hazard>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__QUANTITATIVE_SAFETY_CONSTRAINT:
				getQuantitativeSafetyConstraint().clear();
				getQuantitativeSafetyConstraint().addAll((Collection<? extends QuantitativeSafetyConstraint>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__SAFETY_CASE:
				getSafetyCase().clear();
				getSafetyCase().addAll((Collection<? extends SafetyCase>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__EA_DATATYPE:
				getEaDatatype().clear();
				getEaDatatype().addAll((Collection<? extends EADatatype>)newValue);
				return;
			case Eastadl22Package.DEPENDABILITY__TECHNICAL_SAFETY_CONCEPT:
				getTechnicalSafetyConcept().clear();
				getTechnicalSafetyConcept().addAll((Collection<? extends TechnicalSafetyConcept>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.DEPENDABILITY__HAZARDOUS_EVENT:
				getHazardousEvent().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__SAFETY_CONSTRAINT:
				getSafetyConstraint().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__SAFETY_GOAL:
				getSafetyGoal().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__ITEM:
				getItem().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__FEATURE_FLAW:
				getFeatureFlaw().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__ERROR_MODEL_TYPE:
				getErrorModelType().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__FAULT_FAILURE:
				getFaultFailure().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__FUNCTIONAL_SAFETY_CONCEPT:
				getFunctionalSafetyConcept().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__HAZARD:
				getHazard().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__QUANTITATIVE_SAFETY_CONSTRAINT:
				getQuantitativeSafetyConstraint().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__SAFETY_CASE:
				getSafetyCase().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__EA_DATATYPE:
				getEaDatatype().clear();
				return;
			case Eastadl22Package.DEPENDABILITY__TECHNICAL_SAFETY_CONCEPT:
				getTechnicalSafetyConcept().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.DEPENDABILITY__HAZARDOUS_EVENT:
				return hazardousEvent != null && !hazardousEvent.isEmpty();
			case Eastadl22Package.DEPENDABILITY__SAFETY_CONSTRAINT:
				return safetyConstraint != null && !safetyConstraint.isEmpty();
			case Eastadl22Package.DEPENDABILITY__SAFETY_GOAL:
				return safetyGoal != null && !safetyGoal.isEmpty();
			case Eastadl22Package.DEPENDABILITY__ITEM:
				return item != null && !item.isEmpty();
			case Eastadl22Package.DEPENDABILITY__FEATURE_FLAW:
				return featureFlaw != null && !featureFlaw.isEmpty();
			case Eastadl22Package.DEPENDABILITY__ERROR_MODEL_TYPE:
				return errorModelType != null && !errorModelType.isEmpty();
			case Eastadl22Package.DEPENDABILITY__FAULT_FAILURE:
				return faultFailure != null && !faultFailure.isEmpty();
			case Eastadl22Package.DEPENDABILITY__FUNCTIONAL_SAFETY_CONCEPT:
				return functionalSafetyConcept != null && !functionalSafetyConcept.isEmpty();
			case Eastadl22Package.DEPENDABILITY__HAZARD:
				return hazard != null && !hazard.isEmpty();
			case Eastadl22Package.DEPENDABILITY__QUANTITATIVE_SAFETY_CONSTRAINT:
				return quantitativeSafetyConstraint != null && !quantitativeSafetyConstraint.isEmpty();
			case Eastadl22Package.DEPENDABILITY__SAFETY_CASE:
				return safetyCase != null && !safetyCase.isEmpty();
			case Eastadl22Package.DEPENDABILITY__EA_DATATYPE:
				return eaDatatype != null && !eaDatatype.isEmpty();
			case Eastadl22Package.DEPENDABILITY__TECHNICAL_SAFETY_CONCEPT:
				return technicalSafetyConcept != null && !technicalSafetyConcept.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //DependabilityImpl
