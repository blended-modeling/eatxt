/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.ComputationConstraint;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.LogicalPath;
import org.eclipse.eatop.eastadl22.LogicalTransformation;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Computation Constraint</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ComputationConstraintImpl#getLogicalPath <em>Logical Path</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ComputationConstraintImpl#getLogicalTransformation <em>Logical Transformation</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ComputationConstraintImpl extends EAElementImpl implements ComputationConstraint {
	/**
	 * The cached value of the '{@link #getLogicalPath() <em>Logical Path</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLogicalPath()
	 * @generated
	 * @ordered
	 */
	protected EList<LogicalPath> logicalPath;

	/**
	 * The cached value of the '{@link #getLogicalTransformation() <em>Logical Transformation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLogicalTransformation()
	 * @generated
	 * @ordered
	 */
	protected EList<LogicalTransformation> logicalTransformation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComputationConstraintImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getComputationConstraint();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<LogicalPath> getLogicalPath() {
		if (logicalPath == null) {
			logicalPath = new EObjectContainmentEList<LogicalPath>(LogicalPath.class, this, Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_PATH);
		}
		return logicalPath;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<LogicalTransformation> getLogicalTransformation() {
		if (logicalTransformation == null) {
			logicalTransformation = new EObjectContainmentEList<LogicalTransformation>(LogicalTransformation.class, this, Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_TRANSFORMATION);
		}
		return logicalTransformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_PATH:
				return ((InternalEList<?>)getLogicalPath()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_TRANSFORMATION:
				return ((InternalEList<?>)getLogicalTransformation()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_PATH:
				return getLogicalPath();
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_TRANSFORMATION:
				return getLogicalTransformation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_PATH:
				getLogicalPath().clear();
				getLogicalPath().addAll((Collection<? extends LogicalPath>)newValue);
				return;
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_TRANSFORMATION:
				getLogicalTransformation().clear();
				getLogicalTransformation().addAll((Collection<? extends LogicalTransformation>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_PATH:
				getLogicalPath().clear();
				return;
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_TRANSFORMATION:
				getLogicalTransformation().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_PATH:
				return logicalPath != null && !logicalPath.isEmpty();
			case Eastadl22Package.COMPUTATION_CONSTRAINT__LOGICAL_TRANSFORMATION:
				return logicalTransformation != null && !logicalTransformation.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ComputationConstraintImpl
