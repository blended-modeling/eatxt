/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.Requirement;
import org.eclipse.eatop.eastadl22.RequirementsHierarchy;
import org.eclipse.eatop.eastadl22.RequirementsModel;
import org.eclipse.eatop.eastadl22.RequirementsRelationshipGroup;
import org.eclipse.eatop.eastadl22.Situation;
import org.eclipse.eatop.eastadl22.UseCase;
import org.eclipse.eatop.eastadl22.UserElementType;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Requirements Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.RequirementsModelImpl#getUseCase <em>Use Case</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.RequirementsModelImpl#getOperationalSituation <em>Operational Situation</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.RequirementsModelImpl#getRequirementsHierarchy <em>Requirements Hierarchy</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.RequirementsModelImpl#getRequirement <em>Requirement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.RequirementsModelImpl#getRequirementsRelationshipGroup <em>Requirements Relationship Group</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.RequirementsModelImpl#getRequirementType <em>Requirement Type</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RequirementsModelImpl extends ContextImpl implements RequirementsModel {
	/**
	 * The cached value of the '{@link #getUseCase() <em>Use Case</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUseCase()
	 * @generated
	 * @ordered
	 */
	protected EList<UseCase> useCase;

	/**
	 * The cached value of the '{@link #getOperationalSituation() <em>Operational Situation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperationalSituation()
	 * @generated
	 * @ordered
	 */
	protected EList<Situation> operationalSituation;

	/**
	 * The cached value of the '{@link #getRequirementsHierarchy() <em>Requirements Hierarchy</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequirementsHierarchy()
	 * @generated
	 * @ordered
	 */
	protected EList<RequirementsHierarchy> requirementsHierarchy;

	/**
	 * The cached value of the '{@link #getRequirement() <em>Requirement</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequirement()
	 * @generated
	 * @ordered
	 */
	protected EList<Requirement> requirement;

	/**
	 * The cached value of the '{@link #getRequirementsRelationshipGroup() <em>Requirements Relationship Group</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequirementsRelationshipGroup()
	 * @generated
	 * @ordered
	 */
	protected EList<RequirementsRelationshipGroup> requirementsRelationshipGroup;

	/**
	 * The cached value of the '{@link #getRequirementType() <em>Requirement Type</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequirementType()
	 * @generated
	 * @ordered
	 */
	protected EList<UserElementType> requirementType;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RequirementsModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getRequirementsModel();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<UseCase> getUseCase() {
		if (useCase == null) {
			useCase = new EObjectContainmentEList<UseCase>(UseCase.class, this, Eastadl22Package.REQUIREMENTS_MODEL__USE_CASE);
		}
		return useCase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Situation> getOperationalSituation() {
		if (operationalSituation == null) {
			operationalSituation = new EObjectContainmentEList<Situation>(Situation.class, this, Eastadl22Package.REQUIREMENTS_MODEL__OPERATIONAL_SITUATION);
		}
		return operationalSituation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RequirementsHierarchy> getRequirementsHierarchy() {
		if (requirementsHierarchy == null) {
			requirementsHierarchy = new EObjectContainmentEList<RequirementsHierarchy>(RequirementsHierarchy.class, this, Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_HIERARCHY);
		}
		return requirementsHierarchy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Requirement> getRequirement() {
		if (requirement == null) {
			requirement = new EObjectContainmentEList<Requirement>(Requirement.class, this, Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT);
		}
		return requirement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RequirementsRelationshipGroup> getRequirementsRelationshipGroup() {
		if (requirementsRelationshipGroup == null) {
			requirementsRelationshipGroup = new EObjectContainmentEList<RequirementsRelationshipGroup>(RequirementsRelationshipGroup.class, this, Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_RELATIONSHIP_GROUP);
		}
		return requirementsRelationshipGroup;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<UserElementType> getRequirementType() {
		if (requirementType == null) {
			requirementType = new EObjectContainmentEList<UserElementType>(UserElementType.class, this, Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT_TYPE);
		}
		return requirementType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_MODEL__USE_CASE:
				return ((InternalEList<?>)getUseCase()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.REQUIREMENTS_MODEL__OPERATIONAL_SITUATION:
				return ((InternalEList<?>)getOperationalSituation()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_HIERARCHY:
				return ((InternalEList<?>)getRequirementsHierarchy()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT:
				return ((InternalEList<?>)getRequirement()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_RELATIONSHIP_GROUP:
				return ((InternalEList<?>)getRequirementsRelationshipGroup()).basicRemove(otherEnd, msgs);
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT_TYPE:
				return ((InternalEList<?>)getRequirementType()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_MODEL__USE_CASE:
				return getUseCase();
			case Eastadl22Package.REQUIREMENTS_MODEL__OPERATIONAL_SITUATION:
				return getOperationalSituation();
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_HIERARCHY:
				return getRequirementsHierarchy();
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT:
				return getRequirement();
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_RELATIONSHIP_GROUP:
				return getRequirementsRelationshipGroup();
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT_TYPE:
				return getRequirementType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_MODEL__USE_CASE:
				getUseCase().clear();
				getUseCase().addAll((Collection<? extends UseCase>)newValue);
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__OPERATIONAL_SITUATION:
				getOperationalSituation().clear();
				getOperationalSituation().addAll((Collection<? extends Situation>)newValue);
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_HIERARCHY:
				getRequirementsHierarchy().clear();
				getRequirementsHierarchy().addAll((Collection<? extends RequirementsHierarchy>)newValue);
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT:
				getRequirement().clear();
				getRequirement().addAll((Collection<? extends Requirement>)newValue);
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_RELATIONSHIP_GROUP:
				getRequirementsRelationshipGroup().clear();
				getRequirementsRelationshipGroup().addAll((Collection<? extends RequirementsRelationshipGroup>)newValue);
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT_TYPE:
				getRequirementType().clear();
				getRequirementType().addAll((Collection<? extends UserElementType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_MODEL__USE_CASE:
				getUseCase().clear();
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__OPERATIONAL_SITUATION:
				getOperationalSituation().clear();
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_HIERARCHY:
				getRequirementsHierarchy().clear();
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT:
				getRequirement().clear();
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_RELATIONSHIP_GROUP:
				getRequirementsRelationshipGroup().clear();
				return;
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT_TYPE:
				getRequirementType().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.REQUIREMENTS_MODEL__USE_CASE:
				return useCase != null && !useCase.isEmpty();
			case Eastadl22Package.REQUIREMENTS_MODEL__OPERATIONAL_SITUATION:
				return operationalSituation != null && !operationalSituation.isEmpty();
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_HIERARCHY:
				return requirementsHierarchy != null && !requirementsHierarchy.isEmpty();
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT:
				return requirement != null && !requirement.isEmpty();
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENTS_RELATIONSHIP_GROUP:
				return requirementsRelationshipGroup != null && !requirementsRelationshipGroup.isEmpty();
			case Eastadl22Package.REQUIREMENTS_MODEL__REQUIREMENT_TYPE:
				return requirementType != null && !requirementType.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //RequirementsModelImpl
