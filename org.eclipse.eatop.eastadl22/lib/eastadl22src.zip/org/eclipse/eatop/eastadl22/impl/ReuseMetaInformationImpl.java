/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.ReuseMetaInformation;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Reuse Meta Information</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ReuseMetaInformationImpl#getInformation <em>Information</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.ReuseMetaInformationImpl#getIsReusable <em>Is Reusable</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ReuseMetaInformationImpl extends TraceableSpecificationImpl implements ReuseMetaInformation {
	/**
	 * The default value of the '{@link #getInformation() <em>Information</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformation()
	 * @generated
	 * @ordered
	 */
	protected static final String INFORMATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInformation() <em>Information</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformation()
	 * @generated
	 * @ordered
	 */
	protected String information = INFORMATION_EDEFAULT;

	/**
	 * This is true if the Information attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean informationESet;

	/**
	 * The default value of the '{@link #getIsReusable() <em>Is Reusable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsReusable()
	 * @generated
	 * @ordered
	 */
	protected static final Boolean IS_REUSABLE_EDEFAULT = Boolean.FALSE;

	/**
	 * The cached value of the '{@link #getIsReusable() <em>Is Reusable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsReusable()
	 * @generated
	 * @ordered
	 */
	protected Boolean isReusable = IS_REUSABLE_EDEFAULT;

	/**
	 * This is true if the Is Reusable attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean isReusableESet;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ReuseMetaInformationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getReuseMetaInformation();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInformation() {
		return information;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInformation(String newInformation) {
		String oldInformation = information;
		information = newInformation;
		boolean oldInformationESet = informationESet;
		informationESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.REUSE_META_INFORMATION__INFORMATION, oldInformation, information, !oldInformationESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetInformation() {
		String oldInformation = information;
		boolean oldInformationESet = informationESet;
		information = INFORMATION_EDEFAULT;
		informationESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.REUSE_META_INFORMATION__INFORMATION, oldInformation, INFORMATION_EDEFAULT, oldInformationESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetInformation() {
		return informationESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean getIsReusable() {
		return isReusable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsReusable(Boolean newIsReusable) {
		Boolean oldIsReusable = isReusable;
		isReusable = newIsReusable;
		boolean oldIsReusableESet = isReusableESet;
		isReusableESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.REUSE_META_INFORMATION__IS_REUSABLE, oldIsReusable, isReusable, !oldIsReusableESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetIsReusable() {
		Boolean oldIsReusable = isReusable;
		boolean oldIsReusableESet = isReusableESet;
		isReusable = IS_REUSABLE_EDEFAULT;
		isReusableESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.REUSE_META_INFORMATION__IS_REUSABLE, oldIsReusable, IS_REUSABLE_EDEFAULT, oldIsReusableESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetIsReusable() {
		return isReusableESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.REUSE_META_INFORMATION__INFORMATION:
				return getInformation();
			case Eastadl22Package.REUSE_META_INFORMATION__IS_REUSABLE:
				return getIsReusable();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.REUSE_META_INFORMATION__INFORMATION:
   			setInformation((String)newValue);
				return;
			case Eastadl22Package.REUSE_META_INFORMATION__IS_REUSABLE:
   			setIsReusable((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.REUSE_META_INFORMATION__INFORMATION:
				unsetInformation();
				return;
			case Eastadl22Package.REUSE_META_INFORMATION__IS_REUSABLE:
				unsetIsReusable();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.REUSE_META_INFORMATION__INFORMATION:
				return isSetInformation();
			case Eastadl22Package.REUSE_META_INFORMATION__IS_REUSABLE:
				return isSetIsReusable();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (information: ");
		if (informationESet) result.append(information); else result.append("<unset>");
		result.append(", isReusable: ");
		if (isReusableESet) result.append(isReusable); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //ReuseMetaInformationImpl
