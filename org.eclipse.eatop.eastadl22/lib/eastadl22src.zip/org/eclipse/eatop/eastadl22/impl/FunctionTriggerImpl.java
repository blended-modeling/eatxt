/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22.impl;

import java.util.Collection;

import org.eclipse.eatop.eastadl22.EADatatype;
import org.eclipse.eatop.eastadl22.EAExpression;
import org.eclipse.eatop.eastadl22.EAValue;
import org.eclipse.eatop.eastadl22.Eastadl22Package;
import org.eclipse.eatop.eastadl22.FunctionPort;
import org.eclipse.eatop.eastadl22.FunctionPrototype;
import org.eclipse.eatop.eastadl22.FunctionTrigger;
import org.eclipse.eatop.eastadl22.FunctionType;
import org.eclipse.eatop.eastadl22.Mode;
import org.eclipse.eatop.eastadl22.TriggerPolicyKind;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Function Trigger</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FunctionTriggerImpl#getType <em>Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FunctionTriggerImpl#getValue <em>Value</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FunctionTriggerImpl#getTriggerPolicy <em>Trigger Policy</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FunctionTriggerImpl#getMode <em>Mode</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FunctionTriggerImpl#getFunctionPrototype <em>Function Prototype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FunctionTriggerImpl#getFunction <em>Function</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.impl.FunctionTriggerImpl#getPort <em>Port</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FunctionTriggerImpl extends EAElementImpl implements FunctionTrigger {
	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected EADatatype type;

	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected EList<EAValue> value;

	/**
	 * The default value of the '{@link #getTriggerPolicy() <em>Trigger Policy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTriggerPolicy()
	 * @generated
	 * @ordered
	 */
	protected static final TriggerPolicyKind TRIGGER_POLICY_EDEFAULT = TriggerPolicyKind.EVENT;

	/**
	 * The cached value of the '{@link #getTriggerPolicy() <em>Trigger Policy</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTriggerPolicy()
	 * @generated
	 * @ordered
	 */
	protected TriggerPolicyKind triggerPolicy = TRIGGER_POLICY_EDEFAULT;

	/**
	 * This is true if the Trigger Policy attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean triggerPolicyESet;

	/**
	 * The cached value of the '{@link #getMode() <em>Mode</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMode()
	 * @generated
	 * @ordered
	 */
	protected EList<Mode> mode;

	/**
	 * The cached value of the '{@link #getFunctionPrototype() <em>Function Prototype</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionPrototype()
	 * @generated
	 * @ordered
	 */
	protected FunctionPrototype functionPrototype;

	/**
	 * The cached value of the '{@link #getFunction() <em>Function</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunction()
	 * @generated
	 * @ordered
	 */
	protected FunctionType function;

	/**
	 * The cached value of the '{@link #getPort() <em>Port</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPort()
	 * @generated
	 * @ordered
	 */
	protected EList<FunctionPort> port;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FunctionTriggerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Eastadl22Package.eINSTANCE.getFunctionTrigger();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EADatatype getType() {
		if (type != null && type.eIsProxy()) {
			InternalEObject oldType = (InternalEObject)type;
			type = (EADatatype)eResolveProxy(oldType);
			if (type != oldType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.FUNCTION_TRIGGER__TYPE, oldType, type));
			}
		}
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EADatatype basicGetType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(EADatatype newType) {
		EADatatype oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FUNCTION_TRIGGER__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EAValue> getValue() {
		if (value == null) {
			value = new EObjectContainmentEList<EAValue>(EAValue.class, this, Eastadl22Package.FUNCTION_TRIGGER__VALUE);
		}
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TriggerPolicyKind getTriggerPolicy() {
		return triggerPolicy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTriggerPolicy(TriggerPolicyKind newTriggerPolicy) {
		TriggerPolicyKind oldTriggerPolicy = triggerPolicy;
		triggerPolicy = newTriggerPolicy == null ? TRIGGER_POLICY_EDEFAULT : newTriggerPolicy;
		boolean oldTriggerPolicyESet = triggerPolicyESet;
		triggerPolicyESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FUNCTION_TRIGGER__TRIGGER_POLICY, oldTriggerPolicy, triggerPolicy, !oldTriggerPolicyESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetTriggerPolicy() {
		TriggerPolicyKind oldTriggerPolicy = triggerPolicy;
		boolean oldTriggerPolicyESet = triggerPolicyESet;
		triggerPolicy = TRIGGER_POLICY_EDEFAULT;
		triggerPolicyESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, Eastadl22Package.FUNCTION_TRIGGER__TRIGGER_POLICY, oldTriggerPolicy, TRIGGER_POLICY_EDEFAULT, oldTriggerPolicyESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetTriggerPolicy() {
		return triggerPolicyESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Mode> getMode() {
		if (mode == null) {
			mode = new EObjectResolvingEList<Mode>(Mode.class, this, Eastadl22Package.FUNCTION_TRIGGER__MODE);
		}
		return mode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionPrototype getFunctionPrototype() {
		if (functionPrototype != null && functionPrototype.eIsProxy()) {
			InternalEObject oldFunctionPrototype = (InternalEObject)functionPrototype;
			functionPrototype = (FunctionPrototype)eResolveProxy(oldFunctionPrototype);
			if (functionPrototype != oldFunctionPrototype) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.FUNCTION_TRIGGER__FUNCTION_PROTOTYPE, oldFunctionPrototype, functionPrototype));
			}
		}
		return functionPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionPrototype basicGetFunctionPrototype() {
		return functionPrototype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFunctionPrototype(FunctionPrototype newFunctionPrototype) {
		FunctionPrototype oldFunctionPrototype = functionPrototype;
		functionPrototype = newFunctionPrototype;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FUNCTION_TRIGGER__FUNCTION_PROTOTYPE, oldFunctionPrototype, functionPrototype));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionType getFunction() {
		if (function != null && function.eIsProxy()) {
			InternalEObject oldFunction = (InternalEObject)function;
			function = (FunctionType)eResolveProxy(oldFunction);
			if (function != oldFunction) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Eastadl22Package.FUNCTION_TRIGGER__FUNCTION, oldFunction, function));
			}
		}
		return function;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionType basicGetFunction() {
		return function;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFunction(FunctionType newFunction) {
		FunctionType oldFunction = function;
		function = newFunction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Eastadl22Package.FUNCTION_TRIGGER__FUNCTION, oldFunction, function));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FunctionPort> getPort() {
		if (port == null) {
			port = new EObjectResolvingEList<FunctionPort>(FunctionPort.class, this, Eastadl22Package.FUNCTION_TRIGGER__PORT);
		}
		return port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Eastadl22Package.FUNCTION_TRIGGER__VALUE:
				return ((InternalEList<?>)getValue()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Eastadl22Package.FUNCTION_TRIGGER__TYPE:
				if (resolve) return getType();
				return basicGetType();
			case Eastadl22Package.FUNCTION_TRIGGER__VALUE:
				return getValue();
			case Eastadl22Package.FUNCTION_TRIGGER__TRIGGER_POLICY:
				return getTriggerPolicy();
			case Eastadl22Package.FUNCTION_TRIGGER__MODE:
				return getMode();
			case Eastadl22Package.FUNCTION_TRIGGER__FUNCTION_PROTOTYPE:
				if (resolve) return getFunctionPrototype();
				return basicGetFunctionPrototype();
			case Eastadl22Package.FUNCTION_TRIGGER__FUNCTION:
				if (resolve) return getFunction();
				return basicGetFunction();
			case Eastadl22Package.FUNCTION_TRIGGER__PORT:
				return getPort();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Eastadl22Package.FUNCTION_TRIGGER__TYPE:
   			setType((EADatatype)newValue);
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__VALUE:
				getValue().clear();
				getValue().addAll((Collection<? extends EAValue>)newValue);
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__TRIGGER_POLICY:
   			setTriggerPolicy((TriggerPolicyKind)newValue);
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__MODE:
				getMode().clear();
				getMode().addAll((Collection<? extends Mode>)newValue);
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__FUNCTION_PROTOTYPE:
   			setFunctionPrototype((FunctionPrototype)newValue);
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__FUNCTION:
   			setFunction((FunctionType)newValue);
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__PORT:
				getPort().clear();
				getPort().addAll((Collection<? extends FunctionPort>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FUNCTION_TRIGGER__TYPE:
		    	setType((EADatatype)null);
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__VALUE:
				getValue().clear();
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__TRIGGER_POLICY:
				unsetTriggerPolicy();
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__MODE:
				getMode().clear();
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__FUNCTION_PROTOTYPE:
		    	setFunctionPrototype((FunctionPrototype)null);
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__FUNCTION:
		    	setFunction((FunctionType)null);
				return;
			case Eastadl22Package.FUNCTION_TRIGGER__PORT:
				getPort().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Eastadl22Package.FUNCTION_TRIGGER__TYPE:
				return type != null;
			case Eastadl22Package.FUNCTION_TRIGGER__VALUE:
				return value != null && !value.isEmpty();
			case Eastadl22Package.FUNCTION_TRIGGER__TRIGGER_POLICY:
				return isSetTriggerPolicy();
			case Eastadl22Package.FUNCTION_TRIGGER__MODE:
				return mode != null && !mode.isEmpty();
			case Eastadl22Package.FUNCTION_TRIGGER__FUNCTION_PROTOTYPE:
				return functionPrototype != null;
			case Eastadl22Package.FUNCTION_TRIGGER__FUNCTION:
				return function != null;
			case Eastadl22Package.FUNCTION_TRIGGER__PORT:
				return port != null && !port.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == EAValue.class) {
			switch (derivedFeatureID) {
				case Eastadl22Package.FUNCTION_TRIGGER__TYPE: return Eastadl22Package.EA_VALUE__TYPE;
				default: return -1;
			}
		}
		if (baseClass == EAExpression.class) {
			switch (derivedFeatureID) {
				case Eastadl22Package.FUNCTION_TRIGGER__VALUE: return Eastadl22Package.EA_EXPRESSION__VALUE;
				default: return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == EAValue.class) {
			switch (baseFeatureID) {
				case Eastadl22Package.EA_VALUE__TYPE: return Eastadl22Package.FUNCTION_TRIGGER__TYPE;
				default: return -1;
			}
		}
		if (baseClass == EAExpression.class) {
			switch (baseFeatureID) {
				case Eastadl22Package.EA_EXPRESSION__VALUE: return Eastadl22Package.FUNCTION_TRIGGER__VALUE;
				default: return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (triggerPolicy: ");
		if (triggerPolicyESet) result.append(triggerPolicy); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //FunctionTriggerImpl
