/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Synchronization Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * An InputSynchronizationConstraint defines how far apart the responses that belong to a certain stimulus may occur.
 * 
 * This constraint provides an alternative to the ordinary SynchronizationConstraint for situations where the causal relation between event occurrences must be taken into account. It differs from the SynchronizationConstraint in that it applies to a set of event chains, and only looks at the stimulus occurrences that have the same color as each particular response occurrence. It is the latest of these stimulus occurrences for each chain that are required to lie no more than tolerance time units apart. If the roles of stimuli and responses are swapped, an OutputSynchronizationConstraint is obtained.
 * 
 * Constraints:
 * [1] All scopes must reference one common response event.
 * 
 * Semantics:
 * A system behavior satisfies an InputSynchronizationConstraint c if and only if
 * for each occurrence y in c.scope(1).response,
 * 	     there is a time t such that for each c.scope index i,
 * 		there is an occurrence x in c.scope(i).stimulus such that
 * 		      y.color = x.color
 * 		and
 * 		      x is maximal in c.scope(i).stimulus with that color
 * 		and
 * 		      0 &lt;= x - t &lt;= c.tolerance
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.InputSynchronizationConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.InputSynchronizationConstraint#getTolerance <em>Tolerance</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.InputSynchronizationConstraint#getScope <em>Scope</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getInputSynchronizationConstraint()
 * @model annotation="MetaData guid='{3E58F030-8188-459b-84A2-1FB2CAF1DE89}' id='165' EA\040name='InputSynchronizationConstraint'"
 *        extendedMetaData="name='INPUT-SYNCHRONIZATION-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='INPUT-SYNCHRONIZATION-CONSTRAINTS'"
 * @generated
 */
public interface InputSynchronizationConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Tolerance</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tolerance</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tolerance</em>' containment reference.
	 * @see #setTolerance(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getInputSynchronizationConstraint_Tolerance()
	 * @model containment="true"
	 *        annotation="MetaData guid='{8E3280C6-EA0D-4301-8CE4-9CF07AA1735D}' id='309' EA\040name=''"
	 *        extendedMetaData="name='TOLERANCE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TOLERANCES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getTolerance();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.InputSynchronizationConstraint#getTolerance <em>Tolerance</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tolerance</em>' containment reference.
	 * @see #getTolerance()
	 * @generated
	 */
	void setTolerance(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Scope</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.EventChain}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Scope</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Scope</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getInputSynchronizationConstraint_Scope()
	 * @model lower="2"
	 *        annotation="MetaData guid='{6CA45BA0-8F50-4d0f-9721-5AE80CF4F881}' id='354' EA\040name=''"
	 *        extendedMetaData="name='SCOPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SCOPE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<EventChain> getScope();

} // InputSynchronizationConstraint
