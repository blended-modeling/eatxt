/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Situation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A situation is a state, condition or scenario in the environment that may influence the vehicle. The Situation may be further detailed by a functional definition in the EnvironmentModel.
 * 
 * Semantics:
 * Situation represents a state, condition or scenario that is external to the vehicle.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.Situation</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getSituation()
 * @model annotation="MetaData guid='{F5996BF2-B9A3-4418-942B-B351BAD0CA5D}' id='118' EA\040name='Situation'"
 *        extendedMetaData="name='SITUATION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SITUATIONS'"
 * @generated
 */
public interface Situation extends TraceableSpecification {
} // Situation
