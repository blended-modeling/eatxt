/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hazard</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The Hazard metaclass represents a condition or state in the system that may contribute to accidents. The Hazard is caused by malfunctioning behavior of E/E safety-related systems including interaction of these systems.
 * 
 * The Hazard does not address hazards such as electric shock, fire, smoke, heat, radiation, toxicity, flammability, reactivity, corrosion, release of energy, and similar hazards unless directly caused by malfunctioning behavior of safety related electrical/electronic systems.
 * 
 * Semantics:
 * The Hazard element represents a condition or state in the system that may contribute to accidents. The associated malfunction identifies the FeatureFlaw that corresponds to the Hazard.
 * 
 * Notation:
 * The Hazard is shown as a solid-outline rectangle with "Haz" at the top right. It contains the name of the Hazard and optionally the name of the source entity.
 * 
 * Extension: 
 * UML::Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.Hazard</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Hazard#getMalfunction <em>Malfunction</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Hazard#getItem <em>Item</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getHazard()
 * @model annotation="MetaData guid='{95D4F1E6-BEC4-4047-9EA8-3D1B001F7744}' id='188' EA\040name='Hazard'"
 *        extendedMetaData="name='HAZARD' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HAZARDS'"
 * @generated
 */
public interface Hazard extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Malfunction</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FeatureFlaw}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Malfunction</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Malfunction</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getHazard_Malfunction()
	 * @model required="true"
	 *        annotation="MetaData guid='{A5B5F707-E69C-47fa-8F94-35839E415D4F}' id='263' EA\040name=''"
	 *        extendedMetaData="name='MALFUNCTION-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='MALFUNCTION-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FeatureFlaw> getMalfunction();

	/**
	 * Returns the value of the '<em><b>Item</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Item}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Item</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Item</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getHazard_Item()
	 * @model required="true"
	 *        annotation="MetaData guid='{23788E20-CEEB-4c12-B88C-FCE0D9DFA89C}' id='268' EA\040name=''"
	 *        extendedMetaData="name='ITEM-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ITEM-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Item> getItem();

} // Hazard
