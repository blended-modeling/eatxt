/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Architecture</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The fundamental organization of a system embodied by its components, their relationships to each other, and to the environment, and the principles guiding its design and evolution. [IEEE 1471]
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.Needs.Architecture</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Architecture#getDescribedBy <em>Described By</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArchitecture()
 * @model annotation="MetaData guid='{026ADFB2-5BCD-4ad2-B6FB-957F0980A0AB}' id='324' EA\040name='Architecture'"
 *        extendedMetaData="name='ARCHITECTURE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ARCHITECTURES'"
 * @generated
 */
public interface Architecture extends Concept {
	/**
	 * Returns the value of the '<em><b>Described By</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Described By</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Described By</em>' reference.
	 * @see #setDescribedBy(ArchitecturalDescription)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArchitecture_DescribedBy()
	 * @model required="true"
	 *        annotation="MetaData guid='{81A10BA4-E388-4df5-A1B6-FD50C5B7B753}' id='15' EA\040name=''"
	 *        extendedMetaData="name='DESCRIBED-BY-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DESCRIBED-BY-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	ArchitecturalDescription getDescribedBy();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Architecture#getDescribedBy <em>Described By</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Described By</em>' reference.
	 * @see #getDescribedBy()
	 * @generated
	 */
	void setDescribedBy(ArchitecturalDescription value);

} // Architecture
