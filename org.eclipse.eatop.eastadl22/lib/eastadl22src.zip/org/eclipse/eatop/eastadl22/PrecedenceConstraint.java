/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Precedence Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The PrecedenceConstraint represents a particular constraint applied on the execution/occurrence sequence of events.
 * 
 * Semantics:
 * The semantics for the PrecedenceConstraint metaclass is to define an execution/occurrence order of the events referenced by the referenced event chain. Segments of the event chain can be used to identify multiple events such that
 * <ul>
 * 	<li>multiple stimulus events (s_1...s_n) with the same response event r have to precede the response event r in the specified order (s_1 precedes s_2 and so on),</li>
 * 	<li>multiple response events (r_1...r_m) with the same stimulus event s have to happen after the stimulus event s in the specified order (r_1 precedes r_2 and so on).</li>
 * </ul>
 * 
 * Note: For information about the general execution/occurrence approach, please refer to the "FunctionTrigger" documentation.
 * 
 * Notation:
 * ALTERNATIVE 1: PrecedenceConstraint is shown as a box with its name/icon. It points to the event chain.
 * 
 * ALTERNATIVE 2: The starting entity (e.g., a signal event) points to the entity that it precedes (e.g., an actuator) with a dashed arrow with "Precedes" next to it. (For advanced tools with semantics check/act as a wizard.)
 * 
 * Extension: 
 * The PrecedenceConstraint extends UML2 metaclass Class and Dependency.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.PrecedenceConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.PrecedenceConstraint#getEventChain <em>Event Chain</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPrecedenceConstraint()
 * @model annotation="MetaData guid='{AE2CA1E7-22D4-49a5-97EE-B2E6557437D6}' id='147' EA\040name='PrecedenceConstraint'"
 *        extendedMetaData="name='PRECEDENCE-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PRECEDENCE-CONSTRAINTS'"
 * @generated
 */
public interface PrecedenceConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Event Chain</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event Chain</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event Chain</em>' reference.
	 * @see #setEventChain(EventChain)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getPrecedenceConstraint_EventChain()
	 * @model required="true"
	 *        annotation="MetaData guid='{7966C46F-A96B-4efc-9F44-B31A0B7A966E}' id='775' EA\040name=''"
	 *        extendedMetaData="name='EVENT-CHAIN-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-CHAIN-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EventChain getEventChain();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.PrecedenceConstraint#getEventChain <em>Event Chain</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event Chain</em>' reference.
	 * @see #getEventChain()
	 * @generated
	 */
	void setEventChain(EventChain value);

} // PrecedenceConstraint
