/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Quality Requirement Kind</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * QualityRequirementKind represents an enumeration with enumeration literals describing various types of quality requirements.
 * 
 * Semantics:
 * QualityRequirementKind represents the kind of QualityRequirement given by the definition of the respective Enumeration Literal.
 * 
 * Extension: 
 * Enumeration, no extension.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.QualityRequirementKind</b></em> 
 * <!-- end-model-doc -->
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getQualityRequirementKind()
 * @model annotation="MetaData guid='{01E7D585-BACE-4148-81B4-99CED16BCA1E}' id='107' EA\040name='QualityRequirementKind'"
 *        annotation="Stereotype Stereotype='enumeration'"
 *        extendedMetaData="name='QUALITY-REQUIREMENT-KIND'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='QUALITY-REQUIREMENT-KINDS'"
 * @generated
 */
public enum QualityRequirementKind implements Enumerator {
	/**
	 * The '<em><b>Availability</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #AVAILABILITY_VALUE
	 * @generated
	 * @ordered
	 */
	AVAILABILITY(0, "availability", "AVAILABILITY"),

	/**
	 * The '<em><b>Confidentiality</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONFIDENTIALITY_VALUE
	 * @generated
	 * @ordered
	 */
	CONFIDENTIALITY(1, "confidentiality", "CONFIDENTIALITY"),

	/**
	 * The '<em><b>Configurability</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CONFIGURABILITY_VALUE
	 * @generated
	 * @ordered
	 */
	CONFIGURABILITY(2, "configurability", "CONFIGURABILITY"),

	/**
	 * The '<em><b>Ergonomy</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ERGONOMY_VALUE
	 * @generated
	 * @ordered
	 */
	ERGONOMY(3, "ergonomy", "ERGONOMY"),

	/**
	 * The '<em><b>Integrity</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #INTEGRITY_VALUE
	 * @generated
	 * @ordered
	 */
	INTEGRITY(4, "integrity", "INTEGRITY"),

	/**
	 * The '<em><b>Human Machine Interface</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #HUMAN_MACHINE_INTERFACE_VALUE
	 * @generated
	 * @ordered
	 */
	HUMAN_MACHINE_INTERFACE(5, "humanMachineInterface", "HUMANMACHINEINTERFACE"),

	/**
	 * The '<em><b>Maintainability</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MAINTAINABILITY_VALUE
	 * @generated
	 * @ordered
	 */
	MAINTAINABILITY(6, "maintainability", "MAINTAINABILITY"),

	/**
	 * The '<em><b>Other</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #OTHER_VALUE
	 * @generated
	 * @ordered
	 */
	OTHER(7, "other", "OTHER"),

	/**
	 * The '<em><b>Performance</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PERFORMANCE_VALUE
	 * @generated
	 * @ordered
	 */
	PERFORMANCE(8, "performance", "PERFORMANCE"),

	/**
	 * The '<em><b>Reliability</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RELIABILITY_VALUE
	 * @generated
	 * @ordered
	 */
	RELIABILITY(9, "reliability", "RELIABILITY"),

	/**
	 * The '<em><b>Safety</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SAFETY_VALUE
	 * @generated
	 * @ordered
	 */
	SAFETY(10, "safety", "SAFETY"),

	/**
	 * The '<em><b>Security</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SECURITY_VALUE
	 * @generated
	 * @ordered
	 */
	SECURITY(11, "security", "SECURITY"),

	/**
	 * The '<em><b>Timing</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TIMING_VALUE
	 * @generated
	 * @ordered
	 */
	TIMING(12, "timing", "TIMING");

	/**
	 * The '<em><b>Availability</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Availability</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #AVAILABILITY
	 * @model name="availability" literal="AVAILABILITY"
	 * @generated
	 * @ordered
	 */
	public static final int AVAILABILITY_VALUE = 0;

	/**
	 * The '<em><b>Confidentiality</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Confidentiality</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONFIDENTIALITY
	 * @model name="confidentiality" literal="CONFIDENTIALITY"
	 * @generated
	 * @ordered
	 */
	public static final int CONFIDENTIALITY_VALUE = 1;

	/**
	 * The '<em><b>Configurability</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Configurability</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CONFIGURABILITY
	 * @model name="configurability" literal="CONFIGURABILITY"
	 * @generated
	 * @ordered
	 */
	public static final int CONFIGURABILITY_VALUE = 2;

	/**
	 * The '<em><b>Ergonomy</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Ergonomy</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ERGONOMY
	 * @model name="ergonomy" literal="ERGONOMY"
	 * @generated
	 * @ordered
	 */
	public static final int ERGONOMY_VALUE = 3;

	/**
	 * The '<em><b>Integrity</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Integrity</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #INTEGRITY
	 * @model name="integrity" literal="INTEGRITY"
	 * @generated
	 * @ordered
	 */
	public static final int INTEGRITY_VALUE = 4;

	/**
	 * The '<em><b>Human Machine Interface</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Human Machine Interface</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #HUMAN_MACHINE_INTERFACE
	 * @model name="humanMachineInterface" literal="HUMANMACHINEINTERFACE"
	 * @generated
	 * @ordered
	 */
	public static final int HUMAN_MACHINE_INTERFACE_VALUE = 5;

	/**
	 * The '<em><b>Maintainability</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Maintainability</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MAINTAINABILITY
	 * @model name="maintainability" literal="MAINTAINABILITY"
	 * @generated
	 * @ordered
	 */
	public static final int MAINTAINABILITY_VALUE = 6;

	/**
	 * The '<em><b>Other</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Other</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #OTHER
	 * @model name="other" literal="OTHER"
	 * @generated
	 * @ordered
	 */
	public static final int OTHER_VALUE = 7;

	/**
	 * The '<em><b>Performance</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Performance</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PERFORMANCE
	 * @model name="performance" literal="PERFORMANCE"
	 * @generated
	 * @ordered
	 */
	public static final int PERFORMANCE_VALUE = 8;

	/**
	 * The '<em><b>Reliability</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Reliability</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RELIABILITY
	 * @model name="reliability" literal="RELIABILITY"
	 * @generated
	 * @ordered
	 */
	public static final int RELIABILITY_VALUE = 9;

	/**
	 * The '<em><b>Safety</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Safety</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SAFETY
	 * @model name="safety" literal="SAFETY"
	 * @generated
	 * @ordered
	 */
	public static final int SAFETY_VALUE = 10;

	/**
	 * The '<em><b>Security</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Security</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SECURITY
	 * @model name="security" literal="SECURITY"
	 * @generated
	 * @ordered
	 */
	public static final int SECURITY_VALUE = 11;

	/**
	 * The '<em><b>Timing</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Timing</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TIMING
	 * @model name="timing" literal="TIMING"
	 * @generated
	 * @ordered
	 */
	public static final int TIMING_VALUE = 12;

	/**
	 * An array of all the '<em><b>Quality Requirement Kind</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final QualityRequirementKind[] VALUES_ARRAY =
		new QualityRequirementKind[] {
			AVAILABILITY,
			CONFIDENTIALITY,
			CONFIGURABILITY,
			ERGONOMY,
			INTEGRITY,
			HUMAN_MACHINE_INTERFACE,
			MAINTAINABILITY,
			OTHER,
			PERFORMANCE,
			RELIABILITY,
			SAFETY,
			SECURITY,
			TIMING,
		};

	/**
	 * A public read-only list of all the '<em><b>Quality Requirement Kind</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<QualityRequirementKind> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Quality Requirement Kind</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static QualityRequirementKind get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			QualityRequirementKind result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Quality Requirement Kind</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static QualityRequirementKind getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			QualityRequirementKind result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Quality Requirement Kind</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static QualityRequirementKind get(int value) {
		switch (value) {
			case AVAILABILITY_VALUE: return AVAILABILITY;
			case CONFIDENTIALITY_VALUE: return CONFIDENTIALITY;
			case CONFIGURABILITY_VALUE: return CONFIGURABILITY;
			case ERGONOMY_VALUE: return ERGONOMY;
			case INTEGRITY_VALUE: return INTEGRITY;
			case HUMAN_MACHINE_INTERFACE_VALUE: return HUMAN_MACHINE_INTERFACE;
			case MAINTAINABILITY_VALUE: return MAINTAINABILITY;
			case OTHER_VALUE: return OTHER;
			case PERFORMANCE_VALUE: return PERFORMANCE;
			case RELIABILITY_VALUE: return RELIABILITY;
			case SAFETY_VALUE: return SAFETY;
			case SECURITY_VALUE: return SECURITY;
			case TIMING_VALUE: return TIMING;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private QualityRequirementKind(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //QualityRequirementKind