/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stakeholder</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The stakeholder represents various roles with regard to the creation and use of architectural descriptions. Stakeholders include clients, users, the architect, developers, and evaluators. [IEEE 1471]
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.Needs.Stakeholder</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Stakeholder#getResponsibilities <em>Responsibilities</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Stakeholder#getSuccessCriteria <em>Success Criteria</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStakeholder()
 * @model annotation="MetaData guid='{6AABCE2F-432E-415e-8034-76FE7540DED0}' id='330' EA\040name='Stakeholder'"
 *        extendedMetaData="name='STAKEHOLDER' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STAKEHOLDERS'"
 * @generated
 */
public interface Stakeholder extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Responsibilities</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Summarize the Stakeholder's key responsibilities with regard to the electrical/electronic system being developed; that is, their interest as a Stakeholder.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Responsibilities</em>' attribute.
	 * @see #isSetResponsibilities()
	 * @see #unsetResponsibilities()
	 * @see #setResponsibilities(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStakeholder_Responsibilities()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String" required="true"
	 *        annotation="MetaData guid='{36E30A37-BAB9-4d3e-AF55-0603CFFC0D21}' id='222' EA\040name='responsibilities'"
	 *        extendedMetaData="name='RESPONSIBILITIES' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='RESPONSIBILITIESS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getResponsibilities();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Stakeholder#getResponsibilities <em>Responsibilities</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Responsibilities</em>' attribute.
	 * @see #isSetResponsibilities()
	 * @see #Responsibilities()
	 * @see #getResponsibilities()
	 * @generated
	 */
	void setResponsibilities(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.Stakeholder#getResponsibilities <em>Responsibilities</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetResponsibilities()
	 * @see #getResponsibilities()
	 * @see #setResponsibilities(String)
	 * @generated
	 */
	void unsetResponsibilities();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.Stakeholder#getResponsibilities <em>Responsibilities</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Responsibilities</em>' attribute is set.
	 * @see #Responsibilities()
	 * @see #getResponsibilities()
	 * @see #setResponsibilities(String)
	 * @generated
	 */
	boolean isSetResponsibilities();

	/**
	 * Returns the value of the '<em><b>Success Criteria</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * Describes how the Stakeholder defines success.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Success Criteria</em>' attribute.
	 * @see #isSetSuccessCriteria()
	 * @see #unsetSuccessCriteria()
	 * @see #setSuccessCriteria(String)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStakeholder_SuccessCriteria()
	 * @model unsettable="true" dataType="org.eclipse.eatop.eastadl22.String"
	 *        annotation="MetaData guid='{94A7991D-2964-427b-9BBD-18AC281D8CF3}' id='223' EA\040name='successCriteria'"
	 *        extendedMetaData="name='SUCCESS-CRITERIA' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SUCCESS-CRITERIAS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	String getSuccessCriteria();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Stakeholder#getSuccessCriteria <em>Success Criteria</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Success Criteria</em>' attribute.
	 * @see #isSetSuccessCriteria()
	 * @see #SuccessCriteria()
	 * @see #getSuccessCriteria()
	 * @generated
	 */
	void setSuccessCriteria(String value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.Stakeholder#getSuccessCriteria <em>Success Criteria</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetSuccessCriteria()
	 * @see #getSuccessCriteria()
	 * @see #setSuccessCriteria(String)
	 * @generated
	 */
	void unsetSuccessCriteria();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.Stakeholder#getSuccessCriteria <em>Success Criteria</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Success Criteria</em>' attribute is set.
	 * @see #SuccessCriteria()
	 * @see #getSuccessCriteria()
	 * @see #setSuccessCriteria(String)
	 * @generated
	 */
	boolean isSetSuccessCriteria();

} // Stakeholder
