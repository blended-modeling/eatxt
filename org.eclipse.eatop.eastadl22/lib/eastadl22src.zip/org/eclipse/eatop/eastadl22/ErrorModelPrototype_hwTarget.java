/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Error Model Prototype hw Target</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.ErrorModel._instanceRef.ErrorModelPrototype_hwTarget</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelPrototype_hwTarget#getHardwareComponentPrototype <em>Hardware Component Prototype</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelPrototype_hwTarget#getHardwareComponentPrototype_context <em>Hardware Component Prototype context</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelPrototype_hwTarget()
 * @model annotation="MetaData guid='{380093E7-E4F9-49dc-81F3-6113D64DC979}' id='219' EA\040name='ErrorModelPrototype_hwTarget'"
 *        annotation="Stereotype Stereotype='instanceRef'"
 *        annotation="TaggedValues xml.name='ERROR-MODEL-PROTOTYPE--HW-TARGET-IREF'"
 *        extendedMetaData="name='ERROR-MODEL-PROTOTYPE--HW-TARGET-IREF' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-MODEL-PROTOTYPE--HW-TARGET-IREFS'"
 * @generated
 */
public interface ErrorModelPrototype_hwTarget extends EObject {
	/**
	 * Returns the value of the '<em><b>Hardware Component Prototype</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hardware Component Prototype</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hardware Component Prototype</em>' reference.
	 * @see #setHardwareComponentPrototype(HardwareComponentPrototype)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelPrototype_hwTarget_HardwareComponentPrototype()
	 * @model required="true"
	 *        annotation="MetaData guid='{E9ACECFA-73F6-4ef2-B542-BFECEEB20E1D}' id='567' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.target'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='HARDWARE-COMPONENT-PROTOTYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HARDWARE-COMPONENT-PROTOTYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	HardwareComponentPrototype getHardwareComponentPrototype();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ErrorModelPrototype_hwTarget#getHardwareComponentPrototype <em>Hardware Component Prototype</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hardware Component Prototype</em>' reference.
	 * @see #getHardwareComponentPrototype()
	 * @generated
	 */
	void setHardwareComponentPrototype(HardwareComponentPrototype value);

	/**
	 * Returns the value of the '<em><b>Hardware Component Prototype context</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.HardwareComponentPrototype}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hardware Component Prototype context</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hardware Component Prototype context</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelPrototype_hwTarget_HardwareComponentPrototype_context()
	 * @model annotation="MetaData guid='{548D89CF-6A41-4d8f-B7AA-235607D6B6F6}' id='575' EA\040name=''"
	 *        annotation="Stereotype Stereotype='instanceRef.context'"
	 *        annotation="TaggedValues xml.roleElement='true' xml.roleWrapperElement='false'"
	 *        extendedMetaData="name='HARDWARE-COMPONENT-PROTOTYPE-CONTEXT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HARDWARE-COMPONENT-PROTOTYPE-CONTEXT-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<HardwareComponentPrototype> getHardwareComponentPrototype_context();

} // ErrorModelPrototype_hwTarget
