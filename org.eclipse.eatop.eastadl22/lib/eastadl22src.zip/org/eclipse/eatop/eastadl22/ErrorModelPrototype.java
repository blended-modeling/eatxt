/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Error Model Prototype</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The ErrorModelPrototype is used to define hierarchical error models allowing additional detail or structure to be described in the error model of a particular target. A hierarchal structure can also be defined when several ErrorModels are integrated into a larger ErrorModel representing a system integrated from several targets. 
 * 
 * Typically the target is a system/subsystem, a function, a software component, or a hardware device.
 * 
 * 
 * Semantics:
 * An ErrorModelPrototype represents an occurrence of the ErrorModelType that types it.
 * 
 * Extension:
 * (See ADLFunctionPrototype)
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.ErrorModel.ErrorModelPrototype</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelPrototype#getTarget <em>Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelPrototype#getType <em>Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelPrototype#getFunctionTarget <em>Function Target</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ErrorModelPrototype#getHwTarget <em>Hw Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelPrototype()
 * @model annotation="MetaData guid='{69429BF4-9F89-46d9-AC66-055946E75151}' id='207' EA\040name='ErrorModelPrototype'"
 *        annotation="Stereotype Stereotype='atpPrototype'"
 *        extendedMetaData="name='ERROR-MODEL-PROTOTYPE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ERROR-MODEL-PROTOTYPES'"
 * @generated
 */
public interface ErrorModelPrototype extends EAPrototype, EAElement {
	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(Identifiable)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelPrototype_Target()
	 * @model required="true"
	 *        annotation="MetaData guid='{CEFB33FE-F0D1-4056-B5E4-10285B43B67F}' id='222' EA\040name=''"
	 *        extendedMetaData="name='TARGET-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGET-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Identifiable getTarget();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ErrorModelPrototype#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(Identifiable value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' reference.
	 * @see #setType(ErrorModelType)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelPrototype_Type()
	 * @model required="true"
	 *        annotation="MetaData guid='{158B178B-F75F-4b9f-9B61-636F80353789}' id='231' EA\040name=''"
	 *        annotation="Stereotype Stereotype='isOfType'"
	 *        extendedMetaData="name='TYPE-TREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TYPE-TREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	ErrorModelType getType();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.ErrorModelPrototype#getType <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(ErrorModelType value);

	/**
	 * Returns the value of the '<em><b>Function Target</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ErrorModelPrototype_functionTarget}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Function Target</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Target</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelPrototype_FunctionTarget()
	 * @model containment="true"
	 *        annotation="MetaData guid='{429F2CD7-D9D2-415d-A5BD-B6EB6E39D35E}' id='228' EA\040name=''"
	 *        annotation="TaggedValues xml.name='FUNCTION-TARGET-IREF' xml.namePlural='FUNCTION-TARGET-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='FUNCTION-TARGET-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FUNCTION-TARGET-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<ErrorModelPrototype_functionTarget> getFunctionTarget();

	/**
	 * Returns the value of the '<em><b>Hw Target</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ErrorModelPrototype_hwTarget}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hw Target</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hw Target</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getErrorModelPrototype_HwTarget()
	 * @model containment="true"
	 *        annotation="MetaData guid='{3C772A1A-212F-47b8-B40E-C7BF05E3B60A}' id='229' EA\040name=''"
	 *        annotation="TaggedValues xml.name='HW-TARGET-IREF' xml.namePlural='HW-TARGET-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='HW-TARGET-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='HW-TARGET-IREFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<ErrorModelPrototype_hwTarget> getHwTarget();

} // ErrorModelPrototype
