/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Strong Synchronization Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A StrongSynchronizationConstraint describes how tightly the occurrences of a group of events follow each other.
 * 
 * Semantics:
 * A system behavior satisfies a StrongSynchronizationConstraint c if and only if
 * there is a set of times X such that for each c.event index i, the same system behavior satisfies
 * 
 * StrongDelayConstraint { source = X,
 * target = c.event(i),
 * lower = 0,
 * upper = c.tolerance }
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.TimingConstraints.StrongSynchronizationConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.StrongSynchronizationConstraint#getTolerance <em>Tolerance</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.StrongSynchronizationConstraint#getEvent <em>Event</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStrongSynchronizationConstraint()
 * @model annotation="MetaData guid='{6E1CE504-E924-4432-954A-3BCC132F54DB}' id='168' EA\040name='StrongSynchronizationConstraint'"
 *        extendedMetaData="name='STRONG-SYNCHRONIZATION-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='STRONG-SYNCHRONIZATION-CONSTRAINTS'"
 * @generated
 */
public interface StrongSynchronizationConstraint extends TimingConstraint {
	/**
	 * Returns the value of the '<em><b>Tolerance</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tolerance</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tolerance</em>' containment reference.
	 * @see #setTolerance(TimingExpression)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStrongSynchronizationConstraint_Tolerance()
	 * @model containment="true"
	 *        annotation="MetaData guid='{C2F55807-FE42-45d5-A1AC-4FBB50AD5EB0}' id='299' EA\040name=''"
	 *        extendedMetaData="name='TOLERANCE' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TOLERANCES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	TimingExpression getTolerance();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.StrongSynchronizationConstraint#getTolerance <em>Tolerance</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tolerance</em>' containment reference.
	 * @see #getTolerance()
	 * @generated
	 */
	void setTolerance(TimingExpression value);

	/**
	 * Returns the value of the '<em><b>Event</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Event}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getStrongSynchronizationConstraint_Event()
	 * @model lower="2"
	 *        annotation="MetaData guid='{8FB67076-1DFF-4e69-857A-5A0598B75C06}' id='369' EA\040name=''"
	 *        extendedMetaData="name='EVENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Event> getEvent();

} // StrongSynchronizationConstraint
