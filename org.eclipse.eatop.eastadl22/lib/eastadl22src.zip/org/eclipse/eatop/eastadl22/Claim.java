/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Claim</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Claim represents a statement, the truth of which needs to be confirmed.
 * 
 * Claim has associations to the strategy for goal decomposition and to supported arguments. It also holds associations to the evidences for the SafetyCase.
 * 
 * 
 * Semantics:
 * Goal-based development provides the claim what should be achieved.
 * 
 * Goal is what the argument must show to be true. 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Dependability.SafetyCase.Claim</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Claim#getSafetyRequirement <em>Safety Requirement</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Claim#getJustification <em>Justification</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Claim#getEvidence <em>Evidence</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Claim#getSupportedArgument <em>Supported Argument</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Claim#getGoalDecompositionStrategy <em>Goal Decomposition Strategy</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getClaim()
 * @model annotation="MetaData guid='{EDF09B36-682A-4827-84B3-1D4E452AD1E5}' id='230' EA\040name='Claim'"
 *        extendedMetaData="name='CLAIM' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CLAIMS'"
 * @generated
 */
public interface Claim extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Safety Requirement</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.TraceableSpecification}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Safety Requirement</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Safety Requirement</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getClaim_SafetyRequirement()
	 * @model annotation="MetaData guid='{35CD039C-95A4-411e-9B7F-F3FDE8983BB2}' id='181' EA\040name=''"
	 *        extendedMetaData="name='SAFETY-REQUIREMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SAFETY-REQUIREMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<TraceableSpecification> getSafetyRequirement();

	/**
	 * Returns the value of the '<em><b>Justification</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Rationale}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Justification</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Justification</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getClaim_Justification()
	 * @model containment="true"
	 *        annotation="MetaData guid='{0E936A39-8C52-4c63-A057-3F106773A131}' id='183' EA\040name=''"
	 *        extendedMetaData="name='JUSTIFICATION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='JUSTIFICATIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<Rationale> getJustification();

	/**
	 * Returns the value of the '<em><b>Evidence</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Ground}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Evidence</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Evidence</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getClaim_Evidence()
	 * @model required="true"
	 *        annotation="MetaData guid='{F426A324-D344-4ec3-BB96-25F46BA43C9C}' id='184' EA\040name=''"
	 *        extendedMetaData="name='EVIDENCE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVIDENCE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Ground> getEvidence();

	/**
	 * Returns the value of the '<em><b>Supported Argument</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Warrant}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Supported Argument</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Supported Argument</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getClaim_SupportedArgument()
	 * @model annotation="MetaData guid='{67FAFDF0-681A-4e02-B215-2983C702B9FD}' id='192' EA\040name=''"
	 *        extendedMetaData="name='SUPPORTED-ARGUMENT-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='SUPPORTED-ARGUMENT-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Warrant> getSupportedArgument();

	/**
	 * Returns the value of the '<em><b>Goal Decomposition Strategy</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Warrant}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Goal Decomposition Strategy</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Goal Decomposition Strategy</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getClaim_GoalDecompositionStrategy()
	 * @model annotation="MetaData guid='{0B7A18D9-9949-428b-B74D-0DDEB77940C1}' id='193' EA\040name=''"
	 *        extendedMetaData="name='GOAL-DECOMPOSITION-STRATEGY-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='GOAL-DECOMPOSITION-STRATEGY-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Warrant> getGoalDecompositionStrategy();

} // Claim
