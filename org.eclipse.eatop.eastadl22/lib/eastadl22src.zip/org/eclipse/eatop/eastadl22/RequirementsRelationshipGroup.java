/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Requirements Relationship Group</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * RequirementsRelationGroup represents a group of relations between Requirements.
 * 
 * RequirementsRelationGroup corresponds to ReqIF RelationGroup.
 * 
 * Semantics:
 * RequirementsRelationGroup represents a group of RequirementsRelations. The semantics of this grouping is defined by the user.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Requirements.RequirementsRelationshipGroup</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.RequirementsRelationshipGroup#getRequirementsRelationship <em>Requirements Relationship</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRequirementsRelationshipGroup()
 * @model annotation="MetaData guid='{389D5402-B5BF-451c-9DDE-3E1323E14356}' id='110' EA\040name='RequirementsRelationshipGroup'"
 *        extendedMetaData="name='REQUIREMENTS-RELATIONSHIP-GROUP' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS-RELATIONSHIP-GROUPS'"
 * @generated
 */
public interface RequirementsRelationshipGroup extends TraceableSpecification {
	/**
	 * Returns the value of the '<em><b>Requirements Relationship</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.RequirementsRelationship}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Requirements Relationship</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Requirements Relationship</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getRequirementsRelationshipGroup_RequirementsRelationship()
	 * @model required="true"
	 *        annotation="MetaData guid='{84FF0A83-2238-46ca-BD6D-C2CA89E6C3FE}' id='473' EA\040name=''"
	 *        extendedMetaData="name='REQUIREMENTS-RELATIONSHIP-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='REQUIREMENTS-RELATIONSHIP-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<RequirementsRelationship> getRequirementsRelationship();

} // RequirementsRelationshipGroup
