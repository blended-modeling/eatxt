/**
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package
 * @generated
 */
public interface Eastadl22Factory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Eastadl22Factory eINSTANCE = org.eclipse.eatop.eastadl22.impl.Eastadl22FactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Vehicle Level</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vehicle Level</em>'.
	 * @generated
	 */
	VehicleLevel createVehicleLevel();

	/**
	 * Returns a new object of class '<em>System Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>System Model</em>'.
	 * @generated
	 */
	SystemModel createSystemModel();

	/**
	 * Returns a new object of class '<em>Analysis Level</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Analysis Level</em>'.
	 * @generated
	 */
	AnalysisLevel createAnalysisLevel();

	/**
	 * Returns a new object of class '<em>Design Level</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Design Level</em>'.
	 * @generated
	 */
	DesignLevel createDesignLevel();

	/**
	 * Returns a new object of class '<em>Implementation Level</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Implementation Level</em>'.
	 * @generated
	 */
	ImplementationLevel createImplementationLevel();

	/**
	 * Returns a new object of class '<em>Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feature</em>'.
	 * @generated
	 */
	Feature createFeature();

	/**
	 * Returns a new object of class '<em>Feature Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feature Constraint</em>'.
	 * @generated
	 */
	FeatureConstraint createFeatureConstraint();

	/**
	 * Returns a new object of class '<em>Feature Group</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feature Group</em>'.
	 * @generated
	 */
	FeatureGroup createFeatureGroup();

	/**
	 * Returns a new object of class '<em>Feature Link</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feature Link</em>'.
	 * @generated
	 */
	FeatureLink createFeatureLink();

	/**
	 * Returns a new object of class '<em>Feature Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feature Model</em>'.
	 * @generated
	 */
	FeatureModel createFeatureModel();

	/**
	 * Returns a new object of class '<em>Deviation Attribute Set</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Deviation Attribute Set</em>'.
	 * @generated
	 */
	DeviationAttributeSet createDeviationAttributeSet();

	/**
	 * Returns a new object of class '<em>Vehicle Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vehicle Feature</em>'.
	 * @generated
	 */
	VehicleFeature createVehicleFeature();

	/**
	 * Returns a new object of class '<em>Allocation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Allocation</em>'.
	 * @generated
	 */
	Allocation createAllocation();

	/**
	 * Returns a new object of class '<em>Analysis Function Prototype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Analysis Function Prototype</em>'.
	 * @generated
	 */
	AnalysisFunctionPrototype createAnalysisFunctionPrototype();

	/**
	 * Returns a new object of class '<em>Analysis Function Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Analysis Function Type</em>'.
	 * @generated
	 */
	AnalysisFunctionType createAnalysisFunctionType();

	/**
	 * Returns a new object of class '<em>Basic Software Function Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Basic Software Function Type</em>'.
	 * @generated
	 */
	BasicSoftwareFunctionType createBasicSoftwareFunctionType();

	/**
	 * Returns a new object of class '<em>Design Function Prototype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Design Function Prototype</em>'.
	 * @generated
	 */
	DesignFunctionPrototype createDesignFunctionPrototype();

	/**
	 * Returns a new object of class '<em>Design Function Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Design Function Type</em>'.
	 * @generated
	 */
	DesignFunctionType createDesignFunctionType();

	/**
	 * Returns a new object of class '<em>Functional Device</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Functional Device</em>'.
	 * @generated
	 */
	FunctionalDevice createFunctionalDevice();

	/**
	 * Returns a new object of class '<em>Function Allocation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Allocation</em>'.
	 * @generated
	 */
	FunctionAllocation createFunctionAllocation();

	/**
	 * Returns a new object of class '<em>Function Client Server Interface</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Client Server Interface</em>'.
	 * @generated
	 */
	FunctionClientServerInterface createFunctionClientServerInterface();

	/**
	 * Returns a new object of class '<em>Function Client Server Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Client Server Port</em>'.
	 * @generated
	 */
	FunctionClientServerPort createFunctionClientServerPort();

	/**
	 * Returns a new object of class '<em>Function Connector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Connector</em>'.
	 * @generated
	 */
	FunctionConnector createFunctionConnector();

	/**
	 * Returns a new object of class '<em>Function Flow Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Flow Port</em>'.
	 * @generated
	 */
	FunctionFlowPort createFunctionFlowPort();

	/**
	 * Returns a new object of class '<em>Function Power Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Power Port</em>'.
	 * @generated
	 */
	FunctionPowerPort createFunctionPowerPort();

	/**
	 * Returns a new object of class '<em>Hardware Function Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hardware Function Type</em>'.
	 * @generated
	 */
	HardwareFunctionType createHardwareFunctionType();

	/**
	 * Returns a new object of class '<em>Local Device Manager</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Local Device Manager</em>'.
	 * @generated
	 */
	LocalDeviceManager createLocalDeviceManager();

	/**
	 * Returns a new object of class '<em>Operation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Operation</em>'.
	 * @generated
	 */
	Operation createOperation();

	/**
	 * Returns a new object of class '<em>Port Group</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Port Group</em>'.
	 * @generated
	 */
	PortGroup createPortGroup();

	/**
	 * Returns a new object of class '<em>Function Allocation allocated Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Allocation allocated Element</em>'.
	 * @generated
	 */
	FunctionAllocation_allocatedElement createFunctionAllocation_allocatedElement();

	/**
	 * Returns a new object of class '<em>Function Allocation target</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Allocation target</em>'.
	 * @generated
	 */
	FunctionAllocation_target createFunctionAllocation_target();

	/**
	 * Returns a new object of class '<em>Function Connector port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Connector port</em>'.
	 * @generated
	 */
	FunctionConnector_port createFunctionConnector_port();

	/**
	 * Returns a new object of class '<em>Actuator</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Actuator</em>'.
	 * @generated
	 */
	Actuator createActuator();

	/**
	 * Returns a new object of class '<em>Communication Hardware Pin</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Communication Hardware Pin</em>'.
	 * @generated
	 */
	CommunicationHardwarePin createCommunicationHardwarePin();

	/**
	 * Returns a new object of class '<em>Electrical Component</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Electrical Component</em>'.
	 * @generated
	 */
	ElectricalComponent createElectricalComponent();

	/**
	 * Returns a new object of class '<em>Hardware Component Prototype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hardware Component Prototype</em>'.
	 * @generated
	 */
	HardwareComponentPrototype createHardwareComponentPrototype();

	/**
	 * Returns a new object of class '<em>Hardware Component Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hardware Component Type</em>'.
	 * @generated
	 */
	HardwareComponentType createHardwareComponentType();

	/**
	 * Returns a new object of class '<em>Hardware Connector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hardware Connector</em>'.
	 * @generated
	 */
	HardwareConnector createHardwareConnector();

	/**
	 * Returns a new object of class '<em>Hardware Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hardware Port</em>'.
	 * @generated
	 */
	HardwarePort createHardwarePort();

	/**
	 * Returns a new object of class '<em>Hardware Port Connector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hardware Port Connector</em>'.
	 * @generated
	 */
	HardwarePortConnector createHardwarePortConnector();

	/**
	 * Returns a new object of class '<em>IO Hardware Pin</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>IO Hardware Pin</em>'.
	 * @generated
	 */
	IOHardwarePin createIOHardwarePin();

	/**
	 * Returns a new object of class '<em>Logical Port Connector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Logical Port Connector</em>'.
	 * @generated
	 */
	LogicalPortConnector createLogicalPortConnector();

	/**
	 * Returns a new object of class '<em>Node</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Node</em>'.
	 * @generated
	 */
	Node createNode();

	/**
	 * Returns a new object of class '<em>Power Hardware Pin</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Power Hardware Pin</em>'.
	 * @generated
	 */
	PowerHardwarePin createPowerHardwarePin();

	/**
	 * Returns a new object of class '<em>Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sensor</em>'.
	 * @generated
	 */
	Sensor createSensor();

	/**
	 * Returns a new object of class '<em>Hardware Connector port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hardware Connector port</em>'.
	 * @generated
	 */
	HardwareConnector_port createHardwareConnector_port();

	/**
	 * Returns a new object of class '<em>Hardware Port Connector port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hardware Port Connector port</em>'.
	 * @generated
	 */
	HardwarePortConnector_port createHardwarePortConnector_port();

	/**
	 * Returns a new object of class '<em>Clamp Connector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Clamp Connector</em>'.
	 * @generated
	 */
	ClampConnector createClampConnector();

	/**
	 * Returns a new object of class '<em>Environment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Environment</em>'.
	 * @generated
	 */
	Environment createEnvironment();

	/**
	 * Returns a new object of class '<em>Clamp Connector port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Clamp Connector port</em>'.
	 * @generated
	 */
	ClampConnector_port createClampConnector_port();

	/**
	 * Returns a new object of class '<em>Behavior</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior</em>'.
	 * @generated
	 */
	Behavior createBehavior();

	/**
	 * Returns a new object of class '<em>Mode</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mode</em>'.
	 * @generated
	 */
	Mode createMode();

	/**
	 * Returns a new object of class '<em>Mode Group</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mode Group</em>'.
	 * @generated
	 */
	ModeGroup createModeGroup();

	/**
	 * Returns a new object of class '<em>Function Behavior</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Behavior</em>'.
	 * @generated
	 */
	FunctionBehavior createFunctionBehavior();

	/**
	 * Returns a new object of class '<em>Function Trigger</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Function Trigger</em>'.
	 * @generated
	 */
	FunctionTrigger createFunctionTrigger();

	/**
	 * Returns a new object of class '<em>Configurable Container</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Configurable Container</em>'.
	 * @generated
	 */
	ConfigurableContainer createConfigurableContainer();

	/**
	 * Returns a new object of class '<em>Configuration Decision</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Configuration Decision</em>'.
	 * @generated
	 */
	ConfigurationDecision createConfigurationDecision();

	/**
	 * Returns a new object of class '<em>Configuration Decision Folder</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Configuration Decision Folder</em>'.
	 * @generated
	 */
	ConfigurationDecisionFolder createConfigurationDecisionFolder();

	/**
	 * Returns a new object of class '<em>Container Configuration</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Container Configuration</em>'.
	 * @generated
	 */
	ContainerConfiguration createContainerConfiguration();

	/**
	 * Returns a new object of class '<em>Feature Configuration</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feature Configuration</em>'.
	 * @generated
	 */
	FeatureConfiguration createFeatureConfiguration();

	/**
	 * Returns a new object of class '<em>Internal Binding</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Internal Binding</em>'.
	 * @generated
	 */
	InternalBinding createInternalBinding();

	/**
	 * Returns a new object of class '<em>Private Content</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Private Content</em>'.
	 * @generated
	 */
	PrivateContent createPrivateContent();

	/**
	 * Returns a new object of class '<em>Reuse Meta Information</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Reuse Meta Information</em>'.
	 * @generated
	 */
	ReuseMetaInformation createReuseMetaInformation();

	/**
	 * Returns a new object of class '<em>Selection Criterion</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Selection Criterion</em>'.
	 * @generated
	 */
	SelectionCriterion createSelectionCriterion();

	/**
	 * Returns a new object of class '<em>Variability</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Variability</em>'.
	 * @generated
	 */
	Variability createVariability();

	/**
	 * Returns a new object of class '<em>Variable Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Variable Element</em>'.
	 * @generated
	 */
	VariableElement createVariableElement();

	/**
	 * Returns a new object of class '<em>Variation Group</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Variation Group</em>'.
	 * @generated
	 */
	VariationGroup createVariationGroup();

	/**
	 * Returns a new object of class '<em>Vehicle Level Binding</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vehicle Level Binding</em>'.
	 * @generated
	 */
	VehicleLevelBinding createVehicleLevelBinding();

	/**
	 * Returns a new object of class '<em>Derive Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Derive Requirement</em>'.
	 * @generated
	 */
	DeriveRequirement createDeriveRequirement();

	/**
	 * Returns a new object of class '<em>Situation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Situation</em>'.
	 * @generated
	 */
	Situation createSituation();

	/**
	 * Returns a new object of class '<em>Requirements Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Requirements Model</em>'.
	 * @generated
	 */
	RequirementsModel createRequirementsModel();

	/**
	 * Returns a new object of class '<em>Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Requirement</em>'.
	 * @generated
	 */
	Requirement createRequirement();

	/**
	 * Returns a new object of class '<em>Requirements Hierarchy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Requirements Hierarchy</em>'.
	 * @generated
	 */
	RequirementsHierarchy createRequirementsHierarchy();

	/**
	 * Returns a new object of class '<em>Refine</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Refine</em>'.
	 * @generated
	 */
	Refine createRefine();

	/**
	 * Returns a new object of class '<em>Satisfy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Satisfy</em>'.
	 * @generated
	 */
	Satisfy createSatisfy();

	/**
	 * Returns a new object of class '<em>Requirements Link</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Requirements Link</em>'.
	 * @generated
	 */
	RequirementsLink createRequirementsLink();

	/**
	 * Returns a new object of class '<em>Requirements Relationship Group</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Requirements Relationship Group</em>'.
	 * @generated
	 */
	RequirementsRelationshipGroup createRequirementsRelationshipGroup();

	/**
	 * Returns a new object of class '<em>Quality Requirement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Quality Requirement</em>'.
	 * @generated
	 */
	QualityRequirement createQualityRequirement();

	/**
	 * Returns a new object of class '<em>Refine refined By</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Refine refined By</em>'.
	 * @generated
	 */
	Refine_refinedBy createRefine_refinedBy();

	/**
	 * Returns a new object of class '<em>Satisfy satisfied By</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Satisfy satisfied By</em>'.
	 * @generated
	 */
	Satisfy_satisfiedBy createSatisfy_satisfiedBy();

	/**
	 * Returns a new object of class '<em>Actor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Actor</em>'.
	 * @generated
	 */
	Actor createActor();

	/**
	 * Returns a new object of class '<em>Extend</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Extend</em>'.
	 * @generated
	 */
	Extend createExtend();

	/**
	 * Returns a new object of class '<em>Extension Point</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Extension Point</em>'.
	 * @generated
	 */
	ExtensionPoint createExtensionPoint();

	/**
	 * Returns a new object of class '<em>Include</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Include</em>'.
	 * @generated
	 */
	Include createInclude();

	/**
	 * Returns a new object of class '<em>Interact</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interact</em>'.
	 * @generated
	 */
	Interact createInteract();

	/**
	 * Returns a new object of class '<em>Use Case</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Use Case</em>'.
	 * @generated
	 */
	UseCase createUseCase();

	/**
	 * Returns a new object of class '<em>Verification Validation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Verification Validation</em>'.
	 * @generated
	 */
	VerificationValidation createVerificationValidation();

	/**
	 * Returns a new object of class '<em>Verify</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Verify</em>'.
	 * @generated
	 */
	Verify createVerify();

	/**
	 * Returns a new object of class '<em>VV Actual Outcome</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VV Actual Outcome</em>'.
	 * @generated
	 */
	VVActualOutcome createVVActualOutcome();

	/**
	 * Returns a new object of class '<em>VV Case</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VV Case</em>'.
	 * @generated
	 */
	VVCase createVVCase();

	/**
	 * Returns a new object of class '<em>VV Intended Outcome</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VV Intended Outcome</em>'.
	 * @generated
	 */
	VVIntendedOutcome createVVIntendedOutcome();

	/**
	 * Returns a new object of class '<em>VV Log</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VV Log</em>'.
	 * @generated
	 */
	VVLog createVVLog();

	/**
	 * Returns a new object of class '<em>VV Procedure</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VV Procedure</em>'.
	 * @generated
	 */
	VVProcedure createVVProcedure();

	/**
	 * Returns a new object of class '<em>VV Stimuli</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VV Stimuli</em>'.
	 * @generated
	 */
	VVStimuli createVVStimuli();

	/**
	 * Returns a new object of class '<em>VV Target</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VV Target</em>'.
	 * @generated
	 */
	VVTarget createVVTarget();

	/**
	 * Returns a new object of class '<em>VV Case vv Subject</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VV Case vv Subject</em>'.
	 * @generated
	 */
	VVCase_vvSubject createVVCase_vvSubject();

	/**
	 * Returns a new object of class '<em>VV Target element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VV Target element</em>'.
	 * @generated
	 */
	VVTarget_element createVVTarget_element();

	/**
	 * Returns a new object of class '<em>Event Chain</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Chain</em>'.
	 * @generated
	 */
	EventChain createEventChain();

	/**
	 * Returns a new object of class '<em>Non Concurrence Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Non Concurrence Constraint</em>'.
	 * @generated
	 */
	NonConcurrenceConstraint createNonConcurrenceConstraint();

	/**
	 * Returns a new object of class '<em>Non Preemptive Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Non Preemptive Constraint</em>'.
	 * @generated
	 */
	NonPreemptiveConstraint createNonPreemptiveConstraint();

	/**
	 * Returns a new object of class '<em>Precedence Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Precedence Constraint</em>'.
	 * @generated
	 */
	PrecedenceConstraint createPrecedenceConstraint();

	/**
	 * Returns a new object of class '<em>Timing</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Timing</em>'.
	 * @generated
	 */
	Timing createTiming();

	/**
	 * Returns a new object of class '<em>Timing Expression</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Timing Expression</em>'.
	 * @generated
	 */
	TimingExpression createTimingExpression();

	/**
	 * Returns a new object of class '<em>AUTOSAR Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>AUTOSAR Event</em>'.
	 * @generated
	 */
	AUTOSAREvent createAUTOSAREvent();

	/**
	 * Returns a new object of class '<em>Event Fault Failure</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Fault Failure</em>'.
	 * @generated
	 */
	EventFaultFailure createEventFaultFailure();

	/**
	 * Returns a new object of class '<em>Event Feature Flaw</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Feature Flaw</em>'.
	 * @generated
	 */
	EventFeatureFlaw createEventFeatureFlaw();

	/**
	 * Returns a new object of class '<em>Event Function</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Function</em>'.
	 * @generated
	 */
	EventFunction createEventFunction();

	/**
	 * Returns a new object of class '<em>Event Function Client Server Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Function Client Server Port</em>'.
	 * @generated
	 */
	EventFunctionClientServerPort createEventFunctionClientServerPort();

	/**
	 * Returns a new object of class '<em>Event Function Flow Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Function Flow Port</em>'.
	 * @generated
	 */
	EventFunctionFlowPort createEventFunctionFlowPort();

	/**
	 * Returns a new object of class '<em>External Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>External Event</em>'.
	 * @generated
	 */
	ExternalEvent createExternalEvent();

	/**
	 * Returns a new object of class '<em>Mode Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mode Event</em>'.
	 * @generated
	 */
	ModeEvent createModeEvent();

	/**
	 * Returns a new object of class '<em>Event Function function</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Function function</em>'.
	 * @generated
	 */
	EventFunction_function createEventFunction_function();

	/**
	 * Returns a new object of class '<em>Event Function Client Server Port port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Function Client Server Port port</em>'.
	 * @generated
	 */
	EventFunctionClientServerPort_port createEventFunctionClientServerPort_port();

	/**
	 * Returns a new object of class '<em>Event Function Flow Port port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Event Function Flow Port port</em>'.
	 * @generated
	 */
	EventFunctionFlowPort_port createEventFunctionFlowPort_port();

	/**
	 * Returns a new object of class '<em>Age Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Age Constraint</em>'.
	 * @generated
	 */
	AgeConstraint createAgeConstraint();

	/**
	 * Returns a new object of class '<em>Arbitrary Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Arbitrary Constraint</em>'.
	 * @generated
	 */
	ArbitraryConstraint createArbitraryConstraint();

	/**
	 * Returns a new object of class '<em>Burst Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Burst Constraint</em>'.
	 * @generated
	 */
	BurstConstraint createBurstConstraint();

	/**
	 * Returns a new object of class '<em>Comparison Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Comparison Constraint</em>'.
	 * @generated
	 */
	ComparisonConstraint createComparisonConstraint();

	/**
	 * Returns a new object of class '<em>Delay Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Delay Constraint</em>'.
	 * @generated
	 */
	DelayConstraint createDelayConstraint();

	/**
	 * Returns a new object of class '<em>Execution Time Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Execution Time Constraint</em>'.
	 * @generated
	 */
	ExecutionTimeConstraint createExecutionTimeConstraint();

	/**
	 * Returns a new object of class '<em>Input Synchronization Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Input Synchronization Constraint</em>'.
	 * @generated
	 */
	InputSynchronizationConstraint createInputSynchronizationConstraint();

	/**
	 * Returns a new object of class '<em>Order Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Order Constraint</em>'.
	 * @generated
	 */
	OrderConstraint createOrderConstraint();

	/**
	 * Returns a new object of class '<em>Output Synchronization Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Output Synchronization Constraint</em>'.
	 * @generated
	 */
	OutputSynchronizationConstraint createOutputSynchronizationConstraint();

	/**
	 * Returns a new object of class '<em>Pattern Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pattern Constraint</em>'.
	 * @generated
	 */
	PatternConstraint createPatternConstraint();

	/**
	 * Returns a new object of class '<em>Periodic Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Periodic Constraint</em>'.
	 * @generated
	 */
	PeriodicConstraint createPeriodicConstraint();

	/**
	 * Returns a new object of class '<em>Reaction Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Reaction Constraint</em>'.
	 * @generated
	 */
	ReactionConstraint createReactionConstraint();

	/**
	 * Returns a new object of class '<em>Repetition Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Repetition Constraint</em>'.
	 * @generated
	 */
	RepetitionConstraint createRepetitionConstraint();

	/**
	 * Returns a new object of class '<em>Sporadic Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sporadic Constraint</em>'.
	 * @generated
	 */
	SporadicConstraint createSporadicConstraint();

	/**
	 * Returns a new object of class '<em>Strong Delay Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Strong Delay Constraint</em>'.
	 * @generated
	 */
	StrongDelayConstraint createStrongDelayConstraint();

	/**
	 * Returns a new object of class '<em>Strong Synchronization Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Strong Synchronization Constraint</em>'.
	 * @generated
	 */
	StrongSynchronizationConstraint createStrongSynchronizationConstraint();

	/**
	 * Returns a new object of class '<em>Synchronization Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Synchronization Constraint</em>'.
	 * @generated
	 */
	SynchronizationConstraint createSynchronizationConstraint();

	/**
	 * Returns a new object of class '<em>Non Concurrent Constraint exclusive</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Non Concurrent Constraint exclusive</em>'.
	 * @generated
	 */
	NonConcurrentConstraint_exclusive createNonConcurrentConstraint_exclusive();

	/**
	 * Returns a new object of class '<em>Dependability</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dependability</em>'.
	 * @generated
	 */
	Dependability createDependability();

	/**
	 * Returns a new object of class '<em>Feature Flaw</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feature Flaw</em>'.
	 * @generated
	 */
	FeatureFlaw createFeatureFlaw();

	/**
	 * Returns a new object of class '<em>Hazard</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hazard</em>'.
	 * @generated
	 */
	Hazard createHazard();

	/**
	 * Returns a new object of class '<em>Hazardous Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hazardous Event</em>'.
	 * @generated
	 */
	HazardousEvent createHazardousEvent();

	/**
	 * Returns a new object of class '<em>Item</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Item</em>'.
	 * @generated
	 */
	Item createItem();

	/**
	 * Returns a new object of class '<em>Fault Failure</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fault Failure</em>'.
	 * @generated
	 */
	FaultFailure createFaultFailure();

	/**
	 * Returns a new object of class '<em>Quantitative Safety Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Quantitative Safety Constraint</em>'.
	 * @generated
	 */
	QuantitativeSafetyConstraint createQuantitativeSafetyConstraint();

	/**
	 * Returns a new object of class '<em>Safety Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Safety Constraint</em>'.
	 * @generated
	 */
	SafetyConstraint createSafetyConstraint();

	/**
	 * Returns a new object of class '<em>Fault Failure anomaly</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fault Failure anomaly</em>'.
	 * @generated
	 */
	FaultFailure_anomaly createFaultFailure_anomaly();

	/**
	 * Returns a new object of class '<em>Error Behavior</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Error Behavior</em>'.
	 * @generated
	 */
	ErrorBehavior createErrorBehavior();

	/**
	 * Returns a new object of class '<em>Error Model Prototype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Error Model Prototype</em>'.
	 * @generated
	 */
	ErrorModelPrototype createErrorModelPrototype();

	/**
	 * Returns a new object of class '<em>Error Model Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Error Model Type</em>'.
	 * @generated
	 */
	ErrorModelType createErrorModelType();

	/**
	 * Returns a new object of class '<em>Failure Out Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Failure Out Port</em>'.
	 * @generated
	 */
	FailureOutPort createFailureOutPort();

	/**
	 * Returns a new object of class '<em>Fault Failure Propagation Link</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fault Failure Propagation Link</em>'.
	 * @generated
	 */
	FaultFailurePropagationLink createFaultFailurePropagationLink();

	/**
	 * Returns a new object of class '<em>Fault In Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fault In Port</em>'.
	 * @generated
	 */
	FaultInPort createFaultInPort();

	/**
	 * Returns a new object of class '<em>Internal Fault Prototype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Internal Fault Prototype</em>'.
	 * @generated
	 */
	InternalFaultPrototype createInternalFaultPrototype();

	/**
	 * Returns a new object of class '<em>Process Fault Prototype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Process Fault Prototype</em>'.
	 * @generated
	 */
	ProcessFaultPrototype createProcessFaultPrototype();

	/**
	 * Returns a new object of class '<em>Error Model Prototype function Target</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Error Model Prototype function Target</em>'.
	 * @generated
	 */
	ErrorModelPrototype_functionTarget createErrorModelPrototype_functionTarget();

	/**
	 * Returns a new object of class '<em>Error Model Prototype hw Target</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Error Model Prototype hw Target</em>'.
	 * @generated
	 */
	ErrorModelPrototype_hwTarget createErrorModelPrototype_hwTarget();

	/**
	 * Returns a new object of class '<em>Fault Failure Port function Target</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fault Failure Port function Target</em>'.
	 * @generated
	 */
	FaultFailurePort_functionTarget createFaultFailurePort_functionTarget();

	/**
	 * Returns a new object of class '<em>Fault Failure Port hw Target</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fault Failure Port hw Target</em>'.
	 * @generated
	 */
	FaultFailurePort_hwTarget createFaultFailurePort_hwTarget();

	/**
	 * Returns a new object of class '<em>Fault Failure Propagation Link from Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fault Failure Propagation Link from Port</em>'.
	 * @generated
	 */
	FaultFailurePropagationLink_fromPort createFaultFailurePropagationLink_fromPort();

	/**
	 * Returns a new object of class '<em>Fault Failure Propagation Link to Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fault Failure Propagation Link to Port</em>'.
	 * @generated
	 */
	FaultFailurePropagationLink_toPort createFaultFailurePropagationLink_toPort();

	/**
	 * Returns a new object of class '<em>Functional Safety Concept</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Functional Safety Concept</em>'.
	 * @generated
	 */
	FunctionalSafetyConcept createFunctionalSafetyConcept();

	/**
	 * Returns a new object of class '<em>Safety Goal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Safety Goal</em>'.
	 * @generated
	 */
	SafetyGoal createSafetyGoal();

	/**
	 * Returns a new object of class '<em>Technical Safety Concept</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Technical Safety Concept</em>'.
	 * @generated
	 */
	TechnicalSafetyConcept createTechnicalSafetyConcept();

	/**
	 * Returns a new object of class '<em>Claim</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Claim</em>'.
	 * @generated
	 */
	Claim createClaim();

	/**
	 * Returns a new object of class '<em>Ground</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Ground</em>'.
	 * @generated
	 */
	Ground createGround();

	/**
	 * Returns a new object of class '<em>Safety Case</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Safety Case</em>'.
	 * @generated
	 */
	SafetyCase createSafetyCase();

	/**
	 * Returns a new object of class '<em>Warrant</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Warrant</em>'.
	 * @generated
	 */
	Warrant createWarrant();

	/**
	 * Returns a new object of class '<em>Generic Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Generic Constraint</em>'.
	 * @generated
	 */
	GenericConstraint createGenericConstraint();

	/**
	 * Returns a new object of class '<em>Generic Constraint Set</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Generic Constraint Set</em>'.
	 * @generated
	 */
	GenericConstraintSet createGenericConstraintSet();

	/**
	 * Returns a new object of class '<em>Take Rate Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Take Rate Constraint</em>'.
	 * @generated
	 */
	TakeRateConstraint createTakeRateConstraint();

	/**
	 * Returns a new object of class '<em>Comment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Comment</em>'.
	 * @generated
	 */
	Comment createComment();

	/**
	 * Returns a new object of class '<em>EA Package</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Package</em>'.
	 * @generated
	 */
	EAPackage createEAPackage();

	/**
	 * Returns a new object of class '<em>EAXML</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EAXML</em>'.
	 * @generated
	 */
	EAXML createEAXML();

	/**
	 * Returns a new object of class '<em>Rationale</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Rationale</em>'.
	 * @generated
	 */
	Rationale createRationale();

	/**
	 * Returns a new object of class '<em>Realization</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Realization</em>'.
	 * @generated
	 */
	Realization createRealization();

	/**
	 * Returns a new object of class '<em>Realization realized</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Realization realized</em>'.
	 * @generated
	 */
	Realization_realized createRealization_realized();

	/**
	 * Returns a new object of class '<em>Realization realized By</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Realization realized By</em>'.
	 * @generated
	 */
	Realization_realizedBy createRealization_realizedBy();

	/**
	 * Returns a new object of class '<em>Array Datatype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Array Datatype</em>'.
	 * @generated
	 */
	ArrayDatatype createArrayDatatype();

	/**
	 * Returns a new object of class '<em>Composite Datatype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Composite Datatype</em>'.
	 * @generated
	 */
	CompositeDatatype createCompositeDatatype();

	/**
	 * Returns a new object of class '<em>EA Boolean</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Boolean</em>'.
	 * @generated
	 */
	EABoolean createEABoolean();

	/**
	 * Returns a new object of class '<em>EA Datatype Prototype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Datatype Prototype</em>'.
	 * @generated
	 */
	EADatatypePrototype createEADatatypePrototype();

	/**
	 * Returns a new object of class '<em>EA Numerical</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Numerical</em>'.
	 * @generated
	 */
	EANumerical createEANumerical();

	/**
	 * Returns a new object of class '<em>EA String</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA String</em>'.
	 * @generated
	 */
	EAString createEAString();

	/**
	 * Returns a new object of class '<em>Enumeration</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Enumeration</em>'.
	 * @generated
	 */
	Enumeration createEnumeration();

	/**
	 * Returns a new object of class '<em>Enumeration Literal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Enumeration Literal</em>'.
	 * @generated
	 */
	EnumerationLiteral createEnumerationLiteral();

	/**
	 * Returns a new object of class '<em>Quantity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Quantity</em>'.
	 * @generated
	 */
	Quantity createQuantity();

	/**
	 * Returns a new object of class '<em>Rangeable Value Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Rangeable Value Type</em>'.
	 * @generated
	 */
	RangeableValueType createRangeableValueType();

	/**
	 * Returns a new object of class '<em>Unit</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Unit</em>'.
	 * @generated
	 */
	Unit createUnit();

	/**
	 * Returns a new object of class '<em>EA Array Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Array Value</em>'.
	 * @generated
	 */
	EAArrayValue createEAArrayValue();

	/**
	 * Returns a new object of class '<em>EA Boolean Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Boolean Value</em>'.
	 * @generated
	 */
	EABooleanValue createEABooleanValue();

	/**
	 * Returns a new object of class '<em>EA Composite Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Composite Value</em>'.
	 * @generated
	 */
	EACompositeValue createEACompositeValue();

	/**
	 * Returns a new object of class '<em>EA Enumeration Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Enumeration Value</em>'.
	 * @generated
	 */
	EAEnumerationValue createEAEnumerationValue();

	/**
	 * Returns a new object of class '<em>EA Expression</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Expression</em>'.
	 * @generated
	 */
	EAExpression createEAExpression();

	/**
	 * Returns a new object of class '<em>EA Numerical Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA Numerical Value</em>'.
	 * @generated
	 */
	EANumericalValue createEANumericalValue();

	/**
	 * Returns a new object of class '<em>EA String Value</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>EA String Value</em>'.
	 * @generated
	 */
	EAStringValue createEAStringValue();

	/**
	 * Returns a new object of class '<em>User Attribute Definition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>User Attribute Definition</em>'.
	 * @generated
	 */
	UserAttributeDefinition createUserAttributeDefinition();

	/**
	 * Returns a new object of class '<em>User Attributed Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>User Attributed Element</em>'.
	 * @generated
	 */
	UserAttributedElement createUserAttributedElement();

	/**
	 * Returns a new object of class '<em>User Element Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>User Element Type</em>'.
	 * @generated
	 */
	UserElementType createUserElementType();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Binding Attribute</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Binding Attribute</em>'.
	 * @generated
	 */
	BehaviorConstraintBindingAttribute createBehaviorConstraintBindingAttribute();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Binding Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Binding Event</em>'.
	 * @generated
	 */
	BehaviorConstraintBindingEvent createBehaviorConstraintBindingEvent();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Prototype</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Prototype</em>'.
	 * @generated
	 */
	BehaviorConstraintPrototype createBehaviorConstraintPrototype();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Target Binding</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Target Binding</em>'.
	 * @generated
	 */
	BehaviorConstraintTargetBinding createBehaviorConstraintTargetBinding();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Type</em>'.
	 * @generated
	 */
	BehaviorConstraintType createBehaviorConstraintType();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Internal Binding binding Through Function Connector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Internal Binding binding Through Function Connector</em>'.
	 * @generated
	 */
	BehaviorConstraintInternalBinding_bindingThroughFunctionConnector createBehaviorConstraintInternalBinding_bindingThroughFunctionConnector();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Internal Binding binding Through Hardware Connector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Internal Binding binding Through Hardware Connector</em>'.
	 * @generated
	 */
	BehaviorConstraintInternalBinding_bindingThroughHardwareConnector createBehaviorConstraintInternalBinding_bindingThroughHardwareConnector();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Prototype error Model Target</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Prototype error Model Target</em>'.
	 * @generated
	 */
	BehaviorConstraintPrototype_errorModelTarget createBehaviorConstraintPrototype_errorModelTarget();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Prototype function Target</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Prototype function Target</em>'.
	 * @generated
	 */
	BehaviorConstraintPrototype_functionTarget createBehaviorConstraintPrototype_functionTarget();

	/**
	 * Returns a new object of class '<em>Behavior Constraint Prototype hardware Component Target</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Constraint Prototype hardware Component Target</em>'.
	 * @generated
	 */
	BehaviorConstraintPrototype_hardwareComponentTarget createBehaviorConstraintPrototype_hardwareComponentTarget();

	/**
	 * Returns a new object of class '<em>Attribute</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attribute</em>'.
	 * @generated
	 */
	Attribute createAttribute();

	/**
	 * Returns a new object of class '<em>Attribute Quantification Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attribute Quantification Constraint</em>'.
	 * @generated
	 */
	AttributeQuantificationConstraint createAttributeQuantificationConstraint();

	/**
	 * Returns a new object of class '<em>Behavior Attribute Binding</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Behavior Attribute Binding</em>'.
	 * @generated
	 */
	BehaviorAttributeBinding createBehaviorAttributeBinding();

	/**
	 * Returns a new object of class '<em>Logical Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Logical Event</em>'.
	 * @generated
	 */
	LogicalEvent createLogicalEvent();

	/**
	 * Returns a new object of class '<em>Quantification</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Quantification</em>'.
	 * @generated
	 */
	Quantification createQuantification();

	/**
	 * Returns a new object of class '<em>Computation Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Computation Constraint</em>'.
	 * @generated
	 */
	ComputationConstraint createComputationConstraint();

	/**
	 * Returns a new object of class '<em>Logical Path</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Logical Path</em>'.
	 * @generated
	 */
	LogicalPath createLogicalPath();

	/**
	 * Returns a new object of class '<em>Logical Transformation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Logical Transformation</em>'.
	 * @generated
	 */
	LogicalTransformation createLogicalTransformation();

	/**
	 * Returns a new object of class '<em>Transformation Occurrence</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transformation Occurrence</em>'.
	 * @generated
	 */
	TransformationOccurrence createTransformationOccurrence();

	/**
	 * Returns a new object of class '<em>Logical Time Condition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Logical Time Condition</em>'.
	 * @generated
	 */
	LogicalTimeCondition createLogicalTimeCondition();

	/**
	 * Returns a new object of class '<em>State</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>State</em>'.
	 * @generated
	 */
	State createState();

	/**
	 * Returns a new object of class '<em>State Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>State Event</em>'.
	 * @generated
	 */
	StateEvent createStateEvent();

	/**
	 * Returns a new object of class '<em>Synchronous Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Synchronous Transition</em>'.
	 * @generated
	 */
	SynchronousTransition createSynchronousTransition();

	/**
	 * Returns a new object of class '<em>Temporal Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Temporal Constraint</em>'.
	 * @generated
	 */
	TemporalConstraint createTemporalConstraint();

	/**
	 * Returns a new object of class '<em>Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transition</em>'.
	 * @generated
	 */
	Transition createTransition();

	/**
	 * Returns a new object of class '<em>Transition Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transition Event</em>'.
	 * @generated
	 */
	TransitionEvent createTransitionEvent();

	/**
	 * Returns a new object of class '<em>Architectural Description</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Architectural Description</em>'.
	 * @generated
	 */
	ArchitecturalDescription createArchitecturalDescription();

	/**
	 * Returns a new object of class '<em>Architectural Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Architectural Model</em>'.
	 * @generated
	 */
	ArchitecturalModel createArchitecturalModel();

	/**
	 * Returns a new object of class '<em>Architecture</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Architecture</em>'.
	 * @generated
	 */
	Architecture createArchitecture();

	/**
	 * Returns a new object of class '<em>Mission</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mission</em>'.
	 * @generated
	 */
	Mission createMission();

	/**
	 * Returns a new object of class '<em>Vehicle System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vehicle System</em>'.
	 * @generated
	 */
	VehicleSystem createVehicleSystem();

	/**
	 * Returns a new object of class '<em>Stakeholder</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Stakeholder</em>'.
	 * @generated
	 */
	Stakeholder createStakeholder();

	/**
	 * Returns a new object of class '<em>Stakeholder Need</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Stakeholder Need</em>'.
	 * @generated
	 */
	StakeholderNeed createStakeholderNeed();

	/**
	 * Returns a new object of class '<em>Business Opportunity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Business Opportunity</em>'.
	 * @generated
	 */
	BusinessOpportunity createBusinessOpportunity();

	/**
	 * Returns a new object of class '<em>Problem Statement</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Problem Statement</em>'.
	 * @generated
	 */
	ProblemStatement createProblemStatement();

	/**
	 * Returns a new object of class '<em>Product Positioning</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Product Positioning</em>'.
	 * @generated
	 */
	ProductPositioning createProductPositioning();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	Eastadl22Package getEastadl22Package();

} //Eastadl22Factory
