/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Allocateable Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The AllocateableElement is an abstract superclass for elements that are allocateable.
 * 
 * Semantics:
 * The AllocateableElement abstracts all elements that are allocateable.
 * Subclasses of the abstract class AllocateableElement add their own semantics.
 * 
 * Extension: abstract, no extension
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.FunctionModeling.AllocateableElement</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAllocateableElement()
 * @model abstract="true"
 *        annotation="MetaData guid='{0659EB2C-24E9-4789-BEAA-D3581E492DC2}' id='36' EA\040name='AllocateableElement'"
 *        extendedMetaData="name='ALLOCATEABLE-ELEMENT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ALLOCATEABLE-ELEMENTS'"
 * @generated
 */
public interface AllocateableElement extends EObject {
} // AllocateableElement
