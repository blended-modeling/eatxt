/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Behavior Constraint Target Binding</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.BehaviorConstraintTargetBinding</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintTargetBinding#getBehaviorConstraintType <em>Behavior Constraint Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintTargetBinding#getConstrainedErrorModel <em>Constrained Error Model</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintTargetBinding#getConstrainedFunctionTriggering <em>Constrained Function Triggering</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintTargetBinding#getConstrainedFunctionBehavior <em>Constrained Function Behavior</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintTargetBinding#getConstrainedModeBehavior <em>Constrained Mode Behavior</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintTargetBinding#getTargetedHardwareComponentType <em>Targeted Hardware Component Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintTargetBinding#getTargetedFunctionType <em>Targeted Function Type</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.BehaviorConstraintTargetBinding#getTargetedVehicleFeature <em>Targeted Vehicle Feature</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintTargetBinding()
 * @model annotation="MetaData guid='{B7AD91A5-2E21-4014-80E5-1F8AD28BF202}' id='295' EA\040name='BehaviorConstraintTargetBinding'"
 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-TARGET-BINDING' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-TARGET-BINDINGS'"
 * @generated
 */
public interface BehaviorConstraintTargetBinding extends Relationship {
	/**
	 * Returns the value of the '<em><b>Behavior Constraint Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Behavior Constraint Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Behavior Constraint Type</em>' reference.
	 * @see #setBehaviorConstraintType(BehaviorConstraintType)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintTargetBinding_BehaviorConstraintType()
	 * @model required="true"
	 *        annotation="MetaData guid='{14CCB109-39BD-40d6-991C-6774E09A903E}' id='75' EA\040name=''"
	 *        extendedMetaData="name='BEHAVIOR-CONSTRAINT-TYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='BEHAVIOR-CONSTRAINT-TYPE-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	BehaviorConstraintType getBehaviorConstraintType();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.BehaviorConstraintTargetBinding#getBehaviorConstraintType <em>Behavior Constraint Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Behavior Constraint Type</em>' reference.
	 * @see #getBehaviorConstraintType()
	 * @generated
	 */
	void setBehaviorConstraintType(BehaviorConstraintType value);

	/**
	 * Returns the value of the '<em><b>Constrained Error Model</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.ErrorModelType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Constrained Error Model</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Constrained Error Model</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintTargetBinding_ConstrainedErrorModel()
	 * @model annotation="MetaData guid='{F92FD52C-1D07-4ed4-B49B-8BF3555FB59A}' id='201' EA\040name=''"
	 *        extendedMetaData="name='CONSTRAINED-ERROR-MODEL-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONSTRAINED-ERROR-MODEL-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<ErrorModelType> getConstrainedErrorModel();

	/**
	 * Returns the value of the '<em><b>Constrained Function Triggering</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionTrigger}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Constrained Function Triggering</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Constrained Function Triggering</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintTargetBinding_ConstrainedFunctionTriggering()
	 * @model annotation="MetaData guid='{D932BE48-1271-4709-8256-594C4D50ECF1}' id='514' EA\040name=''"
	 *        extendedMetaData="name='CONSTRAINED-FUNCTION-TRIGGERING-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONSTRAINED-FUNCTION-TRIGGERING-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FunctionTrigger> getConstrainedFunctionTriggering();

	/**
	 * Returns the value of the '<em><b>Constrained Function Behavior</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionBehavior}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Constrained Function Behavior</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Constrained Function Behavior</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintTargetBinding_ConstrainedFunctionBehavior()
	 * @model annotation="MetaData guid='{163136A6-10DE-4f72-BECE-EF7A43E2E242}' id='522' EA\040name=''"
	 *        extendedMetaData="name='CONSTRAINED-FUNCTION-BEHAVIOR-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONSTRAINED-FUNCTION-BEHAVIOR-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FunctionBehavior> getConstrainedFunctionBehavior();

	/**
	 * Returns the value of the '<em><b>Constrained Mode Behavior</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.Mode}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Constrained Mode Behavior</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Constrained Mode Behavior</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintTargetBinding_ConstrainedModeBehavior()
	 * @model annotation="MetaData guid='{ED5C2082-EED4-42a3-9119-F39BE0B496DA}' id='523' EA\040name=''"
	 *        extendedMetaData="name='CONSTRAINED-MODE-BEHAVIOR-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONSTRAINED-MODE-BEHAVIOR-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<Mode> getConstrainedModeBehavior();

	/**
	 * Returns the value of the '<em><b>Targeted Hardware Component Type</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.HardwareComponentType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Targeted Hardware Component Type</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Targeted Hardware Component Type</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintTargetBinding_TargetedHardwareComponentType()
	 * @model annotation="MetaData guid='{303FF4EA-4B10-47ec-A19B-4BC7EBD7ADBC}' id='544' EA\040name=''"
	 *        extendedMetaData="name='TARGETED-HARDWARE-COMPONENT-TYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGETED-HARDWARE-COMPONENT-TYPE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<HardwareComponentType> getTargetedHardwareComponentType();

	/**
	 * Returns the value of the '<em><b>Targeted Function Type</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.FunctionType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Targeted Function Type</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Targeted Function Type</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintTargetBinding_TargetedFunctionType()
	 * @model annotation="MetaData guid='{A8DCD721-00A9-4b3e-8996-C1CEC32FE654}' id='643' EA\040name=''"
	 *        extendedMetaData="name='TARGETED-FUNCTION-TYPE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGETED-FUNCTION-TYPE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<FunctionType> getTargetedFunctionType();

	/**
	 * Returns the value of the '<em><b>Targeted Vehicle Feature</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.VehicleFeature}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Targeted Vehicle Feature</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Targeted Vehicle Feature</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getBehaviorConstraintTargetBinding_TargetedVehicleFeature()
	 * @model annotation="MetaData guid='{22F2F0F2-4D3E-49f9-8B96-2E6200382429}' id='696' EA\040name=''"
	 *        extendedMetaData="name='TARGETED-VEHICLE-FEATURE-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TARGETED-VEHICLE-FEATURE-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<VehicleFeature> getTargetedVehicleFeature();

} // BehaviorConstraintTargetBinding
