/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Configuration</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * FeatureConfiguration defines an actual configuration of a FeatureModel, in particular the selection or de-selection of optional features, values for selected parameterized features, and instance creations for cloned features.
 * 
 * Note that configurations of feature models are realized as a specialization of metaclass ConfigurationDecisionModel. This is possible because a ConfigurationDecisionModel also captures the configuration, i.e., of its target feature model(s); while in the standard case of ConfigurationDecisionModel this target-side configuration depends on a given configuration of source feature model(s), here we simply define a "constant" target-side configuration without considering any source configurations. Therefore, the FeatureConfiguration meta-class has additional constraints compared to the super-class ConfigurationDecisionModel: the FeatureConfiguration has no source FeatureModel and only a single target FeatureModel, which serves as the FeatureModel being configured, explicitly defined through association 'configuredFeatureModel'. And since there is no source feature model to which the criterion can refer, all ConfigurationDecisions in a FeatureConfiguration must have "true" as their criterion.
 * 
 * 
 * Semantics:
 * The FeatureConfiguration specifies a concrete configuration of a feature model, in particular which Features of this FeatureModel are selected or deselected.
 * 
 * Extension:
 * Class
 * 
 * Constraint:
 * [1] Attribute criterion of all ConfigurationDecisions in a FeatureConfiguration must be set to "true".
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Variability.FeatureConfiguration</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.FeatureConfiguration#getConfiguredFeatureModel <em>Configured Feature Model</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFeatureConfiguration()
 * @model annotation="MetaData guid='{40234687-1B0F-45b1-A474-7961161B1AFA}' id='95' EA\040name='FeatureConfiguration'"
 *        extendedMetaData="name='FEATURE-CONFIGURATION' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='FEATURE-CONFIGURATIONS'"
 * @generated
 */
public interface FeatureConfiguration extends ConfigurationDecisionModel {
	/**
	 * Returns the value of the '<em><b>Configured Feature Model</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Configured Feature Model</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Configured Feature Model</em>' reference.
	 * @see #setConfiguredFeatureModel(FeatureModel)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getFeatureConfiguration_ConfiguredFeatureModel()
	 * @model required="true"
	 *        annotation="MetaData guid='{943D03FA-F52D-45f2-836E-9CF8D8FBFCCB}' id='702' EA\040name=''"
	 *        extendedMetaData="name='CONFIGURED-FEATURE-MODEL-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='CONFIGURED-FEATURE-MODEL-REFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	FeatureModel getConfiguredFeatureModel();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.FeatureConfiguration#getConfiguredFeatureModel <em>Configured Feature Model</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Configured Feature Model</em>' reference.
	 * @see #getConfiguredFeatureModel()
	 * @generated
	 */
	void setConfiguredFeatureModel(FeatureModel value);

} // FeatureConfiguration
