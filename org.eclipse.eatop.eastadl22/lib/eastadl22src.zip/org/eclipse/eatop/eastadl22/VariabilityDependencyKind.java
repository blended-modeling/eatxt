/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Variability Dependency Kind</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * This enumeration encapsulates the available types of variability constraints 
 * Semantics:
 * Predefined kinds of constraints that apply when a VariabilityDependencyKind is used. Semantics is defined for the respective enumeration literal. 
 * 
 * Extension: 
 * Enumeration, no extension.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.FeatureModeling.VariabilityDependencyKind</b></em> 
 * <!-- end-model-doc -->
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVariabilityDependencyKind()
 * @model annotation="MetaData guid='{6783CF22-5736-42a2-966D-2FFCBA016160}' id='26' EA\040name='VariabilityDependencyKind'"
 *        annotation="Stereotype Stereotype='enumeration'"
 *        extendedMetaData="name='VARIABILITY-DEPENDENCY-KIND'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VARIABILITY-DEPENDENCY-KINDS'"
 * @generated
 */
public enum VariabilityDependencyKind implements Enumerator {
	/**
	 * The '<em><b>Needs</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NEEDS_VALUE
	 * @generated
	 * @ordered
	 */
	NEEDS(0, "needs", "NEEDS"),

	/**
	 * The '<em><b>Excludes</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #EXCLUDES_VALUE
	 * @generated
	 * @ordered
	 */
	EXCLUDES(1, "excludes", "EXCLUDES"),

	/**
	 * The '<em><b>Optional Alternative</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #OPTIONAL_ALTERNATIVE_VALUE
	 * @generated
	 * @ordered
	 */
	OPTIONAL_ALTERNATIVE(2, "optionalAlternative", "OPTIONALALTERNATIVE"),

	/**
	 * The '<em><b>Mandatory Alternative</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MANDATORY_ALTERNATIVE_VALUE
	 * @generated
	 * @ordered
	 */
	MANDATORY_ALTERNATIVE(3, "mandatoryAlternative", "MANDATORYALTERNATIVE"),

	/**
	 * The '<em><b>Suggests</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SUGGESTS_VALUE
	 * @generated
	 * @ordered
	 */
	SUGGESTS(4, "suggests", "SUGGESTS"),

	/**
	 * The '<em><b>Impedes</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #IMPEDES_VALUE
	 * @generated
	 * @ordered
	 */
	IMPEDES(5, "impedes", "IMPEDES"),

	/**
	 * The '<em><b>Custom</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CUSTOM_VALUE
	 * @generated
	 * @ordered
	 */
	CUSTOM(6, "custom", "CUSTOM");

	/**
	 * The '<em><b>Needs</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Needs</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NEEDS
	 * @model name="needs" literal="NEEDS"
	 * @generated
	 * @ordered
	 */
	public static final int NEEDS_VALUE = 0;

	/**
	 * The '<em><b>Excludes</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Excludes</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #EXCLUDES
	 * @model name="excludes" literal="EXCLUDES"
	 * @generated
	 * @ordered
	 */
	public static final int EXCLUDES_VALUE = 1;

	/**
	 * The '<em><b>Optional Alternative</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Optional Alternative</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #OPTIONAL_ALTERNATIVE
	 * @model name="optionalAlternative" literal="OPTIONALALTERNATIVE"
	 * @generated
	 * @ordered
	 */
	public static final int OPTIONAL_ALTERNATIVE_VALUE = 2;

	/**
	 * The '<em><b>Mandatory Alternative</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Mandatory Alternative</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MANDATORY_ALTERNATIVE
	 * @model name="mandatoryAlternative" literal="MANDATORYALTERNATIVE"
	 * @generated
	 * @ordered
	 */
	public static final int MANDATORY_ALTERNATIVE_VALUE = 3;

	/**
	 * The '<em><b>Suggests</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Suggests</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SUGGESTS
	 * @model name="suggests" literal="SUGGESTS"
	 * @generated
	 * @ordered
	 */
	public static final int SUGGESTS_VALUE = 4;

	/**
	 * The '<em><b>Impedes</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Impedes</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #IMPEDES
	 * @model name="impedes" literal="IMPEDES"
	 * @generated
	 * @ordered
	 */
	public static final int IMPEDES_VALUE = 5;

	/**
	 * The '<em><b>Custom</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Custom</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CUSTOM
	 * @model name="custom" literal="CUSTOM"
	 * @generated
	 * @ordered
	 */
	public static final int CUSTOM_VALUE = 6;

	/**
	 * An array of all the '<em><b>Variability Dependency Kind</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final VariabilityDependencyKind[] VALUES_ARRAY =
		new VariabilityDependencyKind[] {
			NEEDS,
			EXCLUDES,
			OPTIONAL_ALTERNATIVE,
			MANDATORY_ALTERNATIVE,
			SUGGESTS,
			IMPEDES,
			CUSTOM,
		};

	/**
	 * A public read-only list of all the '<em><b>Variability Dependency Kind</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<VariabilityDependencyKind> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Variability Dependency Kind</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static VariabilityDependencyKind get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			VariabilityDependencyKind result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Variability Dependency Kind</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static VariabilityDependencyKind getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			VariabilityDependencyKind result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Variability Dependency Kind</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static VariabilityDependencyKind get(int value) {
		switch (value) {
			case NEEDS_VALUE: return NEEDS;
			case EXCLUDES_VALUE: return EXCLUDES;
			case OPTIONAL_ALTERNATIVE_VALUE: return OPTIONAL_ALTERNATIVE;
			case MANDATORY_ALTERNATIVE_VALUE: return MANDATORY_ALTERNATIVE;
			case SUGGESTS_VALUE: return SUGGESTS;
			case IMPEDES_VALUE: return IMPEDES;
			case CUSTOM_VALUE: return CUSTOM;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private VariabilityDependencyKind(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //VariabilityDependencyKind