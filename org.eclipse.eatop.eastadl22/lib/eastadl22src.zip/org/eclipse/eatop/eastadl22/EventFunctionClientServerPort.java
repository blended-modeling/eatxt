/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Function Client Server Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Event that refers to the occurrence of data being sent or received at the client/server port, according to the attribute eventKind, i.e., when the input data is sent / received, or when the output data is produced / received.
 * 
 * Constraints:
 * [1] eventKind is sentRequest or receivedResponse for a FunctionClientServerPort of type client. Rationale: Only these values make sense for client ports.
 * 
 * [2] eventKind is receivedRequest or sentResponse for a FunctionClientServerPort of type server. Rationale: Only these values make sense for server ports.
 * 
 * Semantics:
 * EventFunctionClientServerPort refers to the time when data is sent or received at the ClientServerPort.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Timing.Events.EventFunctionClientServerPort</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPort#getEventKind <em>Event Kind</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPort#getPort <em>Port</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunctionClientServerPort()
 * @model annotation="MetaData guid='{141B59C7-1164-4e3c-9CBF-E6D58397E1AC}' id='152' EA\040name='EventFunctionClientServerPort'"
 *        extendedMetaData="name='EVENT-FUNCTION-CLIENT-SERVER-PORT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-FUNCTION-CLIENT-SERVER-PORTS'"
 * @generated
 */
public interface EventFunctionClientServerPort extends EAExpression, Event {
	/**
	 * Returns the value of the '<em><b>Event Kind</b></em>' attribute.
	 * The default value is <code>"SENTREQUEST"</code>.
	 * The literals are from the enumeration {@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPortKind}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Event Kind</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event Kind</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.EventFunctionClientServerPortKind
	 * @see #isSetEventKind()
	 * @see #unsetEventKind()
	 * @see #setEventKind(EventFunctionClientServerPortKind)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunctionClientServerPort_EventKind()
	 * @model default="SENTREQUEST" unsettable="true" required="true"
	 *        annotation="MetaData guid='{2EE61057-F2A8-4a7b-BF0A-C34D0E9E100A}' id='104' EA\040name='eventKind'"
	 *        extendedMetaData="name='EVENT-KIND' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EVENT-KINDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EventFunctionClientServerPortKind getEventKind();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPort#getEventKind <em>Event Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event Kind</em>' attribute.
	 * @see org.eclipse.eatop.eastadl22.EventFunctionClientServerPortKind
	 * @see #isSetEventKind()
	 * @see #EventKind()
	 * @see #getEventKind()
	 * @generated
	 */
	void setEventKind(EventFunctionClientServerPortKind value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPort#getEventKind <em>Event Kind</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetEventKind()
	 * @see #getEventKind()
	 * @see #setEventKind(EventFunctionClientServerPortKind)
	 * @generated
	 */
	void unsetEventKind();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPort#getEventKind <em>Event Kind</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Event Kind</em>' attribute is set.
	 * @see #EventKind()
	 * @see #getEventKind()
	 * @see #setEventKind(EventFunctionClientServerPortKind)
	 * @generated
	 */
	boolean isSetEventKind();

	/**
	 * Returns the value of the '<em><b>Port</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Port</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port</em>' containment reference.
	 * @see #setPort(EventFunctionClientServerPort_port)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getEventFunctionClientServerPort_Port()
	 * @model containment="true" required="true"
	 *        annotation="MetaData guid='{84F761DA-FC94-4077-9768-D1D66FA719B7}' id='289' EA\040name=''"
	 *        annotation="TaggedValues xml.name='PORT-IREF' xml.namePlural='PORT-IREFS' xml.roleElement='true' xml.typeElement='false' xml.typeWrapperElement='false'"
	 *        extendedMetaData="name='PORT-IREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='PORT-IREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EventFunctionClientServerPort_port getPort();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.EventFunctionClientServerPort#getPort <em>Port</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Port</em>' containment reference.
	 * @see #getPort()
	 * @generated
	 */
	void setPort(EventFunctionClientServerPort_port value);

} // EventFunctionClientServerPort
