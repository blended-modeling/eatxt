/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Architectural Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * A view may consist of one or more architectural models. Each such architectural model is developed using the methods established by its associated architectural viewpoint. An architectural model may participate in more than one view. [IEEE 1471] 
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.Needs.ArchitecturalModel</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ArchitecturalModel#getIsConceptFor <em>Is Concept For</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArchitecturalModel()
 * @model annotation="MetaData guid='{34ACDFCD-0B2F-4410-9376-98CE5B3CA642}' id='326' EA\040name='ArchitecturalModel'"
 *        extendedMetaData="name='ARCHITECTURAL-MODEL' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ARCHITECTURAL-MODELS'"
 * @generated
 */
public interface ArchitecturalModel extends Concept {
	/**
	 * Returns the value of the '<em><b>Is Concept For</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.SystemModel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Concept For</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Concept For</em>' reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getArchitecturalModel_IsConceptFor()
	 * @model annotation="MetaData guid='{191F0CD2-10F0-425a-B7FA-6957456837D6}' id='724' EA\040name=''"
	 *        extendedMetaData="name='IS-CONCEPT-FOR-REF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-CONCEPT-FOR-REFS' xmlAttribute='false' featureWrapperElement='true' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EList<SystemModel> getIsConceptFor();

} // ArchitecturalModel
