/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Computation Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Computation constraints (ComputationConstraint) provide the language support for specifying the restrictions on data processing, especially when the details of design are not available (e.g. for the reasons of software component IP-protection). The descriptions can be related both to the expected logical transformations of data and to the expected cause-effect flow of events.
 * 
 * Constraints:
 * [1] A computation constraint contains at least one transformation or one flow definition.
 * 
 * Semantics:
 * The EAST-ADL computation constraint is a pair/tuple of: 1. a set of restrictions on the logical transformations of data, 2. a set of restrictions on the cause-effect paths logical transformations.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.ComputationConstraint.ComputationConstraint</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.ComputationConstraint#getLogicalPath <em>Logical Path</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.ComputationConstraint#getLogicalTransformation <em>Logical Transformation</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getComputationConstraint()
 * @model annotation="MetaData guid='{808AED00-3236-404d-8C28-A55847912B3B}' id='314' EA\040name='ComputationConstraint'"
 *        extendedMetaData="name='COMPUTATION-CONSTRAINT' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='COMPUTATION-CONSTRAINTS'"
 * @generated
 */
public interface ComputationConstraint extends EAElement {
	/**
	 * Returns the value of the '<em><b>Logical Path</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.LogicalPath}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Logical Path</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Logical Path</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getComputationConstraint_LogicalPath()
	 * @model containment="true"
	 *        annotation="MetaData guid='{1BBCAC65-730E-48ed-97CF-4C0579FF9F78}' id='36' EA\040name=''"
	 *        extendedMetaData="name='LOGICAL-PATH' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOGICAL-PATHS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<LogicalPath> getLogicalPath();

	/**
	 * Returns the value of the '<em><b>Logical Transformation</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.eatop.eastadl22.LogicalTransformation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Logical Transformation</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Logical Transformation</em>' containment reference list.
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getComputationConstraint_LogicalTransformation()
	 * @model containment="true"
	 *        annotation="MetaData guid='{7DCA83E4-B1FB-48e9-8035-99F7B5020E68}' id='38' EA\040name=''"
	 *        extendedMetaData="name='LOGICAL-TRANSFORMATION' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='LOGICAL-TRANSFORMATIONS' xmlAttribute='false' featureWrapperElement='true' featureElement='false' classifierWrapperElement='false' classifierElement='true'"
	 * @generated
	 */
	EList<LogicalTransformation> getLogicalTransformation();

} // ComputationConstraint
