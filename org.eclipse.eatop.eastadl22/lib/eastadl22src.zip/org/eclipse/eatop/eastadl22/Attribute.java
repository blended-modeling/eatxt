/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * The attribute (Attribute) denotes a parameter or argument of a behavior constraint specification. An attribute can be a constant, simple, or complex data, given by the corresponding EAST-ADL data types (EADataType) for the related meta-information like unit, valid range, required accuracy, etc. 
 * 
 * An attribute can represent an in-, out-, or local-quantity to be processed. If an attribute is externally visible (isExternVisible = true), it denotes an input or output variable and has associated structural ports given by the function ports for the external accesses.
 * 
 * Attributes are instantiation parameters (BehaviorInstantiationParameter), to which certain values can be assigned when a behavior constraint type is instantiated as behavior constraint instances (i.e. prototypes) in certain specification contexts.
 * 
 * Constraints:
 * [1] An attribute must be typed by EADataType.
 * 
 * Semantics:
 * The attributes of a behavior constraint specification is a subset of elements in the vector space of R^n, where R is the real number and n is a natural number defining the dimension of vector space.
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Annexes.BehaviorDescription.AttributeQuantificationConstraint.Attribute</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.Attribute#getIsExternVisible <em>Is Extern Visible</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.Attribute#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAttribute()
 * @model annotation="MetaData guid='{A3212064-0272-4e9a-9D71-4BCC526D7939}' id='310' EA\040name='Attribute'"
 *        annotation="Stereotype Stereotype='atpPrototype'"
 *        extendedMetaData="name='ATTRIBUTE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='ATTRIBUTES'"
 * @generated
 */
public interface Attribute extends BehaviorConstraintParameter, EAElement {
	/**
	 * Returns the value of the '<em><b>Is Extern Visible</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Extern Visible</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Extern Visible</em>' attribute.
	 * @see #isSetIsExternVisible()
	 * @see #unsetIsExternVisible()
	 * @see #setIsExternVisible(Boolean)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAttribute_IsExternVisible()
	 * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Boolean" required="true"
	 *        annotation="MetaData guid='{C35316A5-5066-4887-8170-9A1D505C46D8}' id='212' EA\040name='isExternVisible'"
	 *        extendedMetaData="name='IS-EXTERN-VISIBLE' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-EXTERN-VISIBLES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Boolean getIsExternVisible();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Attribute#getIsExternVisible <em>Is Extern Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Extern Visible</em>' attribute.
	 * @see #isSetIsExternVisible()
	 * @see #IsExternVisible()
	 * @see #getIsExternVisible()
	 * @generated
	 */
	void setIsExternVisible(Boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.Attribute#getIsExternVisible <em>Is Extern Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsExternVisible()
	 * @see #getIsExternVisible()
	 * @see #setIsExternVisible(Boolean)
	 * @generated
	 */
	void unsetIsExternVisible();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.Attribute#getIsExternVisible <em>Is Extern Visible</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Extern Visible</em>' attribute is set.
	 * @see #IsExternVisible()
	 * @see #getIsExternVisible()
	 * @see #setIsExternVisible(Boolean)
	 * @generated
	 */
	boolean isSetIsExternVisible();

	/**
	 * Returns the value of the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' reference.
	 * @see #setType(EADatatype)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getAttribute_Type()
	 * @model required="true"
	 *        annotation="MetaData guid='{9AD7D39C-17B7-48fb-95BF-2D9A7C7CECFA}' id='114' EA\040name=''"
	 *        annotation="Stereotype Stereotype='isOfType'"
	 *        extendedMetaData="name='TYPE-TREF' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='TYPE-TREFS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	EADatatype getType();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.Attribute#getType <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(EADatatype value);

} // Attribute
