/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl22;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vehicle Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * VehicleFeature represents a special kind of feature intended for use on Vehicle Level. The main difference to features in general is that they provide support for the multi-level concept (via their DeviationAttributeSet) and several additional attributes with meta-information specific to the vehicle level viewpoint.
 * 
 * Constraints:
 * [1] VehicleFeatures can only be contained in FeatureModels on VehicleLevel.
 * 
 * Semantics:
 * A VehicleFeature is a functional or non-functional characteristic, constraint or property that can be present or not in a vehicle product line on the level of the complete system, i.e. vehicle.
 * 
 * Extension:
 * Class
 * 
 * Original fully qualified name: 
 * <em><b>eastadl22.EAST-ADL.Structure.VehicleFeatureModeling.VehicleFeature</b></em> 
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsCustomerVisible <em>Is Customer Visible</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsDesignVariabilityRationale <em>Is Design Variability Rationale</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsRemoved <em>Is Removed</em>}</li>
 *   <li>{@link org.eclipse.eatop.eastadl22.VehicleFeature#getDeviationAttributeSet <em>Deviation Attribute Set</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleFeature()
 * @model annotation="MetaData guid='{63313F22-09B0-4b41-A2DE-BBD56140AE06}' id='32' EA\040name='VehicleFeature'"
 *        extendedMetaData="name='VEHICLE-FEATURE' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='VEHICLE-FEATURES'"
 * @generated
 */
public interface VehicleFeature extends Feature {
	/**
	 * Returns the value of the '<em><b>Is Customer Visible</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This attribute states whether the VehicleFeature is customer visible (in contrast to a VehicleFeature that is e.g. technically driven).
	 * 
	 * VehicleFeatures describe the system's characteristics on the level of the complete system and on a high abstraction level but they can still have a strong technical viewpoint. Therefore, they are usually not suitable for being directly presented to the end-customer. There are two approaches to deal with this situation.
	 * 
	 * (1) The simple approach uses this attribute to denote those VehicleFeatures that are suitable for immediate end-customer configuration: if this attribute is set to true, then the feature will be directly presented to the end-customer for selection or de-selection; if set to false, then the feature will be hidden from the end-customer and is thus reserved for internal configuration.
	 * 
	 * (2) The more sophisticated approach is to define a dedicated product feature model to capture the customer viewpoint (available in the variability extension) in addition to the technical feature model on Vehicle Level and to provide a configuration decision model that maps configurations of this end-customer-oriented product feature model to the core technical feature model on Vehicle Level. This approach is much more flexible because the customer-view on the product line's variability can be structured freely and independently from the core technical feature model; furthermore, this approach can cope much better with evolution because the end-customer-oriented feature model can be evolved independently of the core technical feature model (and vice versa). When applying this second approach, this attribute isCustomerVisible will no longer be used, i.e., its value will be ignored.
	 * 
	 * The simple approach #1 is suitable for simple product line scenarios. Approach #2 should be used for complex scenarios with large core technical feature models and/or longer evolution periods of the overall product line infrastructure.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Customer Visible</em>' attribute.
	 * @see #isSetIsCustomerVisible()
	 * @see #unsetIsCustomerVisible()
	 * @see #setIsCustomerVisible(Boolean)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleFeature_IsCustomerVisible()
	 * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Boolean" required="true"
	 *        annotation="MetaData guid='{6F109417-439C-4901-912A-8D9850DC5956}' id='20' EA\040name='isCustomerVisible'"
	 *        extendedMetaData="name='IS-CUSTOMER-VISIBLE' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-CUSTOMER-VISIBLES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Boolean getIsCustomerVisible();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsCustomerVisible <em>Is Customer Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Customer Visible</em>' attribute.
	 * @see #isSetIsCustomerVisible()
	 * @see #IsCustomerVisible()
	 * @see #getIsCustomerVisible()
	 * @generated
	 */
	void setIsCustomerVisible(Boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsCustomerVisible <em>Is Customer Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsCustomerVisible()
	 * @see #getIsCustomerVisible()
	 * @see #setIsCustomerVisible(Boolean)
	 * @generated
	 */
	void unsetIsCustomerVisible();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsCustomerVisible <em>Is Customer Visible</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Customer Visible</em>' attribute is set.
	 * @see #IsCustomerVisible()
	 * @see #getIsCustomerVisible()
	 * @see #setIsCustomerVisible(Boolean)
	 * @generated
	 */
	boolean isSetIsCustomerVisible();

	/**
	 * Returns the value of the '<em><b>Is Design Variability Rationale</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * A VehicleFeature marked as a design variability rationale captures a variant showing up on a concrete artifact level that needs to be modeled on the Vehicle Level as well, in order to be directly available for immediate configuration on Vehicle Level. It is, from the abstraction layer's point of view, not a true Vehicle Level feature.
	 * 
	 * If true, then isCustomerVisible is usually false but there may be rare exceptions.
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Design Variability Rationale</em>' attribute.
	 * @see #isSetIsDesignVariabilityRationale()
	 * @see #unsetIsDesignVariabilityRationale()
	 * @see #setIsDesignVariabilityRationale(Boolean)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleFeature_IsDesignVariabilityRationale()
	 * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Boolean" required="true"
	 *        annotation="MetaData guid='{A4360209-77A2-4a47-A9D7-AD10B89B4720}' id='21' EA\040name='isDesignVariabilityRationale'"
	 *        extendedMetaData="name='IS-DESIGN-VARIABILITY-RATIONALE' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-DESIGN-VARIABILITY-RATIONALES' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Boolean getIsDesignVariabilityRationale();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsDesignVariabilityRationale <em>Is Design Variability Rationale</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Design Variability Rationale</em>' attribute.
	 * @see #isSetIsDesignVariabilityRationale()
	 * @see #IsDesignVariabilityRationale()
	 * @see #getIsDesignVariabilityRationale()
	 * @generated
	 */
	void setIsDesignVariabilityRationale(Boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsDesignVariabilityRationale <em>Is Design Variability Rationale</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsDesignVariabilityRationale()
	 * @see #getIsDesignVariabilityRationale()
	 * @see #setIsDesignVariabilityRationale(Boolean)
	 * @generated
	 */
	void unsetIsDesignVariabilityRationale();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsDesignVariabilityRationale <em>Is Design Variability Rationale</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Design Variability Rationale</em>' attribute is set.
	 * @see #IsDesignVariabilityRationale()
	 * @see #getIsDesignVariabilityRationale()
	 * @see #setIsDesignVariabilityRationale(Boolean)
	 * @generated
	 */
	boolean isSetIsDesignVariabilityRationale();

	/**
	 * Returns the value of the '<em><b>Is Removed</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * This attribute describes if the VehicleFeature is removed (but kept in the database for tracking of evolution, which is required by the multi-level concept).
	 * <!-- end-model-doc -->
	 * @return the value of the '<em>Is Removed</em>' attribute.
	 * @see #isSetIsRemoved()
	 * @see #unsetIsRemoved()
	 * @see #setIsRemoved(Boolean)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleFeature_IsRemoved()
	 * @model default="false" unsettable="true" dataType="org.eclipse.eatop.eastadl22.Boolean" required="true"
	 *        annotation="MetaData guid='{3A830766-E514-4872-841D-71788BDE530C}' id='22' EA\040name='isRemoved'"
	 *        extendedMetaData="name='IS-REMOVED' kind='element'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='IS-REMOVEDS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	Boolean getIsRemoved();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsRemoved <em>Is Removed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Removed</em>' attribute.
	 * @see #isSetIsRemoved()
	 * @see #IsRemoved()
	 * @see #getIsRemoved()
	 * @generated
	 */
	void setIsRemoved(Boolean value);

	/**
	 * Unsets the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsRemoved <em>Is Removed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetIsRemoved()
	 * @see #getIsRemoved()
	 * @see #setIsRemoved(Boolean)
	 * @generated
	 */
	void unsetIsRemoved();

	/**
	 * Returns whether the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getIsRemoved <em>Is Removed</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Is Removed</em>' attribute is set.
	 * @see #IsRemoved()
	 * @see #getIsRemoved()
	 * @see #setIsRemoved(Boolean)
	 * @generated
	 */
	boolean isSetIsRemoved();

	/**
	 * Returns the value of the '<em><b>Deviation Attribute Set</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Deviation Attribute Set</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Deviation Attribute Set</em>' containment reference.
	 * @see #setDeviationAttributeSet(DeviationAttributeSet)
	 * @see org.eclipse.eatop.eastadl22.Eastadl22Package#getVehicleFeature_DeviationAttributeSet()
	 * @model containment="true"
	 *        annotation="MetaData guid='{7F6A0461-823D-4454-9C85-EB2BC28BB651}' id='694' EA\040name=''"
	 *        extendedMetaData="name='DEVIATION-ATTRIBUTE-SET' kind='element' namespace='http://east-adl.info/2.2.0'"
	 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='DEVIATION-ATTRIBUTE-SETS' xmlAttribute='false' featureWrapperElement='false' featureElement='true' classifierWrapperElement='false' classifierElement='false'"
	 * @generated
	 */
	DeviationAttributeSet getDeviationAttributeSet();

	/**
	 * Sets the value of the '{@link org.eclipse.eatop.eastadl22.VehicleFeature#getDeviationAttributeSet <em>Deviation Attribute Set</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Deviation Attribute Set</em>' containment reference.
	 * @see #getDeviationAttributeSet()
	 * @generated
	 */
	void setDeviationAttributeSet(DeviationAttributeSet value);

} // VehicleFeature
