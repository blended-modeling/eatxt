/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.util;

import org.eclipse.eatop.common.metamodel.EastADLMetaModelVersionData;
import org.eclipse.eatop.common.metamodel.EastADLReleaseDescriptor;

import org.eclipse.eatop.common.resource.impl.EastADLResourceFactoryImpl;

import org.eclipse.eatop.eastadl21.Activator;

import org.eclipse.emf.common.util.URI;

import org.eclipse.emf.ecore.resource.Resource;

import org.eclipse.emf.ecore.xmi.XMLResource;

/**
 * <!-- begin-user-doc -->
 * The <b>Resource Factory</b> associated with the package.
 * <!-- end-user-doc -->
 * @see org.eclipse.eatop.eastadl21.util.Eastadl21ResourceImpl
 * @generated
 */
public class Eastadl21ResourceFactoryImpl extends EastADLResourceFactoryImpl {
	
	
	public static final EastADLReleaseDescriptor EAST_ADL_2_1_10_RESOURCE_DESCRIPTOR = new EastADL2110ResourceDescriptor();
	
	
	
	public static final EastADLReleaseDescriptor EAST_ADL_2_1_11_RESOURCE_DESCRIPTOR = new EastADL2111ResourceDescriptor();
	
	
	
	public static final EastADLReleaseDescriptor EAST_ADL_2_1_12_RESOURCE_DESCRIPTOR = Eastadl21ReleaseDescriptor.INSTANCE;	
	
	
	/**
	 * Creates an instance of the resource factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Eastadl21ResourceFactoryImpl() {
		super(Eastadl21ReleaseDescriptor.INSTANCE);
	}

	/**
	 * Creates an instance of the resource.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Resource createResource(URI uri) {
        XMLResource result = new Eastadl21ResourceImpl(uri);
        initResource(result);
        return result;
	}
	
	
	
	private static class EastADL2110ResourceDescriptor extends EastADLReleaseDescriptor {
  	
		private static final String ID = "org.eclipse.eatop.eastadl2110";
		private static final String NS_POSTFIX = "2.1.10";
		private static final String EPKG_PATTERN = "2\\.1\\.10(/\\w+)+";
		private static final String NAME = "EAST-ADL 2.1.10";
		private static final int MAJOR = 2;
		private static final int MINOR = 1;
		private static final int REVISION = 10;
		private static final int ORDINAL = 220;
		
		private EastADL2110ResourceDescriptor() {
			super(ID, new EastADLMetaModelVersionData(NAME, MAJOR, MINOR, REVISION));
		}

		
		@Override
		public String getDefaultContentTypeId() {
			return getRootEPackageContentTypeId();
		}
	}
	
	
	
	
	private static class EastADL2111ResourceDescriptor extends EastADLReleaseDescriptor {
  	
		private static final String ID = "org.eclipse.eatop.eastadl2111";
		private static final String NS_POSTFIX = "2.1.11";
		private static final String EPKG_PATTERN = "2\\.1\\.11(/\\w+)+";
		private static final String NAME = "EAST-ADL 2.1.11";
		private static final int MAJOR = 2;
		private static final int MINOR = 1;
		private static final int REVISION = 11;
		private static final int ORDINAL = 221;
		
		private EastADL2111ResourceDescriptor() {
			super(ID, new EastADLMetaModelVersionData(NAME, MAJOR, MINOR, REVISION));
		}

		
		@Override
		public String getDefaultContentTypeId() {
			return getRootEPackageContentTypeId();
		}
	}
	
	
	
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.artop.aal.common.resource.impl.EastADLResourceFactoryImpl#initSchemaLocationBaseURIs()
	 * @generated
	 */
	
	@Override
	protected void initSchemaLocationBaseURIs() {
		schemaLocationURIHandler.addSchemaLocationBaseURI(Activator.getPlugin(), "model"); //$NON-NLS-1$
	}
} //Eastadl21ResourceFactoryImpl
