/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.eclipse.eatop.common.metamodel.EastADLMetaModelVersionData;
import org.eclipse.eatop.common.metamodel.EastADLReleaseDescriptor;

import org.eclipse.sphinx.emf.metamodel.IMetaModelDescriptor;

public class Eastadl21ReleaseDescriptor extends EastADLReleaseDescriptor {
	
	/**
	 * The id of the content type for EAST-ADL 2.1.12 XML files.
	 */
	public static final String EAXML_CONTENT_TYPE_ID = "org.eclipse.eatop.eastadl21.eastadl21XMLFile"; //$NON-NLS-1$

	/**
	 * Identifier.
	 */
	private static final String ID = "org.eclipse.eatop.eastadl21";
	private static final String NAME = "EAST-ADL 2.1.12";
	private static final int MAJOR = 2;
	private static final int MINOR = 1;
	private static final int REVISION = 12;

	/**
	 * Default instance.
	 */
	public static final Eastadl21ReleaseDescriptor INSTANCE = new Eastadl21ReleaseDescriptor();

	/**
	 * Default constructor.
	 */
	public Eastadl21ReleaseDescriptor() {
		super(ID, new EastADLMetaModelVersionData(NAME, MAJOR, MINOR, REVISION));
	}
	
	@Override
	public String getDefaultContentTypeId() {
		return EAXML_CONTENT_TYPE_ID;
	}

	@Override
	public  Collection<IMetaModelDescriptor> getCompatibleResourceVersionDescriptors() {
		List<IMetaModelDescriptor> result = new ArrayList<IMetaModelDescriptor>();
		result.add(Eastadl21ResourceFactoryImpl.EAST_ADL_2_1_10_RESOURCE_DESCRIPTOR);
		result.add(Eastadl21ResourceFactoryImpl.EAST_ADL_2_1_11_RESOURCE_DESCRIPTOR);
		result.add(Eastadl21ResourceFactoryImpl.EAST_ADL_2_1_12_RESOURCE_DESCRIPTOR);
		return Collections.unmodifiableList(result);
	}   
}