/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.util;

import org.eclipse.eatop.eastadl21.Eastadl21Package;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 */
public class Eastadl21Factory extends EFactoryImpl implements EFactory {

    public static final Eastadl21Factory eINSTANCE = new Eastadl21Factory();

    /**
    * Returns the value of the '<em><b>EPackage</b></em>' reference.
    */
    @Override
    public EPackage getEPackage() {
        if (ePackage == null) {
            ePackage = Eastadl21Package.eINSTANCE;
        }
        return ePackage;
    }
	
    /**
    * <!-- begin-user-doc -->
    * Creates a new instance of the class and returns it.
    * Ask the package the list of its classifiers. Given these classifiers, ask their packages what their factories are.
    * @param eClass the class of the new instance.
    * @return a new instance of the class.
    * <!-- end-user-doc -->
    */
    @Override
    public EObject create(EClass eClass) {
        EObject result = null;

        if (eClass.eContainer() instanceof EPackage) {
            result = ((EPackage) eClass.eContainer()).getEFactoryInstance().create(eClass);
        }
        return result;
    }
	
    public org.eclipse.eatop.eastadl21.Allocation createAllocation() {
        org.eclipse.eatop.eastadl21.Allocation allocation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createAllocation();
        allocation.setUuid(java.util.UUID.randomUUID().toString());
        return allocation;
    }
    
    public org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType createBasicSoftwareFunctionType() {
        org.eclipse.eatop.eastadl21.BasicSoftwareFunctionType basicSoftwareFunctionType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createBasicSoftwareFunctionType();
        basicSoftwareFunctionType.setUuid(java.util.UUID.randomUUID().toString());
        return basicSoftwareFunctionType;
    }
    
    public org.eclipse.eatop.eastadl21.DesignFunctionPrototype createDesignFunctionPrototype() {
        org.eclipse.eatop.eastadl21.DesignFunctionPrototype designFunctionPrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createDesignFunctionPrototype();
        designFunctionPrototype.setUuid(java.util.UUID.randomUUID().toString());
        return designFunctionPrototype;
    }
    
    public org.eclipse.eatop.eastadl21.DesignFunctionType createDesignFunctionType() {
        org.eclipse.eatop.eastadl21.DesignFunctionType designFunctionType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createDesignFunctionType();
        designFunctionType.setUuid(java.util.UUID.randomUUID().toString());
        return designFunctionType;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionAllocation createFunctionAllocation() {
        org.eclipse.eatop.eastadl21.FunctionAllocation functionAllocation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionAllocation();
        functionAllocation.setUuid(java.util.UUID.randomUUID().toString());
        return functionAllocation;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionClientServerInterface createFunctionClientServerInterface() {
        org.eclipse.eatop.eastadl21.FunctionClientServerInterface functionClientServerInterface = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionClientServerInterface();
        functionClientServerInterface.setUuid(java.util.UUID.randomUUID().toString());
        return functionClientServerInterface;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionClientServerPort createFunctionClientServerPort() {
        org.eclipse.eatop.eastadl21.FunctionClientServerPort functionClientServerPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionClientServerPort();
        functionClientServerPort.setUuid(java.util.UUID.randomUUID().toString());
        return functionClientServerPort;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionConnector createFunctionConnector() {
        org.eclipse.eatop.eastadl21.FunctionConnector functionConnector = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionConnector();
        functionConnector.setUuid(java.util.UUID.randomUUID().toString());
        return functionConnector;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionFlowPort createFunctionFlowPort() {
        org.eclipse.eatop.eastadl21.FunctionFlowPort functionFlowPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionFlowPort();
        functionFlowPort.setUuid(java.util.UUID.randomUUID().toString());
        return functionFlowPort;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionPowerPort createFunctionPowerPort() {
        org.eclipse.eatop.eastadl21.FunctionPowerPort functionPowerPort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionPowerPort();
        functionPowerPort.setUuid(java.util.UUID.randomUUID().toString());
        return functionPowerPort;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareFunctionType createHardwareFunctionType() {
        org.eclipse.eatop.eastadl21.HardwareFunctionType hardwareFunctionType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareFunctionType();
        hardwareFunctionType.setUuid(java.util.UUID.randomUUID().toString());
        return hardwareFunctionType;
    }
    
    public org.eclipse.eatop.eastadl21.LocalDeviceManager createLocalDeviceManager() {
        org.eclipse.eatop.eastadl21.LocalDeviceManager localDeviceManager = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createLocalDeviceManager();
        localDeviceManager.setUuid(java.util.UUID.randomUUID().toString());
        return localDeviceManager;
    }
    
    public org.eclipse.eatop.eastadl21.Operation createOperation() {
        org.eclipse.eatop.eastadl21.Operation operation = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createOperation();
        operation.setUuid(java.util.UUID.randomUUID().toString());
        return operation;
    }
    
    public org.eclipse.eatop.eastadl21.PortGroup createPortGroup() {
        org.eclipse.eatop.eastadl21.PortGroup portGroup = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPortGroup();
        portGroup.setUuid(java.util.UUID.randomUUID().toString());
        return portGroup;
    }
    
    public org.eclipse.eatop.eastadl21.FunctionAllocation_allocatedElement createFunctionAllocation_allocatedElement() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionAllocation_allocatedElement();
    }
    
    public org.eclipse.eatop.eastadl21.FunctionAllocation_target createFunctionAllocation_target() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionAllocation_target();
    }
    
    public org.eclipse.eatop.eastadl21.FunctionConnector_port createFunctionConnector_port() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createFunctionConnector_port();
    }
    
    public org.eclipse.eatop.eastadl21.Actuator createActuator() {
        org.eclipse.eatop.eastadl21.Actuator actuator = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createActuator();
        actuator.setUuid(java.util.UUID.randomUUID().toString());
        return actuator;
    }
    
    public org.eclipse.eatop.eastadl21.CommunicationHardwarePin createCommunicationHardwarePin() {
        org.eclipse.eatop.eastadl21.CommunicationHardwarePin communicationHardwarePin = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createCommunicationHardwarePin();
        communicationHardwarePin.setUuid(java.util.UUID.randomUUID().toString());
        return communicationHardwarePin;
    }
    
    public org.eclipse.eatop.eastadl21.ElectricalComponent createElectricalComponent() {
        org.eclipse.eatop.eastadl21.ElectricalComponent electricalComponent = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createElectricalComponent();
        electricalComponent.setUuid(java.util.UUID.randomUUID().toString());
        return electricalComponent;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareComponentPrototype createHardwareComponentPrototype() {
        org.eclipse.eatop.eastadl21.HardwareComponentPrototype hardwareComponentPrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareComponentPrototype();
        hardwareComponentPrototype.setUuid(java.util.UUID.randomUUID().toString());
        return hardwareComponentPrototype;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareComponentType createHardwareComponentType() {
        org.eclipse.eatop.eastadl21.HardwareComponentType hardwareComponentType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareComponentType();
        hardwareComponentType.setUuid(java.util.UUID.randomUUID().toString());
        return hardwareComponentType;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareConnector createHardwareConnector() {
        org.eclipse.eatop.eastadl21.HardwareConnector hardwareConnector = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareConnector();
        hardwareConnector.setUuid(java.util.UUID.randomUUID().toString());
        return hardwareConnector;
    }
    
    public org.eclipse.eatop.eastadl21.HardwarePort createHardwarePort() {
        org.eclipse.eatop.eastadl21.HardwarePort hardwarePort = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwarePort();
        hardwarePort.setUuid(java.util.UUID.randomUUID().toString());
        return hardwarePort;
    }
    
    public org.eclipse.eatop.eastadl21.HardwarePortConnector createHardwarePortConnector() {
        org.eclipse.eatop.eastadl21.HardwarePortConnector hardwarePortConnector = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwarePortConnector();
        hardwarePortConnector.setUuid(java.util.UUID.randomUUID().toString());
        return hardwarePortConnector;
    }
    
    public org.eclipse.eatop.eastadl21.IOHardwarePin createIOHardwarePin() {
        org.eclipse.eatop.eastadl21.IOHardwarePin iOHardwarePin = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createIOHardwarePin();
        iOHardwarePin.setUuid(java.util.UUID.randomUUID().toString());
        return iOHardwarePin;
    }
    
    public org.eclipse.eatop.eastadl21.LogicalPortConnector createLogicalPortConnector() {
        org.eclipse.eatop.eastadl21.LogicalPortConnector logicalPortConnector = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createLogicalPortConnector();
        logicalPortConnector.setUuid(java.util.UUID.randomUUID().toString());
        return logicalPortConnector;
    }
    
    public org.eclipse.eatop.eastadl21.Node createNode() {
        org.eclipse.eatop.eastadl21.Node node = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createNode();
        node.setUuid(java.util.UUID.randomUUID().toString());
        return node;
    }
    
    public org.eclipse.eatop.eastadl21.PowerHardwarePin createPowerHardwarePin() {
        org.eclipse.eatop.eastadl21.PowerHardwarePin powerHardwarePin = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createPowerHardwarePin();
        powerHardwarePin.setUuid(java.util.UUID.randomUUID().toString());
        return powerHardwarePin;
    }
    
    public org.eclipse.eatop.eastadl21.Sensor createSensor() {
        org.eclipse.eatop.eastadl21.Sensor sensor = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createSensor();
        sensor.setUuid(java.util.UUID.randomUUID().toString());
        return sensor;
    }
    
    public org.eclipse.eatop.eastadl21.HardwareConnector_port createHardwareConnector_port() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwareConnector_port();
    }
    
    public org.eclipse.eatop.eastadl21.HardwarePortConnector_port createHardwarePortConnector_port() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createHardwarePortConnector_port();
    }
    
    public org.eclipse.eatop.eastadl21.Comment createComment() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createComment();
    }
    
    public org.eclipse.eatop.eastadl21.EAPackage createEAPackage() {
        org.eclipse.eatop.eastadl21.EAPackage eAPackage = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAPackage();
        eAPackage.setUuid(java.util.UUID.randomUUID().toString());
        return eAPackage;
    }
    
    public org.eclipse.eatop.eastadl21.EAXML createEAXML() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAXML();
    }
    
    public org.eclipse.eatop.eastadl21.Rationale createRationale() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRationale();
    }
    
    public org.eclipse.eatop.eastadl21.Realization createRealization() {
        org.eclipse.eatop.eastadl21.Realization realization = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRealization();
        realization.setUuid(java.util.UUID.randomUUID().toString());
        return realization;
    }
    
    public org.eclipse.eatop.eastadl21.Realization_realized createRealization_realized() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRealization_realized();
    }
    
    public org.eclipse.eatop.eastadl21.Realization_realizedBy createRealization_realizedBy() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRealization_realizedBy();
    }
    
    public org.eclipse.eatop.eastadl21.ArrayDatatype createArrayDatatype() {
        org.eclipse.eatop.eastadl21.ArrayDatatype arrayDatatype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createArrayDatatype();
        arrayDatatype.setUuid(java.util.UUID.randomUUID().toString());
        return arrayDatatype;
    }
    
    public org.eclipse.eatop.eastadl21.CompositeDatatype createCompositeDatatype() {
        org.eclipse.eatop.eastadl21.CompositeDatatype compositeDatatype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createCompositeDatatype();
        compositeDatatype.setUuid(java.util.UUID.randomUUID().toString());
        return compositeDatatype;
    }
    
    public org.eclipse.eatop.eastadl21.EABoolean createEABoolean() {
        org.eclipse.eatop.eastadl21.EABoolean eABoolean = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEABoolean();
        eABoolean.setUuid(java.util.UUID.randomUUID().toString());
        return eABoolean;
    }
    
    public org.eclipse.eatop.eastadl21.EADatatypePrototype createEADatatypePrototype() {
        org.eclipse.eatop.eastadl21.EADatatypePrototype eADatatypePrototype = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEADatatypePrototype();
        eADatatypePrototype.setUuid(java.util.UUID.randomUUID().toString());
        return eADatatypePrototype;
    }
    
    public org.eclipse.eatop.eastadl21.EANumerical createEANumerical() {
        org.eclipse.eatop.eastadl21.EANumerical eANumerical = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEANumerical();
        eANumerical.setUuid(java.util.UUID.randomUUID().toString());
        return eANumerical;
    }
    
    public org.eclipse.eatop.eastadl21.EAString createEAString() {
        org.eclipse.eatop.eastadl21.EAString eAString = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAString();
        eAString.setUuid(java.util.UUID.randomUUID().toString());
        return eAString;
    }
    
    public org.eclipse.eatop.eastadl21.Enumeration createEnumeration() {
        org.eclipse.eatop.eastadl21.Enumeration enumeration = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEnumeration();
        enumeration.setUuid(java.util.UUID.randomUUID().toString());
        return enumeration;
    }
    
    public org.eclipse.eatop.eastadl21.EnumerationLiteral createEnumerationLiteral() {
        org.eclipse.eatop.eastadl21.EnumerationLiteral enumerationLiteral = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEnumerationLiteral();
        enumerationLiteral.setUuid(java.util.UUID.randomUUID().toString());
        return enumerationLiteral;
    }
    
    public org.eclipse.eatop.eastadl21.Quantity createQuantity() {
        org.eclipse.eatop.eastadl21.Quantity quantity = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createQuantity();
        quantity.setUuid(java.util.UUID.randomUUID().toString());
        return quantity;
    }
    
    public org.eclipse.eatop.eastadl21.RangeableValueType createRangeableValueType() {
        org.eclipse.eatop.eastadl21.RangeableValueType rangeableValueType = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createRangeableValueType();
        rangeableValueType.setUuid(java.util.UUID.randomUUID().toString());
        return rangeableValueType;
    }
    
    public org.eclipse.eatop.eastadl21.Unit createUnit() {
        org.eclipse.eatop.eastadl21.Unit unit = org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createUnit();
        unit.setUuid(java.util.UUID.randomUUID().toString());
        return unit;
    }
    
    public org.eclipse.eatop.eastadl21.EAArrayValue createEAArrayValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAArrayValue();
    }
    
    public org.eclipse.eatop.eastadl21.EABooleanValue createEABooleanValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEABooleanValue();
    }
    
    public org.eclipse.eatop.eastadl21.EACompositeValue createEACompositeValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEACompositeValue();
    }
    
    public org.eclipse.eatop.eastadl21.EAEnumerationValue createEAEnumerationValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAEnumerationValue();
    }
    
    public org.eclipse.eatop.eastadl21.EAExpression createEAExpression() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAExpression();
    }
    
    public org.eclipse.eatop.eastadl21.EANumericalValue createEANumericalValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEANumericalValue();
    }
    
    public org.eclipse.eatop.eastadl21.EAStringValue createEAStringValue() {
        return org.eclipse.eatop.eastadl21.Eastadl21Factory.eINSTANCE.createEAStringValue();
    }
    
}