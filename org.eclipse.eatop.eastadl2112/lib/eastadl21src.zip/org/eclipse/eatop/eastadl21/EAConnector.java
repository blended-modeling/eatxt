/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EA Connector</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * null
 * 
 * Original fully qualified name: 
 * <em><b>eastadl21.EAST-ADL.Infrastructure.Elements.EAConnector</b></em> 
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.eatop.eastadl21.Eastadl21Package#getEAConnector()
 * @model abstract="true"
 *        annotation="MetaData guid='{01765C94-3C29-4707-A220-4A087EF7715D}' id='240' EA\040name='EAConnector'"
 *        extendedMetaData="name='EA-CONNECTOR' kind='elementOnly'"
 *        annotation="http:///org/eclipse/sphinx/emf/serialization/XMLPersistenceMappingExtendedMetaData wrapperName='EA-CONNECTORS'"
 * @generated
 */
public interface EAConnector extends EObject {
} // EAConnector
