/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.edit;

import java.io.IOException;
import java.io.InputStream;

import java.net.URL;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;

import org.eclipse.emf.common.EMFPlugin;

import org.eclipse.emf.common.util.ResourceLocator;

/**
 * This is the central singleton for the EAST-ADL_SubsetFDAHDA edit plugin.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public final class Activator extends EMFPlugin {
	/**
	 * Keep track of the singleton.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final Activator INSTANCE = new Activator();

	/**
	 * Keep track of the singleton.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static Implementation plugin;

	/**
	 * Create the instance.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Activator() {
		super
		  (new ResourceLocator [] {
		     org.eclipse.eatop.geastadl.edit.internal.Activator.INSTANCE,
		   });
	}

	/**
	 * Returns the singleton instance of the Eclipse plugin.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the singleton instance.
	 * @generated
	 */
	@Override
	public ResourceLocator getPluginResourceLocator() {
		return plugin;
	}

	/**
	 * Returns the singleton instance of the Eclipse plugin.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the singleton instance.
	 * @generated
	 */
	public static Implementation getPlugin() {
		return plugin;
	}

	/**
	 * The actual implementation of the Eclipse <b>Plugin</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static class Implementation extends EclipsePlugin {
		/**
		 * Creates an instance.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public Implementation() {
			super();

			// Remember the static instance.
			//
			plugin = this;
		}		

		/**
		 * Does the work of fetching the image associated with the key from icons jar file (rather than icons folder).
		 * It ensures that the image exists.
		 * @param key the key of the image to fetch.
		 * @exception IOException if an image doesn't exist.
		 * @return the description of the image associated with the key.
		*/
//		
//		@Override
//		
//		protected Object doGetImage(String key) throws IOException {
//			URL iconsArchiveBundleURL = FileLocator.find(getBundle(), new Path("lib/eastadl21.editicons.jar"), null); //$NON-NLS-1$
//			URL imageFileURL = new URL("jar:" + iconsArchiveBundleURL.toString() + "!/icons/" + key + extensionFor(key)); //$NON-NLS-1$ //$NON-NLS-2$
//			InputStream inputStream = imageFileURL.openStream(); 
//			inputStream.close();
//			return imageFileURL;
//		}
	}

}
