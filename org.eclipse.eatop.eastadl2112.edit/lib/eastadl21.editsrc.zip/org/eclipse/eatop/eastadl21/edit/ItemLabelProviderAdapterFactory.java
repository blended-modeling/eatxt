/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package org.eclipse.eatop.eastadl21.edit;

import org.eclipse.core.runtime.IAdapterFactory;

import org.eclipse.eatop.eastadl21.util.Eastadl21ReleaseDescriptor;

import org.eclipse.emf.edit.provider.IItemLabelProvider;

/**
 * This is the item label provider adapter factory for a EAST-ADL_SubsetFDAHDA release.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class ItemLabelProviderAdapterFactory implements IAdapterFactory {

	/** <!-- begin-user-doc -->
	 *  <!-- end-user-doc -->
	 *  @see org.eclipse.core.runtime.IAdapterFactory#getAdapter(java.lang.Object, java.lang.Class)
	 *  @generated
	 */
	public Object getAdapter(Object adaptableObject, Class adapterType) {
		if (adapterType.equals(IItemLabelProvider.class)) {
			// IItemLabelProvider adapter for Eastadl21ReleaseDescriptor?
			if (adaptableObject instanceof Eastadl21ReleaseDescriptor) {
				return new Eastadl21ReleaseDescriptorItemLabelProvider();
			}
		}
		return null;
	}
    /** <!-- begin-user-doc -->
	 *  <!-- end-user-doc -->
	 *  @see org.eclipse.core.runtime.IAdapterFactory#getAdapterList()
	 *  @generated
	 */
	public Class[] getAdapterList() {
		return new Class<?>[] { IItemLabelProvider.class };
	}
}
